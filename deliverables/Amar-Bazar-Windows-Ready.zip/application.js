const express=require('express');
const multer=require('multer');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {promisify}=require('node:util');
const scrypt=promisify(crypto.scrypt);
const {openStore}=require('./lib/store');
const {sendTelegramOrderNotification}=require('./integrations/telegram');
const {sendOrderEmails}=require('./integrations/email');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const hashAdminToken=token=>hash('admin:v2:'+token);
const fail=(message,status=400)=>{const e=Error(message);e.status=status;throw e;};
function text(v,label,max=200,required=true){if(typeof v!=='string'||v.trim().length>max||(required&&!v.trim()))fail('Invalid '+label);return v.trim();}
function integer(v,label,max=100000000){if(!Number.isSafeInteger(v)||v<0||v>max)fail('Invalid '+label);return v;}
function logoSize(v,label,min,max){integer(v,label,max);if(v<min)fail('Invalid '+label);return v;}
function img(v){if(!v)return '';if(typeof v!=='string'||v.length>150000||!(/^\/uploads\/[\w. =-]+$/.test(v)||/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(v)||/^https:\/\/images\.unsplash\.com\//.test(v)))fail('Upload an image first');return v;}
function isIconFile(buffer){
 if(buffer.length<22||buffer.readUInt32LE(0)!==0x00010000)return false;
 const count=buffer.readUInt16LE(4),directoryEnd=6+count*16;
 if(!count||directoryEnd>buffer.length)return false;
 for(let i=6;i<directoryEnd;i+=16){
  const size=buffer.readUInt32LE(i+8),offset=buffer.readUInt32LE(i+12);
  if(!size||offset<directoryEnd||offset+size>buffer.length)return false;
 }
 return true;
}
function createApp(options={}){
 const root=__dirname, dataDir=options.dataDir||process.env.DATA_DIR||path.join(root,'data');
 const store=openStore(dataDir,options.legacyFile===undefined?path.join(root,'db.json'):options.legacyFile);
 const uploadDir=options.uploadDir||process.env.UPLOAD_DIR||path.join(root,'public','uploads');fs.mkdirSync(uploadDir,{recursive:true});
 const port=process.env.PORT||5000,origin=options.origin||process.env.PUBLIC_URL||`http://localhost:${port}`;
 if(process.env.NODE_ENV==='production'&&!origin.startsWith('https://'))throw Error('Production requires HTTPS PUBLIC_URL');
 const app=express();app.disable('x-powered-by');
 if(process.env.TRUST_PROXY==='1')app.set('trust proxy',1);
 const secure=origin.startsWith('https://');
 app.use((req,res,next)=>{res.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'SAMEORIGIN','Referrer-Policy':'same-origin','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https://images.unsplash.com; connect-src 'self'; frame-ancestors 'self'; base-uri 'none'; form-action 'self'"});if(secure)res.set('Strict-Transport-Security','max-age=31536000');next();});
 app.use('/api', (req,res,next)=>{res.set('Cache-Control','no-store');if(!['GET','HEAD','OPTIONS'].includes(req.method)&&req.get('origin')!==origin)return res.status(403).json({error:'Untrusted request origin. Open the configured store URL.'});next();});
 app.use(express.json({limit:'200kb'}));
 const buckets=new Map();
 function limit(name,max){return(req,res,next)=>{const now=Date.now(),key=name+':'+req.ip;for(const[k,v]of buckets)if(v.until<now)buckets.delete(k);if(buckets.size>10000)return res.status(503).json({error:'Please try later'});let b=buckets.get(key);if(!b){b={n:0,until:now+15*60000};buckets.set(key,b);}if(++b.n>max)return res.status(429).json({error:'Too many attempts. Try again in 15 minutes.'});next();};}
 function session(req){const token=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('wb_session='))?.slice(11);if(!token)return null;return store.db.prepare('SELECT * FROM sessions WHERE token=? AND expires>?').get(hashAdminToken(token),Date.now());}
 function auth(req,res,next){req.session=session(req);if(!req.session)return res.status(401).json({error:'Please log in'});if(!['GET','HEAD'].includes(req.method)&&req.get('x-csrf-token')!==req.session.csrf)return res.status(403).json({error:'Session security check failed. Reload the page.'});next();}
 app.post('/api/login',limit('login',15),async(req,res)=>{const email=text(req.body.email,'email',200).toLowerCase();const password=text(req.body.password,'password',200);const admin=store.db.prepare('SELECT * FROM admins WHERE email=?').get(email);const value=await scrypt(password,admin?.salt||'dummy-salt-for-timing',64);if(!admin||!crypto.timingSafeEqual(value,Buffer.from(admin.hash,'hex')))fail('Incorrect email or password',401);const token=crypto.randomBytes(32).toString('hex'),csrf=crypto.randomBytes(24).toString('hex');const previous=session(req),lifetime=8*3600000;
  store.tx(()=>{
   store.db.prepare('DELETE FROM sessions WHERE expires<=? OR token=?').run(Date.now(),previous?.token||'');
   store.db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hashAdminToken(token),csrf,Date.now()+lifetime);
  });res.cookie('wb_session',token,{httpOnly:true,sameSite:'strict',secure,path:'/',maxAge:8*3600000});res.json({csrf});});
 app.get('/api/session',auth,(req,res)=>res.json({csrf:req.session.csrf,expiresIn:Math.max(0,req.session.expires-Date.now())}));
 app.post('/api/logout',auth,(req,res)=>{store.db.prepare('DELETE FROM sessions WHERE token=?').run(req.session.token);res.clearCookie('wb_session',{path:'/',secure,sameSite:'strict'});res.json({ok:true});});
 require('./lib/customers').attach({app,store,limit,secure});
 require('./lib/categories').attach({app,store,auth});
 require('./lib/experience').attach({app,store,auth,limit});
 require('./lib/admin-suite').attach({app,store,auth,dataDir,uploadDir});
 app.get('/api/settings',(req,res)=>res.json(store.get('config','settings')));
 app.put('/api/settings',auth,(req,res)=>{const b=req.body;const previous=store.get('config','settings');const settings={brandingManaged:true,logoWidth:logoSize(b.logoWidth??previous.logoWidth??140,'desktop logo width',60,320),logoMobileWidth:logoSize(b.logoMobileWidth??previous.logoMobileWidth??100,'mobile logo width',40,180),showStoreName:b.showStoreName===undefined?!!previous.showStoreName:b.showStoreName===true,name:text(b.name,'store name',80),tagline:text(b.tagline,'tagline',180,false),color:text(b.color,'color',7),phone:text(b.phone,'phone',30,false),email:text(b.email,'email',150,false),address:text(b.address,'address',300,false),footer:text(b.footer,'footer',300,false),logo:img(b.logo),banner:img(b.banner),insideShipping:integer(b.insideShipping,'shipping'),outsideShipping:integer(b.outsideShipping,'shipping'),manual:{}};if(!/^#[0-9a-f]{6}$/i.test(settings.color))fail('Invalid color');for(const m of ['bkash','nagad','rocket']){settings.manual[m]=text(b.manual?.[m]??'',m,30,false);if(settings.manual[m]&&!/^\+?[0-9]{10,15}$/.test(settings.manual[m]))fail('Invalid payment account');}store.put('config','settings',settings);store.audit('settings.update','store');res.json(settings);});
 app.get('/theme.css',(req,res)=>res.type('css').send(`:root{--brand:${store.get('config','settings').color}}`));
 const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024,files:1,fields:0}});
 function saveUpload(req,res,allowIcon=false){
  const b=req.file?.buffer;
  if(!b)fail('Choose an image');
  let ext='';
  if(b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))ext='.png';
  else if(b[0]===255&&b[1]===216&&b[2]===255)ext='.jpg';
  else if(b.subarray(0,4).toString()==='RIFF'&&b.subarray(8,12).toString()==='WEBP')ext='.webp';
  else if(allowIcon&&isIconFile(b))ext='.ico';
  if(!ext)fail(allowIcon?'Choose a PNG, JPEG, WebP or ICO image':'Only PNG, JPEG and WebP images are allowed');
  const filename=crypto.randomUUID()+ext;
  fs.writeFileSync(path.join(uploadDir,filename),b,{flag:'wx'});
  res.status(201).json({image:'/uploads/'+filename});
 }
 app.post('/api/uploads',auth,upload.single('image'),(req,res)=>saveUpload(req,res));
 app.post('/api/admin/tab-icon',auth,upload.single('image'),(req,res)=>saveUpload(req,res,true));
 require('./lib/storefront-tab').attach({app,store,auth,uploadDir,publicDir:path.join(root,'public')});
 require('./lib/live-analytics').attach({app,store,auth,session,limit});
 app.get('/api/products',(req,res)=>res.json(store.all('products').filter(p=>p.active).map(p=>{const copy=structuredClone(p);if(copy.details)delete copy.details.cost;return copy;})));
 app.get('/api/admin/products',auth,(req,res)=>res.json(store.all('products').filter(p=>!p.deleted)));
 function productInput(b,old){const p={merch:old?.merch,id:old?.id||crypto.randomUUID(),version:(old?.version||0)+1,name:text(b.name,'product name',120),category:text(b.category,'category',60),description:text(b.description||'','description',15000,false),image:img(b.image),details:require('./lib/admin-suite').metadata(b,old),active:b.active===true,createdAt:old?.createdAt||new Date().toISOString()};const images=b.images===undefined?(old?.images||[]):b.images;if(!Array.isArray(images)||images.length>12)fail('Maximum 12 gallery images');p.images=images.map(img);const reviews=b.reviews===undefined?(old?.reviews||[]):b.reviews;if(!Array.isArray(reviews)||reviews.length>50)fail('Maximum 50 product reviews');p.reviews=reviews.map(r=>{if(!r||!Number.isInteger(r.rating)||r.rating<1||r.rating>5)fail('Rating must be 1–5');return{name:text(r.name,'review name',100),text:text(r.text,'review text',1500),rating:r.rating,image:img(r.image)};});if(!Array.isArray(b.variants)||!b.variants.length||b.variants.length>50)fail('Add 1–50 variants');const ids=new Set(),combinations=new Set();p.variants=b.variants.map(v=>{const color=text(v.color||'','color',40,false),size=text(v.size||'','size',30,false),key=color.toLowerCase()+'|'+size.toLowerCase();if(combinations.has(key))fail('Duplicate size/color');combinations.add(key);const id=old?.variants.some(x=>x.id===v.id)?v.id:crypto.randomUUID();if(ids.has(id))fail('Duplicate variant ID');ids.add(id);const price=integer(v.price,'price');if(price<1)fail('Price must be positive');return{id,color,size,compareAt:v.compareAt===undefined?(old?.variants.find(x=>x.id===id)?.compareAt||0):(()=>{const n=integer(v.compareAt,'compare price');if(n&&n<=price)fail('Compare price must exceed sale price');return n;})(),price,stock:integer(v.stock,'stock',100000)};});if(b.categoryId!==undefined){const category=store.get('config','categories').items.find(c=>c.id===b.categoryId);if(!category)fail('Choose an existing category');p.category=category.name;p.merch={...p.merch,categoryId:category.id};}return p;}
 app.post('/api/products',auth,(req,res)=>{const p=productInput(req.body);store.put('products',p.id,p);store.audit('product.create',p.id);res.status(201).json(p);});
 app.put('/api/products/:id',auth,(req,res)=>{const old=store.get('products',req.params.id);if(!old||old.deleted)fail('Product not found',404);if(req.body.version!==old.version)fail('Product changed since you opened it. Reload and edit again.',409);const p=productInput(req.body,old);if(old.variants.some(v=>!p.variants.some(n=>n.id===v.id)))fail('Existing variants cannot be removed: set stock to 0 or archive the product to preserve order history.');store.put('products',p.id,p);store.audit('product.update',p.id);res.json(p);});
 app.post('/api/products/:id/remove',auth,(req,res)=>{const p=store.get('products',req.params.id);if(!p||p.deleted)fail('Product not found',404);p.active=false;p.deleted=true;p.deletedAt=new Date().toISOString();p.version=(p.version||0)+1;store.put('products',p.id,p);store.audit('product.delete',p.id);res.json({ok:true});});
 app.delete('/api/products/:id',auth,(req,res)=>{const p=store.get('products',req.params.id);if(!p)fail('Product not found',404);p.active=false;p.version=(p.version||0)+1;store.put('products',p.id,p);store.audit('product.archive',p.id);res.json({ok:true});});
 app.post('/api/orders',limit('checkout',30),(req,res)=>{
  const b=req.body;const key=text(b.idempotencyKey,'checkout key',80);if(!/^[\w-]{16,80}$/.test(key))fail('Invalid checkout key');
  const customer={name:text(b.customer?.name,'name',100),phone:text(b.customer?.phone,'phone',20),address:text(b.customer?.address,'address',500),district:text(b.customer?.district,'district',80)};customer.phone=customer.phone.replace(/^\+880/,'0');if(!/^01[3-9]\d{8}$/.test(customer.phone))fail('Enter a valid Bangladesh mobile number');
  customer.email=text(b.customer?.email||'','email',180,false);customer.thana=text(b.customer?.thana||'','thana',100,false);const notes=text(b.notes||'','notes',300,false);const billing=b.billing?{name:text(b.billing.name,'billing name',100),address:text(b.billing.address,'billing address',500)}:null;const zone=b.zone;if(!['inside','outside'].includes(zone))fail('Choose delivery zone');
  const method=b.paymentMethod;if(!['cod','bkash','nagad','rocket'].includes(method))fail('Invalid payment method');
  const trxId=method==='cod'?'':text(b.trxId,'transaction ID',80).toUpperCase();if(trxId&&!/^[A-Z0-9-]{5,80}$/.test(trxId))fail('Invalid transaction ID');
  if(!Array.isArray(b.items)||!b.items.length||b.items.length>50)fail('Cart must contain 1–50 items');
  const requested=new Map();for(const i of b.items){const pid=text(i.productId,'product ID',80),vid=text(i.variantId,'variant ID',80),qty=integer(i.quantity,'quantity',20);if(!qty)fail('Quantity must be positive');const k=pid+':'+vid,prev=requested.get(k);const quantity=(prev?.quantity||0)+qty;if(quantity>20)fail('Maximum 20 per variant');requested.set(k,{productId:pid,variantId:vid,quantity});}
  if(b.accessKey!==undefined&&(typeof b.accessKey!=='string'||!/^([a-f0-9]{64})$/.test(b.accessKey)))fail('Invalid order access key');
  const expectedTotal=integer(b.expectedTotal,'expected total');const normalized={couponCode:String(b.couponCode||'').trim().toUpperCase(),customer,notes,billing,zone,method,trxId,expectedTotal,items:[...requested.values()].sort((a,b)=>(a.productId+a.variantId).localeCompare(b.productId+b.variantId))};const fingerprint=hash(JSON.stringify(normalized));
  const result=store.tx(()=>{const prior=store.db.prepare('SELECT * FROM requests WHERE key=?').get(key);if(prior){if(prior.fingerprint!==fingerprint)fail('Checkout changed. Start a new checkout.',409);const order=store.get('orders',prior.order_id);return{id:order.id,number:order.number,total:order.total,created:false};}
   const settings=store.get('config','settings');if(method!=='cod'&&!settings.manual[method])fail('This payment method is not enabled');
   const items=[];let subtotal=0;
   for(const i of normalized.items){const p=store.get('products',i.productId),v=p?.variants.find(v=>v.id===i.variantId);if(!p?.active||!v)fail('A cart product is unavailable',409);if(v.stock<i.quantity)fail(`Not enough stock: ${p.name}`,409);v.stock-=i.quantity;p.version=(p.version||0)+1;store.put('products',p.id,p);const lineTotal=v.price*i.quantity;subtotal+=lineTotal;items.push({...i,name:p.name,color:v.color,size:v.size,price:v.price,lineTotal});}
   const shipping=zone==='inside'?settings.insideShipping:settings.outsideShipping;const discount=require('./lib/admin-suite').discount(store,normalized.couponCode,items);if(subtotal+shipping-discount.amount!==expectedTotal)fail('Price or delivery fee changed. Refresh checkout and review the new total before ordering.',409);const id=crypto.randomUUID();const order={id,customerId:require('./lib/customers').session(store,req)?.id,accessHash:b.accessKey?hash(b.accessKey):undefined,number:'WB-'+id.slice(0,8).toUpperCase(),customer,notes,billing,zone,items,subtotal,shipping,discount,total:subtotal+shipping-discount.amount,status:'Pending',payment:{method,status:method==='cod'?'unpaid':'pending_verification',trxId},createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),stockReleased:false,courier:{provider:'',tracking:''},legacy:false};if(discount.code){const coupons=store.get('config','coupons');coupons.items.find(c=>c.code===discount.code).used++;coupons.version++;store.put('config','coupons',coupons);}store.put('orders',id,order);store.db.prepare('INSERT INTO requests VALUES(?,?,?)').run(key,fingerprint,id);store.audit('order.create',id);return{id,number:order.number,total:order.total,created:true,notificationOrder:order};});
  if(result.created){
    void sendTelegramOrderNotification(result.notificationOrder).catch(err=>console.error('Telegram notification error:',err.message));
    void sendOrderEmails(result.notificationOrder).catch(err=>console.error('Email notification error:',err.message));
  }
  res.status(201).json({id:result.id,number:result.number,total:result.total});
 });

 // Store reset: requires active admin session, CSRF, current password and explicit confirmation.
 app.get('/api/admin/store-reset/preview',auth,(req,res)=>{
  const count=t=>store.db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
  res.json({orders:count('orders'),customers:count('customers'),requests:count('requests'),transactions:count('transactions')});
 });
 app.post('/api/admin/store-reset',auth,async(req,res,next)=>{
  try{
   const mode=req.body?.mode;
   if(!['orders','customers','all'].includes(mode))fail('Invalid reset option');
   if(req.body?.confirmation!=='DELETE STORE DATA')fail('Type DELETE STORE DATA to confirm');
   const email=String(req.body?.email||'').trim().toLowerCase();
   const password=String(req.body?.password||'');
   if(!email||password.length<1||password.length>200)fail('Enter your admin email and password');
   const admin=store.db.prepare('SELECT * FROM admins WHERE email=?').get(email);
   const candidate=await scrypt(password,admin?.salt||'dummy-salt-for-timing',64);
   if(!admin||!crypto.timingSafeEqual(candidate,Buffer.from(admin.hash,'hex')))fail('Admin email or password incorrect',403);
   // Make a consistent SQLite backup BEFORE any deletion, outside the public directory.
   const backupDir=path.join(dataDir,'reset-backups');fs.mkdirSync(backupDir,{recursive:true,mode:0o700});
   const backupName='store-before-reset-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomBytes(4).toString('hex')+'.sqlite';
   const backupFile=path.join(backupDir,backupName);
   store.db.prepare('VACUUM INTO ?').run(backupFile);
   const result=store.tx(()=>{
    const counts={orders:0,customers:0};
    if(mode==='orders'||mode==='all'){
     counts.orders=store.db.prepare('SELECT COUNT(*) AS n FROM orders').get().n;
     for(const t of ['orders','requests','transactions'])store.db.exec(`DELETE FROM ${t}`);
     // A new client's coupon usage must not include the previous client's orders.
     const coupons=store.get('config','coupons');
     if(coupons?.items){for(const c of coupons.items)c.used=0;coupons.version=(coupons.version||0)+1;store.put('config','coupons',coupons);}
    }
    if(mode==='customers'||mode==='all'){
     counts.customers=store.db.prepare('SELECT COUNT(*) AS n FROM customers').get().n;
     for(const t of ['customer_sessions','customer_profiles','customers'])store.db.exec(`DELETE FROM ${t}`);
    }
    if(mode==='all')store.db.exec('DELETE FROM audit');
    store.audit('store.reset.'+mode,JSON.stringify(counts));
    return counts;
   });
   res.json({ok:true,deleted:result,backup:backupName});
  }catch(e){next(e);}
 });
 app.get('/api/orders',auth,(req,res)=>res.json(store.all('orders')));
 app.get('/api/orders/:id',auth,(req,res)=>{const o=store.get('orders',req.params.id);if(!o)fail('Order not found',404);res.json(o);});
 app.patch('/api/orders/:id',auth,(req,res)=>{const o=store.tx(()=>{const o=store.get('orders',req.params.id);if(!o)fail('Order not found',404);const b=req.body;const transitions={Pending:['Confirmed','Processing','Cancelled'],Confirmed:['Processing','Cancelled'],Processing:['Shipped','Cancelled'],Shipped:['Delivered','Returned'],Delivered:['Returned'],Cancelled:[],Returned:[]};
 if(b.status&&b.status!==o.status){if(!(transitions[o.status]||[]).includes(b.status))fail('Invalid order status transition');if(['Cancelled','Returned'].includes(b.status)&&!o.stockReleased&&!o.legacy){for(const item of o.items){const p=store.get('products',item.productId);const v=p?.variants.find(v=>v.id===item.variantId);if(v){v.stock+=item.quantity;p.version=(p.version||0)+1;store.put('products',p.id,p);}}o.stockReleased=true;}o.status=b.status;}
 if(b.paymentStatus&&b.paymentStatus!==o.payment.status){const s=b.paymentStatus;if(s==='paid'){if(o.legacy)fail('Legacy payment cannot be verified from missing details');if(['Cancelled','Returned'].includes(o.status))fail('Cannot collect payment for a closed order');if(!['unpaid','pending_verification'].includes(o.payment.status))fail('Invalid payment transition');if(o.payment.method==='cod'&&o.status!=='Delivered')fail('Mark delivered before confirming COD collection');if(o.payment.method!=='cod'){const reference=o.payment.method+':'+o.payment.trxId;const existing=store.db.prepare('SELECT order_id FROM transactions WHERE reference=?').get(reference);if(existing&&existing.order_id!==o.id)fail('This transaction is already verified for another order',409);store.db.prepare('INSERT OR IGNORE INTO transactions VALUES(?,?)').run(reference,o.id);}o.payment.paidAt=new Date().toISOString();}else if(s==='refunded'){if(o.payment.status!=='paid'||!['Returned','Cancelled'].includes(o.status))fail('Refund requires a paid cancelled/returned order');o.payment.refundedAt=new Date().toISOString();}else fail('Invalid payment status');o.payment.status=s;}
 if(b.courier){if(!['','steadfast','pathao','other'].includes(b.courier.provider))fail('Invalid courier');o.courier={provider:b.courier.provider,tracking:text(b.courier.tracking||'','tracking',100,false)};}o.updatedAt=new Date().toISOString();store.put('orders',o.id,o);store.audit('order.update',o.id);return o;});res.json(o);});
 app.get('/api/analytics',auth,(req,res)=>{const rows=store.all('orders'),day=d=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Dhaka',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(d)),today=day(Date.now()),month=today.slice(0,7);const valid=rows.filter(o=>!o.legacy),paid=valid.filter(o=>o.payment.status==='paid');const top=new Map();for(const o of valid.filter(o=>o.status==='Delivered'))for(const i of o.items){const t=top.get(i.productId)||{name:i.name,quantity:0};t.quantity+=i.quantity;top.set(i.productId,t);}res.json({orders:rows.length,legacy:rows.filter(o=>o.legacy).length,collected:paid.reduce((n,o)=>n+o.total,0),today:paid.filter(o=>o.payment.paidAt&&day(o.payment.paidAt)===today).reduce((n,o)=>n+o.total,0),month:paid.filter(o=>o.payment.paidAt&&day(o.payment.paidAt).startsWith(month)).reduce((n,o)=>n+o.total,0),statuses:rows.reduce((s,o)=>(s[o.status]=(s[o.status]||0)+1,s),{}),top:[...top.values()].sort((a,b)=>b.quantity-a.quantity).slice(0,5)});});
 const adminPages=['admin','admin-products','invoice','theme-editor','merchandising','admin-suite','categories','admin-reset'];
 function requireAdminPage(req,res,next){
  res.set('Cache-Control','private, no-store');
  res.vary('Cookie');
  if(!session(req))return res.redirect('/login.html');
  next();
 }
 app.get(['/admin','/admin/'],requireAdminPage,(req,res)=>res.redirect('/admin.html'));
 for(const page of adminPages){
  app.get('/'+page+'.html',requireAdminPage,(req,res)=>{
   res.sendFile(page+'.html',{root:path.join(root,'admin'),cacheControl:false,lastModified:false});
  });
 }
 app.use('/uploads',express.static(uploadDir,{dotfiles:'deny',index:false}));
 const staticFiles=express.static(path.join(root,'public'),{dotfiles:'deny',index:false,redirect:false,setHeaders:res=>res.set('Cache-Control','no-store')});
 app.use((req,res,next)=>{
  // Serve HTML only through the page routes, including on overlay deployments with old public HTML files.
  let pathname;
  try{pathname=decodeURIComponent(req.path);}catch{return res.sendStatus(400);}
  if(pathname.toLowerCase().endsWith('.html'))return next();
  staticFiles(req,res,next);
 });
 app.use('/api',(req,res)=>res.status(404).json({error:'API route not found'}));
 app.use((err,req,res,next)=>{const status=err.code==='LIMIT_FILE_SIZE'?413:err instanceof multer.MulterError?400:err.status||500;if(status===500)console.error(err.message);res.status(status).json({error:status===500?'Unexpected server error. Check the server terminal.':err.code==='LIMIT_FILE_SIZE'?'Image must be smaller than 5 MB':err.message});});
 return {app,store};
}
if(require.main===module){const {app}=createApp();const port=process.env.PORT||5000;app.listen(port,process.env.HOST||'127.0.0.1',()=>console.log(`Web Bazar: ${process.env.PUBLIC_URL||'http://localhost:'+port}`));}
module.exports={createApp};
