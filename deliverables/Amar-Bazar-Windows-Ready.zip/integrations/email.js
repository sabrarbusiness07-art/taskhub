'use strict';

async function sendOrderEmails(order) {
  return { skipped: true };
}

module.exports = { sendOrderEmails };