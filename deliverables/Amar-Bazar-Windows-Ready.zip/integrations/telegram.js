// Telegram Bot API integration. Never put credentials in source code.
function safe(value, max=160) { return String(value ?? '').replace(/[\x00-\x1f\x7f]/g,' ').slice(0,max); }
async function sendTelegramOrderNotification(order) {
 const token=process.env.TELEGRAM_BOT_TOKEN;
 const chatId=process.env.TELEGRAM_CHAT_ID;
 if(!token||!chatId)return false;
 const lines=[
  '🛒 New Web Bazar Order!',
  `Order: ${safe(order.number||order.id)}`,
  `Customer: ${safe(order.customer?.name)}`,
  `Phone: ${safe(order.customer?.phone,30)}`,
  `District: ${safe(order.customer?.district)}`,
  `Total: BDT ${safe(order.total,30)}`,
  `Payment: ${safe(order.payment?.method,30)}`,
  `Status: ${safe(order.status,30)}`,
  '', 'Open your admin panel to view the full order.'
 ];
 try {
  const response=await fetch(`https://api.telegram.org/bot${token}/sendMessage`,{
   method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({chat_id:chatId,text:lines.join('\n')}),
   signal:AbortSignal.timeout(10000)
  });
  if(!response.ok)throw Error(`Telegram HTTP ${response.status}`);
  const payload=await response.json();
  if(!payload.ok)throw Error('Telegram API rejected message');
  return true;
 } catch(err) {console.error('Telegram order notification failed:',err.message);return false;}
}
module.exports={sendTelegramOrderNotification};
