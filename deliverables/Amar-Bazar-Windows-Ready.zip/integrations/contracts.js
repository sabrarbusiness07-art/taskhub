// Future server-side adapters. No credentials are stored in storefront settings.
// These explicitly fail until a real provider implementation is configured.
class PaymentGateway {
 async initiate({orderId,amountPaisa,currency,returnUrl,ipnUrl}) {throw new Error('Gateway not connected');}
 async validateNotification(payload) {throw new Error('Gateway not connected');}
 // Implementation must verify provider transaction, order, amount, currency,
 // merchant account and risk flags before an idempotent database transition.
}
class CourierAdapter {
 async book({bookingKey,order,collectPaisa}) {throw new Error('Courier API not connected');}
 async lookup({consignmentId}) {throw new Error('Courier API not connected');}
 // Persist booking key before request; reconcile a timeout before rebooking.
}
module.exports={PaymentGateway,CourierAdapter};
