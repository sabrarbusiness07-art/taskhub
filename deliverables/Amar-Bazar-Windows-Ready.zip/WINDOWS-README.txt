AMAR BAZAR - RUN ON WINDOWS

1. Install Node.js 24.14.0 or a newer 24.x version.
2. Extract the entire Windows ZIP into a regular folder.
3. To run an existing store locally, copy its data/ folder and
   public/uploads/ folder into this extracted project. Stop the existing
   local server before copying its SQLite database.
4. Double-click START-WINDOWS.cmd or use node server.js from the project
   folder in PowerShell.
5. Open http://localhost:5000/. The admin login is at
   http://localhost:5000/login.html.

This package includes the Node.js libraries needed to start, including
Express and multer. The Node.js runtime is installed separately.
If you are starting with an empty database, run npm.cmd run setup
from the project folder to create a local admin account.

This ZIP is the Windows package. Use the separate source update and
DEPLOY-README.txt for cPanel.
