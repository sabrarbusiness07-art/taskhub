'use strict';
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=p=>new Intl.NumberFormat('en-BD',{style:'currency',currency:'BDT'}).format((p||0)/100);
let csrf='';
async function api(url,options={}){const headers={...options.headers};if(options.body&&!(options.body instanceof FormData)){headers['Content-Type']='application/json';options.body=JSON.stringify(options.body);}if(csrf)headers['X-CSRF-Token']=csrf;let r;try{r=await fetch(url,{...options,headers});}catch{throw Error('Cannot reach the server. Check that it is running, then try again.');}let data={};try{data=await r.json();}catch{}if(!r.ok){if(r.status===401&&location.pathname!=='/login.html')redirectToAdminLogin();throw Error(data.error||'Request failed ('+r.status+')');}return data;}
let toastTimer;
function message(text,error=false){const el=$('#message');if(!el)return;el.hidden=false;el.className='notice '+(error?'error':'success');el.textContent=text;el.setAttribute('role',error?'alert':'status');if(document.body.classList.contains('admin-app')){el.classList.add('toast');el.title='Click to dismiss';el.onclick=()=>{el.hidden=true;};clearTimeout(toastTimer);toastTimer=setTimeout(()=>{el.hidden=true;},error?9000:4000);}else el.scrollIntoView({block:'nearest',behavior:'smooth'});}
function imageMarkup(src,name){return src?`<img src="${esc(src)}" alt="${esc(name)}" loading="lazy">`:'<div class="placeholder" aria-label="No product image">◇</div>';}
async function branding(){const s=await api('/api/settings');document.querySelectorAll('[data-brand]').forEach(el=>el.textContent=s.name);document.querySelectorAll('[data-footer]').forEach(el=>el.textContent=[s.footer,s.phone,s.email,s.address].filter(Boolean).join(' · '));if($('.brand'))$('.brand').innerHTML=storeBrandMarkup(s);return s;}
const adminPage=document.documentElement.hasAttribute('data-admin');
let adminCheck,adminExpiry,adminLeaving=false,adminSignedOut=false;
const logoutSignal='wb-admin-logout';

function hideAdmin(){
 document.documentElement.removeAttribute('data-admin-ready');
}

function redirectToAdminLogin(){
 adminSignedOut=true;
 hideAdmin();
 clearTimeout(adminExpiry);
 csrf='';
 location.replace('/login.html');
}

function checkAdminSession(){
 if(!adminCheck){
  adminCheck=api('/api/session').then(session=>{
   if(adminSignedOut)throw Error('Please log in');
   csrf=session.csrf;
   document.documentElement.removeAttribute('data-admin-unreachable');
   clearTimeout(adminExpiry);
   adminExpiry=setTimeout(()=>{
    hideAdmin();
    checkAdminSession().catch(()=>{});
   },Math.max(1,session.expiresIn));
   if(!adminLeaving&&document.visibilityState==='visible')document.documentElement.setAttribute('data-admin-ready','');
  }).catch(error=>{
   hideAdmin();
   if(!adminSignedOut)document.documentElement.setAttribute('data-admin-unreachable','');
   throw error;
  }).finally(()=>{adminCheck=null;});
 }
 return adminCheck;
}

async function protect(){
 if(!csrf)await checkAdminSession();
}

if(adminPage){
 document.addEventListener('DOMContentLoaded',()=>{
  protect().catch(()=>{});
  $('#logout')?.addEventListener('click',async event=>{
   const button=event.currentTarget;
   button.disabled=true;
   try{
    await api('/api/logout',{method:'POST'});
    try{localStorage.setItem(logoutSignal,String(Date.now()));}catch{}
    redirectToAdminLogin();
   }catch(error){message(error.message,true);button.disabled=false;}
  });
 });
 window.addEventListener('storage',event=>{
  if(event.key===logoutSignal)redirectToAdminLogin();
 });
 window.addEventListener('pagehide',()=>{
  adminLeaving=true;
  hideAdmin();
 });
 window.addEventListener('pageshow',event=>{
  adminLeaving=false;
  if(event.persisted&&!adminSignedOut)checkAdminSession().catch(()=>{});
 });
 function recheckVisibleAdmin(){
  if(document.visibilityState==='visible'&&!adminLeaving&&!adminSignedOut)checkAdminSession().catch(()=>{});
 }
 document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='hidden')hideAdmin();
  else recheckVisibleAdmin();
 });
 window.addEventListener('online',recheckVisibleAdmin);
}

const storefrontTabTitle=document.querySelector('meta[name="store-tab-title"]')?.content;
function formObject(form){return Object.fromEntries(new FormData(form));}

window.addEventListener('storage',e=>{if(e.key==='wb-theme-published'&&!new URLSearchParams(location.search).has('preview')&&!document.body.classList.contains('admin-app'))location.reload();});

// Site Settings owns branding once it has been saved. Legacy theme logos remain until then.
function storeBrandSettings(settings,theme={}){return {...settings,logo:settings.brandingManaged?settings.logo:(theme.logo??settings.logo),logoWidth:settings.logoWidth||theme.logoWidth||140,logoMobileWidth:settings.logoMobileWidth||100};}
function storeBrandMarkup(settings,theme={}){const s=storeBrandSettings(settings,theme),width=Math.max(60,Math.min(320,Number(s.logoWidth)||140)),mobile=Math.max(40,Math.min(180,Number(s.logoMobileWidth)||100));return `<span class="store-branding" style="--logo-width:${width}px;--logo-mobile-width:${mobile}px">${s.logo?`<img src="${esc(s.logo)}" alt="${esc(s.name)}">`:''}${!s.logo||s.showStoreName?`<span>${esc(s.name)}</span>`:''}</span>`;}
const brandStyle=document.createElement('style');brandStyle.textContent='.store-branding{display:flex;flex-direction:column;gap:5px;align-items:flex-start;max-width:100%;overflow-wrap:anywhere}.store-branding img{display:block!important;width:var(--logo-width)!important;max-width:100%!important;height:auto!important;max-height:160px!important;object-fit:contain!important}.header-inner>.logo{max-width:320px;flex-shrink:0}.store-branding>span{max-width:320px}@media(max-width:700px){.store-branding img{width:var(--logo-mobile-width)!important;max-height:100px!important}.header-inner>.logo{max-width:180px;flex-shrink:1}.store-branding>span{max-width:180px}}';document.head.append(brandStyle);

if(window.parent!==window&&new URLSearchParams(location.search).get('studio')==='1'){document.addEventListener('DOMContentLoaded',()=>{const s=document.createElement('script');s.src='/studio-canvas.js?v=82';document.body.append(s);});}
