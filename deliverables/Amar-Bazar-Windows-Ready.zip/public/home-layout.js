/* One layout model for the editor, preview and live store. */
(function(root){
 function normalizeHomeLayout(theme){
  if(theme.layoutRevision===2&&Array.isArray(theme.homepageLayout))return theme.homepageLayout;
  const base=theme.homepageLayout||[['hero','Main banners'],['categories','Featured Categories'],['top','Featured Products'],['brands','Our Brands'],['collections','Collections'],['recommendations','Just For You'],['reviews','Customer Reviews']].map(([kind,title])=>({id:'home-'+kind,kind,title,text:'',enabled:true,limit:kind==='top'?4:10,columns:5,mobileColumns:2,ids:[],category:''}));
  const layout=structuredClone(base);
  // Preserve older sections as independently editable blocks, rather than silently ignoring them.
  for(const old of theme.sections||[]){
   if(['banner','categories'].includes(old.type))continue;
   const id='legacy-'+old.id;if(layout.some(s=>s.id===id))continue;
   if(['slideshow','image-carousel','reviews'].includes(old.type)){
    layout.push({id,kind:old.type==='reviews'?'review-list':'image-list',title:old.title,text:old.subtitle||'',enabled:old.enabled,limit:old.limit||10,columns:old.columns||4,mobileColumns:old.mobileColumns||2,ids:[],category:'',items:structuredClone(old.items||[]),autoplay:!!old.autoplay,interval:old.interval||5});continue;
   }
   layout.push({id,kind:'products',title:old.title,text:old.subtitle||'',enabled:old.enabled,limit:old.limit||8,columns:old.columns||4,mobileColumns:old.mobileColumns||2,ids:structuredClone(old.ids||[]),category:old.category||'',source:old.type,mode:old.mode||'auto',autoplay:old.layout==='slider',background:old.background||'#ffffff',backgroundMode:'solid',spacing:old.spacing??24});
  }
  theme.homepageLayout=layout;theme.layoutRevision=2;return layout;
 }
 root.normalizeHomeLayout=normalizeHomeLayout;
 if(typeof module!=='undefined')module.exports={normalizeHomeLayout};
})(typeof window==='undefined'?globalThis:window);
