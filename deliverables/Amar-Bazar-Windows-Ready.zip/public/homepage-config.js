// Optional homepage-only content. Uploaded image paths look like /uploads/filename.jpg.
// Empty arrays use existing Theme Studio banners, categories and genuine product data.
window.HOME_CONFIG={slideSeconds:5,brands:[],banners:[],promoImage:'',reviews:[],categoryImages:{}};
// banners: [{image:'/uploads/banner.jpg',title:'Your headline',subtitle:'Your text',href:'/collection.html'}]
// brands: [{name:'Your brand',image:'/uploads/logo.png',href:'/collection.html'}]
// reviews: [{name:'Actual customer',text:'Their genuine feedback',rating:5}]
