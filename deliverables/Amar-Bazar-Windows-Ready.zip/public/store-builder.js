function homeLayoutSetting(kind){return homeTheme?.homepageLayout?.find(s=>s.kind===kind)||{};}
function builderProducts(s){
 const all=homeData.products,manual=(s.ids||[]).map(id=>all.find(p=>p.id===id)).filter(Boolean),source=s.source||s.kind;let list=[...all];
 if(['manual','featured','custom'].includes(source)||s.mode==='manual')list=manual;
 else {if(source==='new')list.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));if(source==='sale')list=list.filter(p=>p.variants.some(v=>v.compareAt>v.price));if(source==='hot')list=list.filter(p=>p.badges?.some(b=>/hot/i.test(b))||p.sold>=homeTheme.hotThreshold);if(source==='best')list=list.filter(p=>p.sold>0).sort((a,b)=>b.sold-a.sold);if(manual.length)list=s.mode==='both'?[...manual,...list]:manual;}
 if(s.category){const cat=homeTheme.categories.find(c=>c.id===s.category);const ids=new Set(cat?categoryProducts(cat).map(p=>p.id):[]);list=list.filter(p=>ids.has(p.id));}
 return [...new Map(list.map(p=>[p.id,p])).values()].slice(0,s.limit||10);
}
function applyBuilderStyle(el,s){
 const color=(x,fallback)=>/^#[0-9a-f]{6}$/i.test(x||'')?x:fallback;
 const bg=color(s.background,s.kind==='timer'?'#fff1df':'#ffffff'),end=color(s.gradientEnd,'#ffdda6');
 el.style.background=s.backgroundMode==='gradient'?`linear-gradient(${Number.isInteger(s.gradientAngle)?s.gradientAngle:135}deg, ${bg}, ${end})`:s.background||s.kind==='timer'?bg:'';
 el.style.color=color(s.textColor,'#203c33');if(s.background||s.backgroundMode==='gradient'||s.kind==='timer')el.classList.add('builder-styled');
 el.style.setProperty('--section-columns',s.columns);el.style.setProperty('--section-mobile',s.mobileColumns);
}
function applyStoreBuilder(){
 if(!['/','/index.html'].includes(location.pathname))return;
 const layout=normalizeHomeLayout(homeTheme),main=$('main.wrap'),map={hero:'hero',categories:'featured-categories',top:'top-products',brands:'brands',collections:'collections',recommendations:'recommendations',reviews:'reviews'};
 main.querySelectorAll('[data-custom-builder]').forEach(e=>e.remove());Object.values(map).forEach(id=>{const el=$('#'+id);el.hidden=true;delete el.dataset.sectionId;el.classList.remove('builder-styled','builder-columns');});
 for(const s of layout){if(!s.enabled){if(new URLSearchParams(location.search).has('studio')){const ghost=document.createElement('section');ghost.dataset.customBuilder='true';ghost.dataset.sectionId=s.id;ghost.className='studio-hidden';ghost.textContent=(s.title||s.kind)+' · Hidden on live site';main.append(ghost);}continue;}const el=map[s.kind]?$('#'+map[s.kind]):document.createElement('section');if(!map[s.kind]){el.dataset.customBuilder='true';el.className='builder-store-section';}el.hidden=false;el.dataset.sectionId=s.id;
 if(!map[s.kind]||s.visualConfigured&&['top','recommendations'].includes(s.kind)||s.items&&['brands','categories','reviews'].includes(s.kind)){
 let body='';if(s.kind==='special-products'){const list=builderProducts({...s,limit:s.limit===2?2:4});body=`<div class="special-product-grid">${list.map(p=>card(p,true)).join('')||'<p class="empty">Select products using this section’s edit button.</p>'}</div>`;el.classList.add('special-products-section');}else if(['products','hot','best','top','recommendations'].includes(s.kind)){const list=builderProducts(s);body=`<div class="product-grid ${(s.layout?s.layout==='carousel':s.autoplay!==false)?'product-track':''}">${list.map(p=>card(p)).join('')||'<p class="empty">No matching products yet.</p>'}</div>`;}
 else if(s.kind==='image-banner'){const href=s.href?esc(safeLink(s.href)):'';const img=s.image?`<img src="${esc(s.image)}" alt="${esc(s.title||'Promotional banner')}" loading="lazy" style="${s.bannerHeight?'height:'+Math.min(900,Math.max(0,Number(s.bannerHeight)||0))+'px;':''}object-fit:${s.fit==='contain'?'contain':'cover'}">`:'<p class="empty">Upload an image in Theme Studio to show this banner.</p>';body=`<div class="wb-wide-image">${href?`<a href="${href}">${img}</a>`:img}</div>`;el.classList.add('wb-image-banner');}
 else if(s.kind==='banner')body=s.image?`<a href="${esc(safeLink(s.href))}"><img class="builder-banner-image" src="${esc(s.image)}" alt="${esc(s.title)}"></a>`:'<p class="empty">Add a banner image in Theme Studio.</p>';
 else if(s.kind==='timer')body='<strong class="builder-countdown" role="timer" aria-label="Time remaining"></strong>';
 else if(['image-list','brands','categories'].includes(s.kind))body=builderMedia(s);
 else if(['review-list','reviews'].includes(s.kind))body=`<div class="review-track">${(s.items||[]).slice(0,s.limit).map((i,n)=>`<article class="review"><p data-review-field="text" data-review-index="${n}">${esc(i.text)}</p><div class="stars">${'★'.repeat(i.rating||5)}</div><strong data-review-field="name" data-review-index="${n}">${esc(i.name)}</strong></article>`).join('')}</div>`;
 el.innerHTML=s.kind==='image-banner'?body:`<div class="section-head"><h2 data-builder-edit="title">${esc(s.title)}</h2></div><p data-builder-edit="text">${esc(s.text)}</p>${body}`;
 if(s.kind==='announcement'){
  el.classList.add('builder-announcement');
  const headline=el.querySelector('[data-builder-edit="title"]');
  const description=el.querySelector('[data-builder-edit="text"]');
  // Keep the original editable nodes for Theme Studio; visually hide them.
  if(headline)headline.classList.add('marquee-source');
  if(description)description.classList.add('marquee-source');
  const message=[s.title,s.text].filter(Boolean).join('  ✦  ')||'Welcome to our store';
  const belt=document.createElement('div');belt.className='announcement-marquee';
  belt.setAttribute('aria-label',message);
  const track=document.createElement('div');track.className='announcement-marquee-track';
  for(let i=0;i<2;i++){
    const segment=document.createElement('div');segment.className='announcement-marquee-segment';
    segment.setAttribute('aria-hidden','true');
    for(let j=0;j<4;j++){
      const item=document.createElement('span');item.textContent=message;segment.append(item);
    }
    track.append(segment);
  }
  belt.append(track);el.append(belt);
 }if(s.kind==='timer'){
  const update=()=>{const end=s.end&&!/(Z|[+-]\d\d:\d\d)$/.test(s.end)?s.end+'+06:00':s.end,ms=Date.parse(end)-Date.now();el.querySelector('.builder-countdown').textContent=!Number.isFinite(ms)?'Choose an offer end time':ms<=0?'Offer ended':`${Math.floor(ms/86400000)}d ${Math.floor(ms/3600000)%24}h ${Math.floor(ms/60000)%60}m ${Math.floor(ms/1000)%60}s`;};update();homeTimers.push(setInterval(update,1000));
 }
 }else{
  el.querySelectorAll('[data-builder-heading],[data-builder-description]').forEach(n=>n.remove());
  let heading=['hero','collections','reviews'].includes(s.kind)?null:el.querySelector('h2');
  if(!heading&&s.title){const container=document.createElement('div');container.className='section-head';container.dataset.builderHeading='';heading=document.createElement('h2');container.append(heading);el.prepend(container);}
  if(heading){heading.textContent=s.title;heading.dataset.builderEdit='title';}
  if(s.text||new URLSearchParams(location.search).has('studio')){const desc=document.createElement('p');desc.dataset.builderEdit='text';desc.dataset.builderDescription='';desc.textContent=s.text;(heading?.parentElement||el).after(desc);if(!el.contains(desc))el.prepend(desc);}
  const selector={brands:'.brand-tile',reviews:'.review',categories:'.category-card',top:'.product',recommendations:'.product',collections:':scope>.collection'}[s.kind];if(selector)el.querySelectorAll(selector).forEach((item,i)=>item.hidden=i>=s.limit);
 }
 if(s.kind==='hero'){const heading=el.querySelector('#banner-slide h1'),text=el.querySelector('#banner-slide p'),side=el.querySelector('#side-banner h2');for(const [node,key]of [[heading,'heroTitle'],[text,'heroText'],[side,'sideTitle']])if(node){if(s[key]!==undefined)node.textContent=s[key];node.dataset.heroEdit=key;}}
 applyBuilderStyle(el,s);applyHeadlineStyle(el,s);el.classList.add('builder-columns');main.append(el);
 if(!map[s.kind]||s.items||s.visualConfigured)el.querySelectorAll('.product-track,.builder-image-track,.review-track').forEach(track=>{carousel(track,s.interval||5,s.autoplay!==false);});
 if(new URLSearchParams(location.search).has('preview')&&!new URLSearchParams(location.search).has('studio'))el.querySelectorAll('[data-builder-edit]').forEach(text=>{text.contentEditable='true';text.title='Click to edit';text.onblur=()=>parent.postMessage({type:'builder-edit',id:s.id,field:text.dataset.builderEdit,value:text.textContent},location.origin);});
 }
}
window.addEventListener('message',e=>{if(e.origin!==location.origin||e.source!==parent||!new URLSearchParams(location.search).has('preview')||e.data?.type!=='flush-edits')return;document.querySelectorAll('[contenteditable="true"]').forEach(el=>el.blur());parent.postMessage({type:'edits-flushed',token:e.data.token},location.origin);});

function builderMedia(s){const layout=s.layout||'carousel',purpose=s.purpose||s.kind,items=(s.items||[]).slice(0,s.limit),isLogo=['brands','categories'].includes(purpose);return `<div class="builder-media ${layout==='grid'?'media-grid':'builder-image-track'} ${layout==='slideshow'?'media-slideshow':''} ${isLogo?'media-logos':''}">${items.map((i,n)=>`<a href="${esc(safeLink(i.href))}">${i.image?`<img src="${esc(i.image)}" alt="${esc(i.title)}">`:'<span class="media-placeholder">◇</span>'}<span data-item-title="${n}">${esc(i.title)}</span></a>`).join('')||'<p class="empty">Add images or logos using this section’s edit button.</p>'}</div>`;}

function applyHeadlineStyle(el,s){el.dataset.titleAlign=s.titleAlign||'';el.dataset.titleSize=s.titleSize||'';el.querySelectorAll('[data-builder-edit="title"],[data-hero-edit="heroTitle"],[data-hero-edit="sideTitle"]').forEach(h=>{h.style.textAlign=s.titleAlign||'';h.style.fontSize=s.titleSize?s.titleSize+'px':'';h.style.overflowWrap='anywhere';if(h.parentElement.classList.contains('section-head')){h.style.flex='1';h.style.minWidth='0';}});}
window.addEventListener('message',async e=>{if(e.origin!==location.origin||e.source!==parent||e.data?.type!=='studio-refresh-products'||new URLSearchParams(location.search).get('studio')!=='1')return;try{homeData.products=(await api('/api/experience')).products;renderHome();}catch(err){message(err.message,true);}});
