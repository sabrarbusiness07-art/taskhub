(() => {
  'use strict';

  const params = new URLSearchParams(location.search);
  if (window.top !== window || params.has('preview') || params.has('studio')) return;
  if (navigator.doNotTrack === '1' || navigator.globalPrivacyControl === true) return;

  const storageKey = 'wb-traffic-visitor';
  const idleLimit = 30 * 60 * 1000;
  const makeId = () => {
    const hex = Array.from(crypto.getRandomValues(new Uint8Array(16)), byte =>
      byte.toString(16).padStart(2, '0')
    ).join('');
    return hex.slice(0, 8)+'-'+hex.slice(8, 12)+'-'+hex.slice(12, 16)+'-'+hex.slice(16, 20)+'-'+hex.slice(20);
  };

  let visitor = makeId(), visitorSeen = 0, viewed = false, timer;
  function visitorId() {
    const now = Date.now();
    if (visitorSeen && now - visitorSeen >= idleLimit) visitor = makeId();
    visitorSeen = now;
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
      if (saved && typeof saved.id === 'string' && now - saved.time < idleLimit) visitor = saved.id;
      localStorage.setItem(storageKey, JSON.stringify({ id: visitor, time: now }));
    } catch {}
    return visitor;
  }

  function send(event) {
    const page = location.pathname.toLowerCase().replace(/\/$/, '') || '/';
    fetch('/api/storefront-traffic', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        visitor: visitorId(), page, event,
        product: page === '/product.html' ? params.get('id') : undefined
      }),
      keepalive: true
    }).catch(() => {});
  }

  function updatePresence() {
    clearInterval(timer);
    if (document.visibilityState !== 'visible') return;
    send(viewed ? 'heartbeat' : 'view');
    viewed = true;
    timer = setInterval(() => send('heartbeat'), 60000);
  }

  document.addEventListener('visibilitychange', updatePresence);
  window.addEventListener('pagehide', () => clearInterval(timer));
  window.addEventListener('pageshow', event => { if (event.persisted) updatePresence(); });
  updatePresence();
})();
