// LEFT: add as many banner images as you want. Empty = existing published banners.
// RIGHT: one fixed image; it never changes with the left slideshow.
window.HOME_BANNERS = {
  seconds: 5,
  slides: [
    // { image: '/uploads/banner-1.jpg', href: '/collection.html', alt: 'First offer' },
    // { image: '/uploads/banner-2.jpg', href: '/collection.html', alt: 'Second offer' }
  ],
  right: {
    image: '', // Example: '/uploads/right-banner.jpg'
    href: '/collection.html',
    alt: 'Featured collection'
  }
};
