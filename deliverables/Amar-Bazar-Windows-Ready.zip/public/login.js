branding().catch(e=>message(e.message,true));
$('#login').addEventListener('submit',async e=>{e.preventDefault();const button=e.target.querySelector('button');button.disabled=true;try{await api('/api/login',{method:'POST',body:formObject(e.target)});location.replace('/admin.html');}catch(err){message(err.message,true);}finally{button.disabled=false;}});
