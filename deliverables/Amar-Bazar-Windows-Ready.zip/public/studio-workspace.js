(()=>{
 const pane=document.querySelector('.studio>section'),details=[...pane.children].filter(e=>e.tagName==='DETAILS');
 for(const d of details){const title=d.querySelector('summary').textContent;d.dataset.toolGroup=/Header|Logo/.test(title)?'design':/banners|Information/.test(title)?'content':/Legacy/.test(title)?'advanced':'layout';if(/Categories/.test(title))d.dataset.toolGroup='hidden';}
 const categoryLink=document.createElement('a');categoryLink.className='studio-category-link';categoryLink.href='/categories.html';categoryLink.textContent='Manage categories & subcategories ↗';pane.querySelector('.studio-tip').after(categoryLink);
 function tab(name){for(const d of details)d.hidden=d.dataset.toolGroup!==name;document.querySelectorAll('[data-studio-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.studioTab===name)));}
 document.querySelectorAll('[data-studio-tab]').forEach(b=>b.onclick=()=>tab(b.dataset.studioTab));tab('layout');
 const actions=document.querySelector('main>.actions');actions.classList.add('studio-savebar');
 const advanced=document.createElement('details');advanced.className='studio-more';advanced.innerHTML='<summary>More actions</summary>';for(const id of ['market-preset','reset-theme','restore-theme'])advanced.append(document.getElementById(id));actions.append(advanced);
 const pages=document.querySelector('#template');pages.addEventListener('change',()=>{const home=pages.value==='home';const builder=details.find(d=>d.textContent.includes('Homepage section builder'));if(builder)builder.hidden=!home;});
})();
