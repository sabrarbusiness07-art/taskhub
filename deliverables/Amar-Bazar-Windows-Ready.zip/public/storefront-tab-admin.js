(() => {
  'use strict';

  const params = new URLSearchParams(location.search);
  if (params.get('view') !== 'settings') return;

  const form = document.querySelector('#storefront-tab-form');
  const fields = form.elements;
  const button = form.querySelector('button');
  const preview = form.querySelector('#store-tab-preview');
  let settings;

  function render() {
    fields.title.value = settings.title;
    fields.iconFile.value = '';
    fields.removeIcon.checked = false;
    fields.removeIcon.disabled = !settings.icon;
    preview.hidden = !settings.icon;
    if (settings.icon) preview.src = settings.icon;
    else preview.removeAttribute('src');
  }

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!settings) return;
    button.disabled = true;
    try {
      let icon = fields.removeIcon.checked ? '' : settings.icon;
      const file = fields.iconFile.files[0];
      if (file) {
        const upload = new FormData();
        upload.append('image', file);
        icon = (await api('/api/admin/tab-icon', { method: 'POST', body: upload })).image;
      }
      settings = await api('/api/admin/storefront-tab', {
        method: 'PUT',
        body: { title: fields.title.value, icon }
      });
      render();
      message('Browser tab settings saved.');
    } catch (error) {
      message(error.message, true);
    } finally {
      button.disabled = false;
    }
  });

  fields.removeIcon.addEventListener('change', () => {
    if (fields.removeIcon.checked) fields.iconFile.value = '';
  });
  fields.iconFile.addEventListener('change', () => {
    if (fields.iconFile.files.length) fields.removeIcon.checked = false;
  });

  (async () => {
    try {
      await protect();
      settings = await api('/api/admin/storefront-tab');
      render();
      button.disabled = false;
    } catch (error) {
      message(error.message, true);
    }
  })();
})();
