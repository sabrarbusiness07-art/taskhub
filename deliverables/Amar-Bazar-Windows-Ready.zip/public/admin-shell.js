// Admin shell: top bar + grouped sidebar shared by every admin page.
(()=>{
const ICONS={
 home:'M3 10 12 3l9 7v11h-6v-7H9v7H3Z',
 orders:'M6 3h12v18H6ZM9 8h6M9 12h6M9 16h4',
 products:'m3 3 9 0 9 9-9 9-9-9ZM7 7h.01',
 customers:'M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0M4 21v-2a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v2',
 discount:'M4 4h8l8 8-8 8-8-8ZM8.5 8.5h.01',
 gift:'M3 8h18v4H3ZM5 12v9h14v-9M12 8v13M12 8c-2 0-4-1-4-3s3-2 4 1c1-3 4-3 4-1s-2 3-4 3',
 collection:'M3 4h7v7H3ZM14 4h7v7h-7ZM3 14h7v7H3ZM14 14h7v7h-7Z',
 box:'M21 8 12 3 3 8v8l9 5 9-5ZM3 8l9 5 9-5M12 13v8',
 truck:'M2 6h11v10H2ZM13 9h5l4 4v3h-9ZM6 17.5h.01M17 17.5h.01',
 swap:'M7 7h13l-3-3M17 17H4l3 3',
 theme:'M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2s0-2 1.5-2h2a3 3 0 0 0 3-3 9 9 0 0 0-8-11ZM7.5 11h.01M10 7h.01M15 7h.01',
 badge:'m12 2 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z',
 doc:'M6 3h9l4 4v14H6ZM14 3v5h5M9 13h6M9 17h6',
 link:'M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1',
 image:'M3 4h18v16H3ZM3 16l5-5 4 4 3-3 6 6M8.5 8.5h.01',
 chart:'M4 20V10M10 20V4M16 20v-8M22 20H2',
 globe:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18ZM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
 card:'M2 6h20v12H2ZM2 10h20M6 15h4',
 settings:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2',
 external:'M14 3h7v7M21 3l-11 11M10 3H3v18h18v-7'
};
const icon=k=>`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${ICONS[k]||ICONS.home}"/></svg>`;
const S='/admin-suite.html?tab=';
// [group label, [[title, url, icon], ...]]
const GROUPS=[
 ['',[['Home','/admin.html','home']]],
 ['Sales',[['Orders','/admin.html?view=orders','orders'],['Customers',S+'customers','customers'],['Discounts',S+'discounts','discount'],['Gift cards',S+'giftcards','gift']]],
 ['Catalog',[['Products','/admin-products.html','products'],['Categories','/categories.html','collection'],['Collections',S+'collections','collection'],['Inventory',S+'inventory','box'],['Purchase orders',S+'purchase','truck'],['Transfers',S+'transfer','swap']]],
 ['Online store',[['Theme editor','/theme-editor.html','theme'],['Badges & sale prices','/merchandising.html','badge'],['Content',S+'content','doc'],['Menus',S+'menus','link'],['Files',S+'files','image']]],
 ['Insights',[['Live Analytics',S+'live','chart'],['Analytics',S+'analytics','chart'],['Reports',S+'reports','chart'],['Growth',S+'growth','chart']]],
 ['Settings',[['Store settings','/admin-products.html?view=settings','settings'],['Markets',S+'markets','globe'],['Payments & couriers',S+'payments','card'],['Reset store','/admin-reset.html','settings']]]
];
const params=new URLSearchParams(location.search);
const view=params.get('view')||'',tab=params.get('tab')||'',path=location.pathname.replace(/\/$/,'')||'/';
const onProducts=path.includes('admin-products');
// An item is "current" when the path matches and its tab/view (if it has one) matches too.
function isCurrent(url){
 const u=new URL(url,location.origin);if(u.pathname!==path)return false;
 const t=u.searchParams.get('tab'),v=u.searchParams.get('view');
 if(path.endsWith('admin-suite.html'))return t===(tab||'analytics');
 return v?v===view:!view;
}
const topbar=$('.topbar');
if(topbar)topbar.innerHTML=`<nav class="admin-top"><button id="menu-toggle" class="icon-button" aria-label="Toggle navigation" aria-expanded="false" aria-controls="admin-sidebar" type="button">☰</button><a class="admin-wordmark" href="/admin.html"><span class="brand-mark">w</span> <span data-brand>Web Bazar</span></a><form id="global-search" role="search"><label class="sr-only" for="global-q">Search products</label><input id="global-q" placeholder="Search products…  (press / to focus)" autocomplete="off"><kbd>↵</kbd></form><a class="store-shortcut" href="/" target="_blank" rel="noopener">View store ↗</a><button id="logout" class="admin-account" title="Log out" type="button">Log out</button></nav>`;
const sidebar=document.createElement('aside');sidebar.className='admin-sidebar';sidebar.id='admin-sidebar';
sidebar.innerHTML=`<div class="workspace-label"><span class="workspace-avatar">W</span><div><strong data-brand>Web Bazar</strong><small>Merchant workspace</small></div></div><nav aria-label="Admin navigation">${GROUPS.map(([label,items])=>`${label?`<p class="sidebar-label">${label.toUpperCase()}</p>`:''}${items.map(([title,url,i])=>{const cur=isCurrent(url);return `<a href="${url}" class="side-link${cur?' current':''}"${cur?' aria-current="page"':''}>${icon(i)}<span>${title}</span></a>`;}).join('')}`).join('')}<a href="/" target="_blank" rel="noopener" class="side-link side-external">${icon('external')}<span>Open online store</span></a></nav><div class="sidebar-bottom"><span class="live-dot"></span> Your store workspace<small>All amounts in BDT</small></div>`;
const scrim=document.createElement('div');scrim.className='admin-scrim';
document.body.append(sidebar,scrim);
const toggle=$('#menu-toggle');
function setNav(open){document.body.classList.toggle('nav-open',open);toggle?.setAttribute('aria-expanded',String(open));}
toggle?.addEventListener('click',()=>setNav(!document.body.classList.contains('nav-open')));
scrim.addEventListener('click',()=>setNav(false));
sidebar.addEventListener('click',e=>{if(e.target.closest('a'))setNav(false);});
$('#global-search')?.addEventListener('submit',e=>{e.preventDefault();location.href='/admin-products.html?q='+encodeURIComponent($('#global-q').value);});
const currentLink=sidebar.querySelector('.side-link.current span');
// Load the merchant's saved store name on every admin page, including Categories.
async function syncAdminBrand(){
 try{
  const response=await fetch('/api/settings',{credentials:'same-origin'});
  if(!response.ok) return;
  const settings=await response.json();
  const name=typeof settings.name==='string'&&settings.name.trim()?settings.name.trim():'Web Bazar';
  document.querySelectorAll('[data-brand]').forEach(el=>{el.textContent=name;});
  document.querySelectorAll('.workspace-avatar,.brand-mark').forEach(el=>{el.textContent=name.charAt(0).toUpperCase();});
  document.title=(currentLink?.textContent||'Admin')+' · '+name+' admin';
 }catch(err){console.warn('Store branding could not be loaded',err);}
}
syncAdminBrand();
// Pages that share one HTML file (orders vs overview, products vs settings) need the right heading.
if(onProducts&&view){for(const id of ['product-panel','editor'])$('#'+id).hidden=true;$('.import-note').hidden=true;$('.page-subtitle').textContent=view==='settings'?'Make this store your own.':'Manage how you accept payments and ship orders.';$('.container h1').textContent=view==='settings'?'Store settings':'Integrations';$('#settings-panel').hidden=view!=='settings';$('#integration-panel').hidden=view!=='integrations';}
else if(onProducts){$('#settings-panel').hidden=true;$('#integration-panel').hidden=true;}
if(path.endsWith('/admin.html')&&view==='orders'){$('.container h1').textContent='Orders';$('.eyebrow').textContent='SALES';$('#stats').hidden=true;$('#overview-panel').hidden=true;}
document.addEventListener('keydown',e=>{
 // "/" jumps to search unless the user is typing somewhere.
 const t=document.activeElement;
 if(e.key==='/'&&!e.ctrlKey&&!e.metaKey&&!/^(INPUT|TEXTAREA|SELECT)$/.test(t?.tagName||'')&&!t?.isContentEditable){const q=$('#global-q');if(q&&getComputedStyle(q).display!=='none'){e.preventDefault();q.focus();}}
 if(e.key==='Escape'){if(document.body.classList.contains('nav-open'))setNav(false);const editor=$('#editor');if(editor&&!editor.hidden){editor.hidden=true;$('#new-product')?.focus();}}
});
// Keep keyboard focus within the product editor while it is open.
document.addEventListener('keydown',e=>{const editor=$('#editor');if(e.key!=='Tab'||!editor||editor.hidden)return;const items=[...editor.querySelectorAll('button:not(:disabled),input:not([type="hidden"]):not(:disabled),select,textarea,a[href]')].filter(el=>el.getClientRects().length);const first=items[0],last=items.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}});
})();
