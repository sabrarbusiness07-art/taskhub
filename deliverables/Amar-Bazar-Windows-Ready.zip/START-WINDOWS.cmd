@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>&1
if errorlevel 1 (
    echo Install Node.js 24.14.0 or a newer 24.x version, then run this file again.
    pause
    exit /b 1
)
node.exe server.js
set "amar_exit=%errorlevel%"
if not "%amar_exit%"=="0" pause
exit /b %amar_exit%
