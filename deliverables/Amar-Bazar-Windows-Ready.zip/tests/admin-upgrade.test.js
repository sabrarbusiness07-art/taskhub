'use strict';

const assert = require('node:assert/strict');
const { randomUUID, scryptSync, createHash } = require('node:crypto');
const { mkdtempSync, rmSync } = require('node:fs');
const { createServer } = require('node:http');
const { tmpdir } = require('node:os');
const { join } = require('node:path');
const { test } = require('node:test');
const { createApp } = require('../application');

const email = 'test-admin@example.com';
const password = 'local-only-test-password';
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aN28AAAAASUVORK5CYII=', 'base64');

async function start(t) {
  const directory = mkdtempSync(join(tmpdir(), 'amar-bazar-test-'));
  const server = createServer();
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = 'http://127.0.0.1:'+server.address().port;
  const { app, store } = createApp({ origin: base, dataDir: directory, uploadDir: join(directory, 'uploads'), legacyFile: null });
  server.on('request', app);
  t.after(async () => {
    await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
    store.close();
    rmSync(directory, { recursive: true, force: true });
  });
  const salt = randomUUID();
  store.db.prepare('INSERT INTO admins VALUES(?,?,?)').run(email, salt, scryptSync(password, salt, 64).toString('hex'));

  function request(path, { method = 'GET', body, cookie, csrf } = {}) {
    const headers = { Origin: base };
    if (cookie) headers.Cookie = cookie;
    if (csrf) headers['X-CSRF-Token'] = csrf;
    if (body && !(body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(body);
    }
    return fetch(base + path, { method, headers, body, redirect: 'manual' });
  }

  async function login() {
    const response = await request('/api/login', { method: 'POST', body: { email, password } });
    assert.equal(response.status, 200);
    assert.match(response.headers.get('set-cookie'), /HttpOnly/);
    const cookie = response.headers.get('set-cookie').split(';')[0];
    return { cookie, csrf: (await response.json()).csrf };
  }

  return { request, login, store };
}

test('Admin documents and APIs require a valid current admin session', async t => {
  const { request, login, store } = await start(t);
  for (const page of ['/admin', '/admin.html', '/admin-products.html', '/invoice.html',
    '/theme-editor.html', '/merchandising.html', '/admin-suite.html', '/categories.html', '/admin-reset.html']) {
    const response = await request(page);
    assert.equal(response.status, 302, page);
    assert.equal(response.headers.get('location'), '/login.html');
    assert.match(response.headers.get('cache-control'), /no-store/);
    assert.doesNotMatch(await response.text(), /data-admin/);
  }
  assert.equal((await request('/api/admin/live-analytics')).status, 401);
  assert.equal((await request('/api/admin/storefront-tab')).status, 401);
  assert.equal((await request('/api/orders')).status, 401);
  assert.equal((await request('/api/login', { method: 'POST', body: { email, password: 'wrong-password' } })).status, 401);

  const legacy = randomUUID();
  const legacyHash = createHash('sha256').update(legacy).digest('hex');
  store.db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(legacyHash, 'legacy-csrf', Date.now()+60000);
  assert.equal((await request('/admin.html', { cookie: 'wb_session='+legacy })).status, 302);

  const session = await login();
  const admin = await request('/admin-products.html?view=settings', session);
  assert.equal(admin.status, 200);
  assert.match(await admin.text(), /data-admin/);
  assert.match(admin.headers.get('cache-control'), /private, no-store/);
  assert.match(admin.headers.get('vary'), /Cookie/i);
  assert.equal((await request('/api/session', session)).status, 200);

  assert.equal((await request('/api/logout', { ...session, method: 'POST' })).status, 200);
  assert.equal((await request('/admin.html', session)).status, 302);
  assert.equal((await request('/api/session', session)).status, 401);

  const expiring = await login();
  store.db.prepare('UPDATE sessions SET expires=0 WHERE csrf=?').run(expiring.csrf);
  assert.equal((await request('/admin.html', expiring)).status, 302);
  assert.equal((await request('/api/session', expiring)).status, 401);
});

test('Live analytics counts views and distinct visitors separately', async t => {
  const { request, login, store } = await start(t);
  const session = await login(), visitor = randomUUID();
  store.put('products', 'featured', { id: 'featured', name: 'Featured item', active: true });
  const send = (page, event, product, credentials) => request('/api/storefront-traffic', {
    ...credentials,
    method: 'POST',
    body: { visitor, page, event, product }
  });
  assert.equal((await send('/', 'view')).status, 204);
  assert.equal((await send('/index.html', 'view')).status, 204);
  assert.equal((await send('/product.html', 'view', 'featured')).status, 204);
  assert.equal((await send('/product.html', 'heartbeat')).status, 204);
  assert.equal((await send('/cart.html', 'view', undefined, session)).status, 204);
  assert.equal((await send('/admin.html', 'view')).status, 400);
  let data = await (await request('/api/admin/live-analytics', session)).json();
  assert.equal(data.visitors, 1);
  assert.equal(data.views, 3);
  assert.deepEqual(data.topPages, [{ name: 'Home', views: 2 }, { name: 'Product', views: 1 }]);
  assert.deepEqual(data.topProducts, [{ name: 'Featured item', views: 1 }]);
  assert.equal(data.timeZone, 'Asia/Dhaka');
  store.db.prepare('UPDATE storefront_presence SET last_seen=0').run();
  data = await (await request('/api/admin/live-analytics', session)).json();
  assert.equal(data.visitors, 0);
  assert.equal(data.views, 3);
});

test('Browser tab settings are protected, update public HTML, and can be cleared', async t => {
  const { request, login, store } = await start(t);
  const session = await login();
  const before = store.get('config', 'settings');
  const upload = new FormData();
  upload.append('image', new Blob([png], { type: 'image/png' }), 'favicon.png');
  const uploaded = await request('/api/admin/tab-icon', { ...session, method: 'POST', body: upload });
  assert.equal(uploaded.status, 201);
  const { image } = await uploaded.json();
  const icoHeader = Buffer.alloc(22);
  icoHeader.writeUInt16LE(1, 2);
  icoHeader.writeUInt16LE(1, 4);
  icoHeader[6] = 1;
  icoHeader[7] = 1;
  icoHeader.writeUInt16LE(1, 10);
  icoHeader.writeUInt16LE(32, 12);
  icoHeader.writeUInt32LE(png.length, 14);
  icoHeader.writeUInt32LE(icoHeader.length, 18);
  const ico = new FormData();
  ico.append('image', new Blob([icoHeader, png], { type: 'image/x-icon' }), 'favicon.ico');
  const icoUpload = await request('/api/admin/tab-icon', { ...session, method: 'POST', body: ico });
  assert.equal(icoUpload.status, 201);
  assert.match((await icoUpload.json()).image, /\.ico$/);
  const body = { title: 'Amar & Bazar <store>', icon: image };
  assert.equal((await request('/api/admin/storefront-tab', { cookie: session.cookie, method: 'PUT', body })).status, 403);
  assert.equal((await request('/api/admin/storefront-tab', { ...session, method: 'PUT', body })).status, 200);
  assert.deepEqual(store.get('config', 'settings'), before);
  const html = await (await request('/')).text();
  assert.match(html, /<title>Amar &amp; Bazar &lt;store&gt;<\/title>/);
  assert.ok(html.includes('rel="icon" href="'+image+'"'));
  assert.match((await request(image)).headers.get('content-type'), /image\/png/);
  assert.match(await (await request('/cart.html')).text(), /<title>Cart — Amar &amp; Bazar/);
  const invalid = await request('/api/admin/storefront-tab', { ...session, method: 'PUT', body: { ...body, icon: '/missing.ico' } });
  assert.equal(invalid.status, 400);
  assert.equal((await request('/api/admin/storefront-tab', { ...session, method: 'PUT', body: { title: '', icon: '' } })).status, 200);
  assert.doesNotMatch(await (await request('/')).text(), /store-tab-title|rel="icon"/);
});
