// Hosting bootstrap: preserve the original Amar Bazar application in application.js.
'use strict';
const path = require('node:path');
const fs = require('node:fs');
const Module = require('node:module');
const root = __dirname;
const candidatePaths = [
  path.join(root, 'node_modules'),
  path.join(process.env.HOME || '/home/kazicons', 'nodevenv', path.basename(root), '24', 'lib', 'node_modules'),
  '/home/kazicons/nodevenv/web-bazar-live/24/lib/node_modules'
];
const existing = candidatePaths.filter(p => fs.existsSync(p));
process.env.NODE_PATH = [...existing, process.env.NODE_PATH || ''].filter(Boolean).join(path.delimiter);
Module._initPaths();
try {
  console.log('Express module:', require.resolve('express'));
  const {createApp} = require('./application');
  const {app} = createApp();
  const port = process.env.PORT || 5000;
  const host = process.env.HOST || '127.0.0.1';
  app.listen(port, host, () => console.log('Amar Bazar started on port', port));
} catch (error) {
  console.error('AMAR_BAZAR_STARTUP_ERROR', error && error.stack || error);
  process.exitCode = 1;
}
