AMAR BAZAR ADMIN UPDATE — CPANEL

This update contains the application code. Use the existing live database,
uploaded images, environment variables and cPanel domain mapping.

1. Back up the existing application before uploading the update.
2. In cPanel Node.js App, stop Amar Bazar and extract this ZIP over the
   existing application root. server.js must remain at the application root.
   If your app uses Passenger, keep the existing Passenger configuration.
3. Move any old admin HTML files out of public/ into a backup outside
   the web root. The update serves these pages from the private admin/
   directory. The old files in public/ are admin.html, admin-products.html,
   invoice.html, theme-editor.html, merchandising.html, admin-suite.html,
   categories.html and admin-reset.html.
4. Keep the live data and upload directories in place. By default these are
   data/ and public/uploads/. If DATA_DIR or UPLOAD_DIR is configured, keep
   the existing locations. This update creates the analytics tables at startup.
5. Keep the current startup file (server.js), Node.js 24 and HTTPS PUBLIC_URL.
   Run npm install if the project's Node dependencies are not already present.
6. Restart the app. Existing admins will sign in once with their current
   credentials. Open a private browser window to check that /admin.html
   redirects to /login.html.

Insights > Live Analytics shows traffic collected after installation.
Settings > Store settings > Browser tab controls the favicon and title.
