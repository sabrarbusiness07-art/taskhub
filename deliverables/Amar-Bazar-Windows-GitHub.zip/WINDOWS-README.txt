AMAR BAZAR - WINDOWS PACKAGE

Requirements: Node.js 24.14.0 or a newer 24.x version.

1. Stop any older local server with Ctrl+C and extract this entire ZIP into a
   new folder.
2. Open the extracted folder in VS Code and open its PowerShell terminal.
3. Run npm.cmd run setup to create your local admin. Enter an email and a
   password of at least 12 characters, then confirm the password. This is a
   one-time step. The terminal hides password input.
4. Run npm.cmd start, or run node server.js directly.
5. Open http://localhost:5000/ for the storefront and
   http://localhost:5000/login.html for the Admin sign-in.

This package includes public store products, banners and images, and all the
Node.js libraries required to start. No npm install is required. Store
orders, customers, existing admin credentials and manual payment accounts
are excluded from this public copy. Use your private backup for those.
