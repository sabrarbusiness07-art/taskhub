// Hosting bootstrap: preserve the original Amar Bazar application in application.js.
'use strict';
const path = require('node:path');
const fs = require('node:fs');
const Module = require('node:module');
const root = __dirname;
const candidatePaths = [
  path.join(root, 'node_modules'),
  path.join(process.env.HOME || '/home/kazicons', 'nodevenv', path.basename(root), '24', 'lib', 'node_modules'),
  '/home/kazicons/nodevenv/web-bazar-live/24/lib/node_modules'
];
const existing = candidatePaths.filter(p => fs.existsSync(p));
process.env.NODE_PATH = [...existing, process.env.NODE_PATH || ''].filter(Boolean).join(path.delimiter);
Module._initPaths();
try {
  if (process.platform === 'win32') {
    const [major, minor] = process.versions.node.split('.').map(Number);
    if (major !== 24 || minor < 14) {
      throw new Error('This package needs Node.js 24.14.0 or later in the Node.js 24 series.');
    }
    const {dependencies} = require('./package.json');
    const missing = Object.keys(dependencies).filter(name =>
      !fs.existsSync(path.join(root, 'node_modules', name, 'package.json'))
    );
    if (missing.length) {
      throw new Error('Missing local packages: '+missing.join(', ')+
        '. Extract the entire Windows ZIP, or run npm.cmd ci in this project folder.');
    }
  }
  const {createApp} = require('./application');
  const {app} = createApp();
  const port = process.env.PORT || 5000;
  const host = process.env.HOST || '127.0.0.1';
  const listener = app.listen(port, host);
  listener.once('listening', () => console.log('Amar Bazar started on port', port));
  listener.once('error', error => {
    if (error.code === 'EADDRINUSE') {
      console.error('Port '+port+' is already in use. Stop the older Amar Bazar server and start this folder again.');
    } else {
      console.error('AMAR_BAZAR_STARTUP_ERROR', error);
    }
    process.exitCode = 1;
  });
} catch (error) {
  console.error('AMAR_BAZAR_STARTUP_ERROR', error && error.stack || error);
  process.exitCode = 1;
}
