export const stylesheet = "/storefront.8ff8b00cd8ab.css";
export const layout = "wm-efec02b90480";
