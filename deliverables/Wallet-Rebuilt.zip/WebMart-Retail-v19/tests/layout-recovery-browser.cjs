'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { chromium } = require('playwright');
const { createApp } = require('../application');

const assets = path.join(__dirname, '..', 'public');
const output = process.env.BROWSER_ARTIFACTS || path.join(os.tmpdir(), 'webmart-layout-recovery');

async function assertDesktop(page) {
  await page.locator('.rental-plan').first().waitFor();
  const layout = await page.evaluate(() => {
    const sidebar = document.querySelector('.commerce-header');
    const box = sidebar.getBoundingClientRect();
    return {
      position: getComputedStyle(sidebar).position,
      left: box.left,
      width: box.width,
      mobileMenuVisible: !!document.querySelector('#drawer-toggle').getClientRects().length,
      utilityVisible: !!document.querySelector('.commerce-utility').getClientRects().length,
      pricing: [...document.querySelectorAll('.rental-plan')].map(el => {
        const { top, height } = el.getBoundingClientRect();
        return { top, height };
      })
    };
  });
  assert.equal(layout.position, 'fixed');
  assert.ok(layout.left < 25 && layout.width < 270);
  assert.equal(layout.mobileMenuVisible, false);
  assert.equal(layout.utilityVisible, false);
  assert.equal(layout.pricing.length, 3);
  assert.ok(layout.pricing.every(card =>
    Math.abs(card.top - layout.pricing[0].top) < 1 && Math.abs(card.height - layout.pricing[0].height) < 1));
  assert.equal(await page.locator('head link[rel=stylesheet]').count(), 1);
}

(async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-layout-recovery-'));
  const uploads = path.join(directory, 'uploads');
  let browser, server, store;
  try {
    fs.mkdirSync(output, { recursive: true });
    const built = createApp({ dataDir: directory, uploadDir: uploads });
    store = built.store;
    server = built.app.listen(0, '127.0.0.1');
    await new Promise(resolve => server.once('listening', resolve));
    const base = 'http://127.0.0.1:' + server.address().port;

    // Use merchant-owned URLs and reordered sections without relying on release defaults.
    fs.copyFileSync(path.join(assets, 'assets', 'market', 'main-store.webp'), path.join(uploads, 'merchant-hero.webp'));
    const settings = store.get('config', 'settings');
    settings.heroSlides[0] = { image:'/uploads/merchant-hero.webp', alt:'Merchant homepage banner', href:'/shop' };
    store.put('config', 'settings', settings);
    const theme = store.get('config', 'site-live');
    const sections = theme.pages.home.sections;
    const productIndex = sections.findIndex(item => item.source === 'home-templates');
    const categoryIndex = sections.findIndex(item => item.source === 'home-featured');
    [sections[productIndex], sections[categoryIndex]] = [sections[categoryIndex], sections[productIndex]];
    theme.global.showAnnouncement = true;
    store.put('config', 'site-live', theme);

    const { stylesheet } = await import('../public/storefront-layout-v19.mjs');
    const css = fs.readFileSync(path.join(assets, stylesheet.slice(1)), 'utf8');
    const oldCss = css.split('/* graphite-v17.css */')[0];
    const stalePath = '/storefront.111111111111.css';
    const executablePath = process.env.BROWSER_EXECUTABLE || (fs.existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined);
    browser = await chromium.launch({ executablePath, args: ['--no-sandbox'] });

    const staleHtml = await browser.newPage({ viewport: { width:1366, height:900 } });
    await staleHtml.route(base + '/', async route => {
      const response = await route.fetch();
      const html = (await response.text()).replace(stylesheet, stalePath).replaceAll('?release=19', '');
      await route.fulfill({ response, body:html });
    });
    await staleHtml.route(base + stalePath, route => route.fulfill({ contentType:'text/css', body:oldCss }));
    await staleHtml.goto(base);
    await assertDesktop(staleHtml);
    await staleHtml.locator('.hero-slide:not([hidden]) img').evaluate(img => img.decode());
    const imageUrl = await staleHtml.locator('.hero-slide:not([hidden]) img').getAttribute('src');
    assert.equal(imageUrl, '/uploads/merchant-hero.webp');
    assert.equal(await staleHtml.locator('[data-cms-section]').evaluateAll(nodes =>
      nodes.findIndex(node => node.querySelector('[data-home-section=home-templates]')) <
      nodes.findIndex(node => node.querySelector('[data-home-section=home-featured]'))), true);
    await staleHtml.screenshot({ path:path.join(output, 'desktop-after-stale-html.png') });
    console.log('PASS stale HTML stylesheet repairs to left desktop navigation, aligned plans and published merchant content');

    const wrongBytes = await browser.newPage({ viewport:{ width:1024, height:900 } });
    let recoveredRequest = false;
    await wrongBytes.route(url => url.pathname === stylesheet, route => {
      if (!new URL(route.request().url()).search) return route.fulfill({ contentType:'text/css', body:oldCss });
      recoveredRequest = true;
      return route.continue();
    });
    await wrongBytes.goto(base);
    await assertDesktop(wrongBytes);
    assert.equal(recoveredRequest, true);
    await wrongBytes.locator('#rail-search').click();
    await wrongBytes.locator('#store-search').fill('Atlas');
    await wrongBytes.locator('#store-search').press('Enter');
    await wrongBytes.locator('.catalog-head').waitFor();
    assert.equal(await wrongBytes.locator('.commerce-card').count(), 1);
    console.log('PASS stale response at the current stylesheet URL is bypassed and compact sidebar search works');

    const outage = await browser.newPage({ viewport:{ width:1440, height:900 } });
    const broken = url => url.pathname === stylesheet;
    await outage.route(broken, route => route.abort());
    await outage.goto(base);
    await outage.locator('#retry-start').waitFor();
    assert.equal(await outage.locator('.commerce-header').count(), 0);
    await outage.unroute(broken);
    await outage.locator('#retry-start').click();
    await assertDesktop(outage);
    console.log('PASS missing stylesheet shows retry instead of a broken top bar and recovers when available');

    const mobile = await browser.newPage({ viewport:{ width:390, height:844 }, hasTouch:true, isMobile:true });
    await mobile.goto(base);
    await mobile.locator('#drawer-toggle').waitFor();
    assert.equal(await mobile.locator('#rail-toggle').isVisible(), false);
    await mobile.locator('#drawer-toggle').click();
    await mobile.locator('#navigation-drawer[open]').waitFor();
    await mobile.locator('#drawer-close').click();
    await mobile.locator('.mobile-bottom-nav').waitFor();
    console.log('PASS mobile keeps its drawer and bottom navigation');
  } finally {
    await browser?.close();
    if (server) await new Promise(resolve => server.close(resolve));
    store?.close();
    fs.rmSync(directory, { recursive:true, force:true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
