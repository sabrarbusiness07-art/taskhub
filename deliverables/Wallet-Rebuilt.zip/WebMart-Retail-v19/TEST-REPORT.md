# WebMart Retail v19 verification

Node 24.22.1, npm 11.9 and Chromium 156 were used with temporary databases.

- All 75 Node tests passed, including checkout/renewal, publication, migration and port conflict.
- 61 browser checks passed across customer commerce, mobile and editor, storefront, layout recovery and retail suites.
- Asset verification passed for the compiled storefront stylesheet, layout fingerprint, source syntax, seed media and compressed copies.
- Fresh ZIP extraction installed 73 production packages. Merchant setup and login, release health, compressed CSS, square sidebar, flat actions and desktop/mobile rendering passed. The extracted copy also passed all 75 Node tests.

The redesign checks the full-height sidebar in both widths, saved selection and submenu interactions, monthly/yearly selection, aligned cards, flat mobile navigation and live product previews. Network checks confirm one CSS request on home, no liquid or entrance-motion module requests and a single catalog list in the storefront data response. Existing API clients get the previous response shape unless they request the compact variant.

The upload contains prior generated styles and a separate glass sidebar override. The distribution regenerates current styles and removes the separate override. An older stylesheet response and missing stylesheet both have recovery tests. The release excludes user databases, credentials and uploads.
