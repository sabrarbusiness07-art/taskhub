# WebMart Retail v19 performance

The paired comparison ran in the same Chromium process with three fresh contexts per release and device. A warm run reloaded each context. Mobile used a 390px touch viewport, 4× CPU slowdown, 1.6 Mbps and 150ms configured latency. Values are medians from a local test with the bundled WebMart catalog.

| Session | v18 LCP | v19 LCP | v18 requests | v19 requests |
| --- | ---: | ---: | ---: | ---: |
| Desktop cold | 548 ms | 524 ms | 24 | 22 |
| Desktop warm | 216 ms | 140 ms | 24 | 22 |
| Mobile cold | 1820 ms | 1812 ms | 20 | 18 |
| Mobile warm | 1184 ms | 1144 ms | 23 | 21 |


The number of initial resources fell by two in each run. Mobile cold rendering was similar between releases. Desktop and mobile warm rendering improved in this sample. LCP tracks when the largest visible element appears. Measurements stop 600 ms after first banner decode and exclude the HTML bytes. Actual results depend on hosting, device and merchant media.

The storefront uses one fingerprinted Brotli/gzip stylesheet, early hero image loading, lazy product media and one serialized catalog list. Liquid-button and entrance-motion modules and their runtime effects are removed. Merchant styles and code load on demand.
