# WebMart Retail v19 — চালু ও আপডেট

Desktop-এ সোজা কোণের বাম sidebar। Toggle দিয়ে শুধু icon বা icon-এর সঙ্গে নাম দেখানো যায়। Mobile-এ solid header, drawer ও নিচের navigation আছে। Purchase button orange এবং browse করার controls slate ও সাদা।

## পুরোনো site আপডেট

আগের server বন্ধ করে পুরো folder backup রাখুন। নতুন ZIP আলাদা folder-এ extract করুন। আগের `data`, `public/uploads`, এবং থাকলে `public/media` নতুন folder-এর একই জায়গায় copy করুন। এগুলোতে account, product, ছবি, order, plan ও settings আছে। পুরোনো source বা node_modules copy করবেন না। নিজের DATA_DIR / UPLOAD_DIR ব্যবহার করলে সেই private settings বজায় রাখুন।

নতুন folder-এর PowerShell terminal-এ:

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

Website: http://localhost:5000
Admin: http://localhost:5000/admin

Terminal-এ `WebMart v19.0.0 is running` দেখা গেলে নতুন version চলছে। পুরোনো server ৫০০০ পোর্টে চালু থাকলে আগে সেটা বন্ধ করুন। Browser-এ http://localhost:5000/api/health খুলে `webmart-retail-19.0.0` মিলিয়ে নিতে পারেন।

আগের login ব্যবহার করুন। নতুন install হলে Node.js 24.x (24.14+) ব্যবহার করুন; start-এর আগে `npm.cmd run setup` দিয়ে নিজের merchant account তৈরি করুন। কোনো default password নেই। START-WEBMART.cmd দিয়েও চালানো যায়।

## কী পরিবর্তন হয়েছে

- Liquid glass, blur ও shine সরিয়ে solid retail controls দেওয়া হয়েছে।
- Pricing card একই মাপের। Monthly/Yearly বাছাই এবং hover state border ও রঙে বোঝা যায়।
- মূল slideshow ও দুইটি fixed promo আছে। Admin থেকে নিজের ছবি এবং destination বদলাতে পারবেন।
- Homepage একটিমাত্র compressed CSS নেয়। Button-এর liquid runtime এবং entrance animation বাদ গেছে।

## নিজের content সম্পাদনা

Admin → Store settings → Hero image slideshow থেকে slide/mobile image ও দুইটি promotional image, link, description, add/remove/reorder বদলান। Theme Studio থেকে page/section, drag ordering, menu/submenu, mobile quick links, SVG/custom icons, ছবি/text/video/date সম্পাদনা করুন। Products & services থেকে product/gallery, description, preview, private download, one-time price ও monthly/yearly plans দিন। Wishlist/cart/customer account ও analytics আছে। Payment যাচাই ও activation আপনার team করবে।

v16 প্রথমবার চালু হলে live/draft action accent graphite হয়। আগের theme/settings এবং database-এর private backup `data/backups` ও `*-before-v16` snapshots-এ থাকে। Customer, paid history ও নিজের uploaded hero/product ছবি মুছে যায় না। Public ZIP-এ private database, password, .env, backup ও customer uploads নেই।

Source CSS/MJS বদলালে `npm.cmd run build:assets` চালিয়ে server restart করুন। Bundle file সরাসরি edit করবেন না। বিস্তারিত README.md, RUN-AND-DEPLOY.md, TEST-REPORT.md-তে আছে।
