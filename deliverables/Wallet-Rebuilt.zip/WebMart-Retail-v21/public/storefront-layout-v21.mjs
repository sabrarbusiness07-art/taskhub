export const stylesheet = "/storefront.453862174ca1.css";
export const layout = "wm-68f83e21d492";
