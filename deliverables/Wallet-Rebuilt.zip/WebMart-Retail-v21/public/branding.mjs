export const defaultSidebarColor = '#1c2026';
export const defaultFavicon = '/assets/favicon.svg';

export function brandSettings(settings = {}) {
 const name = settings.name?.trim() || 'WebMart';
 return {
  name,
  logo: settings.logo || '',
  favicon: settings.favicon || settings.logo || defaultFavicon,
  tabTitle: settings.tabTitle?.trim() || '',
  sidebarColor: /^#[0-9a-f]{6}$/i.test(settings.sidebarColor) ? settings.sidebarColor : defaultSidebarColor
 };
}

export function browserTitle(settings, page = '', seoTitle = '') {
 const brand = brandSettings(settings);
 return brand.tabTitle || seoTitle || (page ? page + ' — ' + brand.name : brand.name);
}

export function applyBrowserBranding(settings, page = '', seoTitle = '') {
 document.title = browserTitle(settings, page, seoTitle);
 const icon = document.querySelector('#store-favicon');
 const href = brandSettings(settings).favicon;
 if (icon && icon.getAttribute('href') !== href) icon.setAttribute('href', href);
}

export function brandMarkup(settings, escape, href = '/') {
 const { name, logo } = brandSettings(settings);
 const source = logo || '/assets/brand-mark.svg';
 const label = href === '/admin' ? name + ' merchant workspace' : name + ' home';
 return `<a class="wordmark store-brand${logo?' store-brand-custom':''}" href="${href}" aria-label="${escape(label)}" title="${escape(name)}" data-no-content-edit>
 <span class="brand-symbol"><img class="brand-mark" src="${escape(source)}" alt="" width="40" height="40" decoding="async"></span><span class="store-brand-name">${escape(name)}</span></a>`;
}

function tone(rgb) {
 const luminance = rgb.map(x => x / 255).reduce((sum, x, i) =>
  sum + [0.2126, 0.7152, 0.0722][i] * (x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4), 0);
 return luminance >= 0.179 ? '#000000' : '#ffffff';
}

export function sidebarPalette(color) {
 const base = /^#[0-9a-f]{6}$/i.test(color) ? color : defaultSidebarColor;
 const rgb = base.slice(1).match(/../g).map(hex => parseInt(hex, 16));
 const text = tone(rgb);
 const mix = amount => rgb.map(x => Math.round(x + ((text === '#ffffff' ? 255 : 0) - x) * amount));
 const rgbCss = numbers => 'rgb(' + numbers.join(', ') + ')';
 const active = mix(.15);
 const field = mix(.07);
 return {
  '--rail-background': base,
  '--rail-text': text,
  '--rail-active': rgbCss(active),
  '--rail-active-text': tone(active),
  '--rail-field': rgbCss(field),
  '--rail-field-text': tone(field),
  '--rail-border': rgbCss(mix(.33))
 };
}

export function sidebarStyle(color) {
 return Object.entries(sidebarPalette(color)).map(([key,value]) => key + ':' + value).join(';');
}
