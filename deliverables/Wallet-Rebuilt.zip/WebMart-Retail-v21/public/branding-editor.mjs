import { brandSettings, defaultSidebarColor, sidebarStyle } from './branding.mjs';

function imageField(escape, key, label, path, source) {
 return `<div class="branding-image-setting" data-brand-setting="${key}">
 <img src="${escape(source)}" alt="" width="48" height="48" data-brand-preview>
 <div class="branding-image-controls">
 <label class="form-field">${label}<input type="file" aria-label="${label}" accept="image/png,image/jpeg,image/webp" data-brand-upload></label>
 <input type="hidden" name="${key}" value="${escape(path)}">
 <button type="button" class="btn outline compact" data-brand-reset>Use default</button>
 </div></div>`;
}

export function brandingEditorMarkup(draft, escape, field) {
 const brand = brandSettings(draft);
 return `<section id="brand-settings" class="panel stack" aria-labelledby="brand-settings-title">
 <div><h3 id="brand-settings-title">Branding &amp; navigation</h3><p class="small muted">Update your storefront name, logos and sidebar color.</p></div>
 <div class="form-grid">
 ${field('Business name','name',brand.name,'text',true,'maxlength="80"')}
 ${field('Browser tab name','tabTitle',brand.tabTitle,'text',false,'maxlength="120" placeholder="Use page title and business name"')}
 ${imageField(escape,'logo','Store logo',brand.logo,brand.logo||'/assets/brand-mark.svg')}
 ${imageField(escape,'favicon','Browser tab icon',draft.favicon||'',brand.favicon)}
 </div>
 <p class="small muted">Upload PNG, JPEG or WebP. A square icon works best. The tab icon uses your store logo when left blank.</p>
 <div class="branding-color-setting">
 <label class="form-field">Sidebar color<input type="color" aria-label="Sidebar color" name="sidebarColor" value="${escape(brand.sidebarColor)}"></label>
 <span class="branding-sidebar-sample" style="${sidebarStyle(brand.sidebarColor)}">Sidebar preview</span>
 <button type="button" class="btn outline compact" id="reset-sidebar-color">Use default color</button>
 </div>
 <p class="small" data-brand-status role="status" aria-live="polite"></p>
 </section>`;
}

export function mountBrandingEditor(root, api) {
 const logo = root.querySelector('[name=logo]');
 const favicon = root.querySelector('[name=favicon]');
 const color = root.querySelector('[name=sidebarColor]');
 const status = root.querySelector('[data-brand-status]');
 const sample = root.querySelector('.branding-sidebar-sample');
 let uploads = 0;

 function refreshImages() {
  const current = brandSettings({logo:logo.value,favicon:favicon.value});
  root.querySelector('[data-brand-setting=logo] img').src = current.logo || '/assets/brand-mark.svg';
  root.querySelector('[data-brand-setting=favicon] img').src = current.favicon;
 }

 for (const slot of root.querySelectorAll('[data-brand-setting]')) {
  const field = slot.querySelector('input[type=hidden]');
  const upload = slot.querySelector('[data-brand-upload]');
  const reset = slot.querySelector('[data-brand-reset]');
  upload.addEventListener('change', async () => {
   const file = upload.files[0];
   if (!file) return;
   uploads++;
   upload.disabled = reset.disabled = true;
   status.textContent = 'Uploading image…';
   const data = new FormData();
   data.append('image',file);
   try {
    const result = await api('/api/admin/uploads',{method:'POST',body:data});
    field.value = result.image;
    refreshImages();
    status.textContent = 'Image ready. Save & publish to apply it.';
   } catch (error) {
    status.textContent = error.message;
   } finally {
    uploads--;
    upload.disabled = reset.disabled = false;
    upload.value = '';
   }
  });
  reset.addEventListener('click', () => {
   field.value = '';
   refreshImages();
   status.textContent = 'Default image selected. Save & publish to apply it.';
  });
 }
 const refreshColor = () => { sample.style.cssText = sidebarStyle(color.value); };
 color.addEventListener('input',refreshColor);
 root.querySelector('#reset-sidebar-color').addEventListener('click',() => {
  color.value = defaultSidebarColor;
  refreshColor();
 });
 return {isUploading:()=>uploads>0};
}
