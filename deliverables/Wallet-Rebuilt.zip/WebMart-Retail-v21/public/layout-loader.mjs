import { stylesheet, layout } from './storefront-layout-v21.mjs';

const legacyStylesheets = new Set([
  'fonts.css', 'styles.css', 'page-content.css', 'rental.css', 'rentals-v11.css', 'premium.css',
  'banner-v12.css', 'commerce.css', 'liquid-v14.css', 'obsidian-v15.css', 'onyx-v16.css', 'graphite-v17.css', 'retail-v19.css', 'finishing-v20.css', 'branding-v21.css', 'liquid-glass-rail-v19.css'
]);

function layoutIsReady() {
  return getComputedStyle(document.documentElement).getPropertyValue('--wm-layout').trim() === layout;
}

let recovery;
export function ensureStorefrontLayout() {
  if (recovery) return recovery;

  const oldLinks = [...document.querySelectorAll('link[rel=stylesheet]')].filter(link => {
    const url = new URL(link.href);
    return url.origin === location.origin && (/^\/storefront\.[a-f0-9]{12}\.css$/.test(url.pathname) ||
      legacyStylesheets.has(url.pathname.slice(1)));
  });
  const currentUrlAlreadyUsed = oldLinks.some(link => new URL(link.href).pathname === stylesheet);
  if (currentUrlAlreadyUsed && layoutIsReady()) {
    oldLinks.filter(link => new URL(link.href).pathname !== stylesheet).forEach(link => link.remove());
    return Promise.resolve();
  }

  recovery = new Promise((resolve, reject) => {
    const fresh = document.createElement('link');
    fresh.rel = 'stylesheet';
    fresh.href = stylesheet + (currentUrlAlreadyUsed ? '?layout=' + layout : '');

    function failed() {
      fresh.remove();
      reject(Error('The store layout could not load. Make sure WebMart is running from the new release folder, then try again.'));
    }

    fresh.addEventListener('error', failed, { once: true });
    fresh.addEventListener('load', () => {
      if (!layoutIsReady()) return failed();
      oldLinks.forEach(link => link.remove());
      resolve();
    }, { once: true });
    document.head.append(fresh);
  }).finally(() => { recovery = undefined; });
  return recovery;
}
