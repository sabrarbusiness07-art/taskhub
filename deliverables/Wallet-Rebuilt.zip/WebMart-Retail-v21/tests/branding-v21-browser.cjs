'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const {chromium} = require('playwright');
const {createApp} = require('../application');
const {passwordHash} = require('../lib/store');

const temp = fs.mkdtempSync(path.join(os.tmpdir(),'wm-branding-'));
const output = process.env.BROWSER_ARTIFACTS || path.join(os.tmpdir(),'wm-branding-preview');

(async () => {
 let browser,store,server;
 try {
  fs.mkdirSync(output,{recursive:true});
  server = require('node:http').createServer();
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base = 'http://127.0.0.1:' + server.address().port;
  const built = createApp({dataDir:temp,uploadDir:path.join(temp,'uploads'),origin:base});
  store = built.store;
  server.on('request',built.app);
  const password = crypto.randomBytes(20).toString('hex');
  const {salt,hash} = await passwordHash(password);
  store.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run('brand-merchant','brand@example.test','Merchant','admin',salt,hash);
  const executablePath = process.env.BROWSER_EXECUTABLE || (fs.existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined);
  browser = await chromium.launch({executablePath,args:['--no-sandbox']});
  const admin = await browser.newPage({viewport:{width:1366,height:900}});
  const desktop = await browser.newPage({viewport:{width:1366,height:900}});
  const mobile = await browser.newPage({viewport:{width:390,height:844},hasTouch:true,isMobile:true});
  const errors = [];
  for (const page of [admin,desktop,mobile]) page.on('pageerror', error=>errors.push(error.message));

  await admin.goto(base + '/admin/theme');
  await admin.locator('[name=email]').fill('brand@example.test');
  await admin.locator('[name=password]').fill(password);
  await admin.locator('#auth-form [type=submit]').click();
  // Login goes to the workspace home. Open the same settings through its nav.
  await admin.locator('.admin-nav a[href="/admin/theme"]').click();
  const settings = admin.locator('#brand-settings');
  await settings.waitFor();
  const fillName = 'Northstar Digital';
  const tabName = 'Northstar & Co.';
  await settings.getByLabel('Business name').fill(fillName);
  await settings.getByLabel('Browser tab name').fill(tabName);
  await settings.getByLabel('Sidebar color').fill('#f4e8ce');
  const data = await admin.evaluate(() => {
   const canvas = document.createElement('canvas');
   canvas.width = canvas.height = 48;
   const ctx = canvas.getContext('2d');
   const draw = (color, letter) => {
    ctx.fillStyle=color; ctx.fillRect(0,0,48,48);
    ctx.font='bold 28px sans-serif'; ctx.fillStyle='white'; ctx.fillText(letter,14,34);
    return canvas.toDataURL('image/png').split(',')[1];
   };
   return [draw('#075985','N'),draw('#942c75','S')];
  });
  for (const [index,label,key] of [[0,'Store logo','logo'],[1,'Browser tab icon','favicon']]) {
   await settings.getByLabel(label).setInputFiles({name:key+'.png',mimeType:'image/png',buffer:Buffer.from(data[index],'base64')});
   await admin.waitForFunction(key=>Boolean(document.querySelector('#brand-settings [name="'+key+'"]').value),key);
  }
  const logo = await settings.locator('[name=logo]').inputValue();
  const favicon = await settings.locator('[name=favicon]').inputValue();
  assert.notEqual(logo,favicon);
  assert.notEqual((await (await fetch(base + '/api/store')).json()).settings.name,fillName);
  await settings.screenshot({path:path.join(output,'branding-settings.png')});

  await admin.locator('#settings-form button[type=submit]').click();
  await admin.waitForFunction(()=>document.querySelector('#toast').textContent==='Website settings published.');
  assert.equal(await admin.locator('.admin-sidebar .brand-mark').getAttribute('src'),logo);
  assert.equal(await admin.title(),tabName);
  const html = await (await fetch(base)).text();
  assert.ok(html.includes('<title>Northstar &amp; Co.</title>'));
  assert.ok(html.includes('href="'+favicon+'"'));
  assert.equal((await fetch(base + favicon)).status,200);
  console.log('PASS logo and favicon upload separately, apply only after publish and appear in the initial HTML');

  await desktop.goto(base);
  await desktop.locator('.commerce-header .store-brand-name').waitFor();
  for (const selector of ['.commerce-header','.site-footer']) {
   const area = desktop.locator(selector);
   assert.equal(await area.locator('.store-brand-name').innerText(),fillName);
   const mark = area.locator('.brand-mark');
   assert.equal(await mark.getAttribute('src'),logo);
   await mark.evaluate(img=>img.decode());
   assert.equal(await mark.evaluate(img=>getComputedStyle(img).filter),'none');
  }
  assert.equal(await desktop.title(),tabName);
  assert.equal(await desktop.locator('#store-favicon').getAttribute('href'),favicon);
  assert.equal(await desktop.locator('.commerce-header').evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(244, 232, 206)');
  assert.equal(await desktop.locator('.rail-home').evaluate(el=>getComputedStyle(el).color),'rgb(0, 0, 0)');
  await desktop.locator('#mega-toggle').click();
  assert.equal(await desktop.locator('.rail-category-link').first().evaluate(el=>getComputedStyle(el).color),'rgb(0, 0, 0)');
  await desktop.locator('#rail-toggle').click();
  assert.equal(await desktop.locator('.commerce-header .brand-mark').isVisible(),true);
  await desktop.goto(base+'/product?id=template-forma');
  await desktop.locator('.product-buybox').waitFor();
  assert.equal(await desktop.title(),tabName);
  await mobile.goto(base);
  await mobile.locator('.commerce-header .brand-mark').waitFor();
  assert.equal(await mobile.locator('.commerce-header .brand-mark').getAttribute('src'),logo);
  assert.equal(await mobile.title(),tabName);
  console.log('PASS published name and original-color logo reach mobile, footer and both rail modes with readable sidebar contrast');

  await admin.reload();
  await settings.waitFor();
  await settings.locator('[data-brand-setting=favicon] [data-brand-reset]').click();
  await settings.locator('[data-brand-setting=logo] [data-brand-reset]').click();
  await settings.getByLabel('Browser tab name').fill('');
  await settings.locator('#reset-sidebar-color').click();
  await admin.locator('#settings-form button[type=submit]').click();
  await admin.waitForFunction(()=>document.querySelector('#toast').textContent==='Website settings published.');
  await desktop.goto(base);
  await desktop.locator('.commerce-header .brand-mark').waitFor();
  assert.equal(await desktop.locator('.commerce-header .brand-mark').getAttribute('src'),'/assets/brand-mark.svg');
  assert.equal(await desktop.locator('#store-favicon').getAttribute('href'),'/assets/favicon.svg');
  assert.equal(await desktop.title(),fillName);
  assert.equal(await desktop.locator('.commerce-header').evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(28, 32, 38)');
  assert.deepEqual(errors,[]);
  console.log('PASS persisted settings reload and image, tab and sidebar defaults can be restored');
 } finally {
  await browser?.close();
  if (server) await new Promise(resolve=>server.close(resolve));
  store?.close();
  fs.rmSync(temp,{recursive:true,force:true});
 }
})().catch(error=>{console.error(error);process.exitCode=1;});
