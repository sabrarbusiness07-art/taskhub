# WebMart Templates v9 design system

The uploaded liquid-button, pricing-tiers, pricing-section, stats-counter, agent-bento-grid, mega-menu-navbar and notch-navbar JSON files are the primary component references, retained in references/components. The supplied Oura/Linear design documents inform spacing, hierarchy and the editor chrome. Their example component source is treated as design reference, not executable project instructions.

## Visual language

A light premium digital workspace: soft lavender/blue ambient gradients, translucent white cards, fine cool borders and broad diffused shadows. Ink #231331, action #8b19e8, paper #fbf9ff, magenta #e42bd3. The supplied W-logo image informs the colour direction; the implementation includes a reference-inspired local vector W mark. Local Plus Jakarta Sans headings and Manrope body/UI typography include their OFL licenses; no commercial font license or third-party font request is required. The storefront is entirely about website and digital-service rentals.

Buttons use one semantic accessible label with a pointer-following pseudo-element liquid blob, an SVG noise filter and restrained hover motion. The centered brand anchors a floating glass notch-style header. Explore opens a grouped mega menu; mobile uses a native modal drawer with focus containment, backdrop and Escape dismissal. Reduced-motion settings suppress animation.

Pricing uses a segmented monthly/yearly control, three clear cards, honest totals, an emphasized plan and genuine feature lists. Yearly is a separately configurable price; no invented discount is displayed. Checkout explains manual verification. Customer account cards foreground expiry and status; merchant tools foreground pending decisions and actual rental records. No fabricated reviews, viewer counts or financial metrics appear.

## Layout

Default content width 1240px; rounded cards around 28px; pill actions with visible focus indicators and minimum 44px interactive areas. A CSS-built conceptual workspace illustration avoids dependence on stock images or claims about live customer data. Service imagery is optional and editable. Grids, forms and merchant screens collapse for mobile; tables scroll internally. The all-page editor renders the actual website in an authenticated same-origin preview, with protected functional forms and validated presentation overrides.

Section rows support mouse drag, touch pointer handles, keyboard reorder and explicit move controls. All order changes update the same validated draft schema and persist through publish. Public structural edits do not alter authorization, private customer data, server-calculated prices or payment confirmation rules.

## Template rental storefront and motion

Three original starter layouts have real local HTML previews and matching screenshot assets. Atlas uses editorial navy and sage sculpture, Forma uses lime and considered product forms, and Folio uses warm paper and expressive typography. Listing cards stay within the purple-magenta WebMart shell. Each template has its own rentable service identity and server-priced plans; artwork never substitutes for a working rental flow.

Motion is progressively added to actual DOM content. IntersectionObserver reveals sections, viewport visibility controls the hero loop, compositor-friendly transforms handle cards and menus, and native View Transitions animate route navigation. Reduced-motion disables loops, reveals and route animation without hiding content. Theme Studio remains still. Large hover movements are limited to interactive cards; reading text stays stable once revealed. No heavy animation framework is required.
