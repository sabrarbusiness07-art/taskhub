# WebMart Templates v9 — শুরু করো

## আগে v8 ব্যবহার করলে

Server বন্ধ করে পুরো পুরোনো folder backup রাখো। নতুন ZIP আলাদা করে extract করো। পুরোনো `data` ও নিজের `public/uploads` নতুন project-এ কপি করো; পুরোনো code/node_modules নয়। প্রথম startup-এ private backup হবে। আগের account, confirmed rental, expiry, requests, custom pages এবং section order থাকবে। Template gallery, details page ও homepage showcase যোগ হবে। Logo অনুযায়ী purple–magenta brand colour হবে।

## Website template যোগ/বদলানো

**Services & templates → Add service / Edit service → Listing type: Website template**। নিজের নাম, screenshot, tagline, included pages, highlights, monthly/yearly দাম ও plans দাও। নিজের design হলে **Custom design / external demo** বেছে public HTTPS demo URL দাও। **Featured on homepage** দিলে showcase-এ আসবে। Visibility Hidden করলে নতুন customer আর listing দেখতে বা request করতে পারবে না; পুরোনো rental history থাকবে।

শুরু করার জন্য Atlas Studio, Forma Commerce ও Folio Personal নামে তিনটি responsive demo আছে। এদের screenshot সেই আসল demo থেকেই বানানো। এগুলো starter design; নিজের service scope ও দাম মিলিয়ে তারপর live করো। Customer template page থেকে plan বেছে rent request করবে, তুমি আগের মতো payment যাচাই করে activate করবে।

Homepage, cards, buttons, menu, drawer ও navigation-এ motion আছে। OS/browser-এ Reduce motion চালু থাকলে animation বন্ধ থাকবে। Theme Editor preview ইচ্ছাকৃতভাবে স্থির রাখা হয়েছে যাতে সহজে edit করা যায়।

## আগে v7 ব্যবহার করলে

পুরোনো server Ctrl+C দিয়ে বন্ধ করো। পুরোনো পুরো folder backup রাখো। নতুন ZIP আলাদা folder-এ extract করে পুরোনো `data` এবং নিজের `public/uploads` নতুন project-এর একই জায়গায় কপি করো। পুরোনো code বা node_modules কপি কোরো না।

প্রথম startup-এ private database backup হবে। আগের merchant email/password থাকবে। পুরোনো physical products archive হবে; শুধু rental services দেখা যাবে। পুরোনো Basic/Advanced/Pro monthly দাম থাকবে, yearly দাম শুরুতে monthly-এর ১২ গুণ। Permanent কেনাকাটা থাকবে না। Built-in theme নতুন liquid design হবে; আগের theme database-এ snapshot হিসেবে থাকবে, custom pages রাখা হবে।

## Windows terminal

Project folder VS Code-এ খোলো। Node.js 24.14+ (24.x) লাগবে। PowerShell-এ চালাও:

```powershell
npm.cmd ci --omit=dev
```

শুধু নতুন installation হলে নিজের merchant email/password তৈরি করো:

```powershell
node scripts/setup-admin.js
```

তারপর:

```powershell
npm.cmd start
```

Website: http://localhost:5000
Merchant: http://localhost:5000/admin

Terminal চালু রাখবে। `START-WEBMART.cmd` দিয়েও চালাতে পারো। PowerShell script restriction এড়াতে `npm.cmd` ব্যবহার করো। কোনো default ID/password নেই; setup-এ নিজেরটা দিতে হবে। ZIP-এ তোমার পুরোনো private database দেওয়া নেই।

## Rental কাজের নিয়ম

- **Services & templates:** service, plans, features, monthly/yearly দাম ও visibility বদলাও।
- Customer plan বেছে নিজের account খুলে request করবে। সঙ্গে সঙ্গে active হবে না।
- **Customer rentals → Review:** বাস্তবে payment পাওয়ার পর checkbox দিয়ে confirm করো। Website link এবং customer message দিতে পারো। তখন plan-এর মেয়াদ শুরু হবে।
- Customer **My workspace**-এ plan, expiry, remaining days, history, renewal এবং cancellation request দেখবে।
- Admin subscription-এর status, expiry, customer message ও private notes manage করবে। Private notes customer দেখবে না।
- Renewal confirm করলে মেয়াদ বাড়বে। টাকা স্বয়ংক্রিয় কাটবে না; website তৈরি/hosting suspend/refund নিজে করতে হবে।
- **Settings:** contact ও manual bKash/Nagad/Rocket account দাও। না দিলে invoice arrangement থাকবে।

## Theme editor

16টি built-in page এবং custom pages সম্পাদনা করতে পারবে। Preview-এ লেখা/link/image click করো। **Add section** দিয়ে নতুন section যোগ করো। বাম পাশের section row/handle drag করে উপরে-নিচে নাও; keyboard-এ Alt+ArrowUp/Down অথবা Move up/down আছে। Touch handle-ও ব্যবহার করা যায়।

**Save draft** খসড়া রাখে; **Publish** live করে। Style-এ colours/fonts/menu, Page-এ title/SEO, More-এ import/export/rollback। Actual plan price Services & templates থেকে বদলাবে; customer data ও checkout calculation arbitrary text edit দিয়ে বদলায় না।

**Analytics**-এ live browsers, page/service views ও history দেখবে। Live মানে শেষ ৯০ সেকেন্ডে active browser; নিজের admin/preview বাদ যায়। Test করতে incognito browser-এ website খোলো।

`/api/health`-এ `webmart-templates-9.0.0` দেখাবে। চালু করতে সমস্যা হলে terminal-এর error দেখো; পুরোনো node_modules এনে বসাবে না।
