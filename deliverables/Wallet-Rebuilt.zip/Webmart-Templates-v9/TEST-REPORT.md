# WebMart Templates v9 verification

Verified 11 November 2026 on Linux, Node 24.22.1, npm 11.9.0 and Chromium 156.0.8078.79. Fixtures use isolated temporary databases and generated credentials.

| Check | Result |
|---|---|
| JavaScript syntax and seed assets | Passed |
| API, schema, migration and authorization | 37 passed |
| Existing rental browser journey | 19 passed |
| All-page editor browser journey | 20 passed |
| New template and motion browser journey | 13 passed |
| Total automated cases | **89 passed, 0 failed** |

API coverage retains pricing, account ownership, CSRF/origin checks, idempotency, payment verification, activation, calendar-month/year expiry, renewal, private notes, suspension/cancellation, concurrent edit versions, theme validation/publish/rollback and analytics. New cases cover three genuine starter previews, template metadata, custom HTTPS demo validation, published/hidden listings, exact template/plan/yearly identity through rental activation, template popularity and v8 migration without changing paid rentals, account hashes, edited page order or custom pages. Restart does not reseed edited templates.

The 13 new Chromium cases exercise purple-magenta branding, observed hero transform changes over time, scroll reveals, hover animation, catalogue category/search/empty states, native route transitions, real local iframe previews, desktop/mobile preview width, synchronized billing controls, signup and template checkout, merchant confirmation, customer plan expiry, admin metadata editing, external-demo behavior, both new Theme Studio pages, analytics and reduced motion. Rapid navigation exposed a rejected View Transition ready promise; it was handled, then all browser journeys passed with zero uncaught JavaScript exceptions.

The editor suite covers all **16** built-in templates, custom pages, static/button-link copy, validated draft/publish/export/rollback, FAQ sections, visibility, duplicate/delete, actual HTML drag, keyboard reorder and actual Chromium touch input for section handles. Preview editing is deliberately still; motion runs on the public website. The homepage now has six editable built-in sections, including the template showcase.

Template collection/details, public rental flows, merchant screens and the template-edit form were checked for document overflow at **320, 390 and 768px**, alongside desktop screenshot review. The mobile drawer was opened and dismissed with Escape. Reduced-motion makes content fully visible and disables looping effects. Card preview images are screenshots of the included real HTML demos.

Windows launcher scripts were inspected but not executed on Windows; Safari/iOS and real mobile hardware were not tested. Real payment settlement, automated website provisioning, external hosting enforcement, recurring charging, refunds and production deployment were not exercised. Existing manual activation and rental management remain the operating model. External demo URLs were checked for correct safe links; their external websites were not loaded or certified.

The release excludes private databases/backups, .env files, credentials, node_modules, logs and test screenshots. Installation uses locked runtime dependencies. A clean extracted production ZIP passed locked dependency installation, merchant account setup/login, actual server startup, all 16 page templates, three local template previews, font/brand/motion assets, public routes and private-data exclusion.
