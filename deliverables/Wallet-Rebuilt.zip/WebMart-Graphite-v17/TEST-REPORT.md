# WebMart Graphite v17 verification

Node 24.22.1 and Chromium 156. Browser checks used isolated temporary databases.

- Asset check passed for source syntax, seed media, the fingerprinted stylesheet and its Brotli/gzip copies.
- 74 API tests passed.
- 54 browser checks passed across the commerce, liquid, Obsidian, Onyx and Graphite suites.

The Graphite tests cover expanded and compact desktop navigation, preference persistence, custom submenus, Escape, search and the mobile drawer. At desktop widths from 801–1440px the three pricing cards share the same position and dimensions, with aligned prices, calls to action and details. The yearly price switch preserves alignment. Hover changes the shadow without moving the card.

The existing commerce tests verify the mobile preview device switch, cart, account, private downloads, editorial controls and storefront publication. A visual comparison at 390px verified that the mobile header, hero, promos and glass dock retain their layout with the new palette. A computed style audit checked home, catalog, product, plans, account, admin sign-in, cart, wishlist and help on desktop and mobile for residual pink or purple UI colors.

A fresh extraction installed all 73 production packages with npm ci. Merchant setup and login, release health, Brotli CSS, hero image decoding, dark actions and responsive rendering passed. All 74 API tests also passed in that extraction.
