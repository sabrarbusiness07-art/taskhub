# Unslop reference notes for WebMart v15

Reference: **unslop by Damir Sokolovsky** ([@heydamir](https://x.com/heydamir)), https://github.com/heydamir/unslop, licensed **CC BY 4.0**. The supplied archive is the source used for this review. Its original license is retained beside this file. These notes adapt its design guidance to the user’s explicit WebMart requirements.

## Material consulted

- README.md and skills/unslop/SKILL.md: product-specific direction; audit before polish; preserve working features and merchant content.
- references/signs.md: remove emoji decoration, arbitrary spacing, repeated coloured glows, tiny tracked labels, generic marketing copy and unsupported claims.
- references/tokens.md: consistent 4px spacing steps; quiet neutral surfaces; readable type roles; line icons; short purposeful motion.
- references/visuals.md and references/effects.md: show real product content; avoid decorative blobs and unnecessary canvas effects.

The archive’s examples/store.html is an intentionally problematic before example. It is not used as storefront code, branding, copy or business data. No unslop script is installed or executed by WebMart.

## Decisions applied to this brief

1. WebMart stays a digital-products marketplace with one-time purchases and monthly/yearly service plans. Product imagery, pricing, cart, account and merchant controls remain meaningful.
2. Quiet light graphite/ink surfaces and restrained borders make product screenshots the visual focus. Keep the provided WebMart mark recognisable; do not spread its purple colour into every surface.
3. The user explicitly requests liquid glass in the navigation and black liquid actions. That requirement takes precedence over unslop’s general preference against glass chrome. Use restrained translucent/specular treatments there, while keeping product information surfaces calm.
4. The hero follows the supplied Techland composition: a larger left slideshow and two smaller fixed images on the right. The user requests no carousel dots. Show digital-product content rather than copying another shop’s hardware offers, promises or logos.
5. Use a compact commerce type hierarchy, sentence-case labels and readable body/meta text. Avoid negative tracking on small text, large editorial serif emphasis and oversized slogan headings. Locally available Roboto may approximate the screenshot’s compact sans feel; this does not claim an exact match to Techland’s Latin font.
6. Use the existing consistent SVG icon set, approximately 16–18px with one stroke weight. No emoji in navigation, status labels, product badges or controls.
7. Use 120–180ms hover/press responses and a restrained ease-out curve. Animate opacity/transform rather than layout dimensions. Respect reduced-motion and retain native focus/click behaviour.
8. Keep prices and counters factual. Do not invent discounts, popularity, ratings, customers or delivery guarantees for visual decoration.

## Typography evidence scope

Techland’s non-www homepage was readable over normal TLS during this review. Its HTML links assets/theme/tailwind/css/v2-core.min.css. Direct inspection of that stylesheet’s Latin text stack was not completed. A public browser-scanned font report identifies self-hosted Noto Sans Bengali; that supports genuine Bengali glyph coverage but does not establish the Latin computed font. The supplied screenshots remain the visual reference for proportions and density.

Additional user-supplied design notes reviewed: Apple (quiet product-led layout, neutral ink, compact utility controls), Figma (black/white hierarchy and black primary actions), Shopify (commerce surface hierarchy and compact text roles), and the liquid-button registry reference (semantic button content and brief pointer feedback). These references inform an adaptation, not a claim of an Apple system component, Figma document or copied Techland storefront.


For v16 the same source informs charcoal admin surfaces, neutral action links, restrained 120–180ms motion and reduced blur. User-requested glass is bounded to navigation; source documents do not override the requested functionality.
