'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { chromium } = require('playwright');
const { createApp } = require('../application');

const output = process.env.BROWSER_ARTIFACTS || path.join(os.tmpdir(), 'webmart-graphite-browser');
const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-graphite-'));

async function verifyAlignedCards(page) {
  const cards = page.locator('.rental-plan');
  assert.equal(await cards.count(), 3);
  for (const element of ['.rental-plan', '.rental-plan .plan-price', '.rental-plan .btn', '.rental-plan .plan-features']) {
    const rectangles = await page.locator(element).evaluateAll(nodes => nodes.map(node => {
      const { y, height, width } = node.getBoundingClientRect();
      return { y, height, width };
    }));
    for (const rect of rectangles.slice(1)) {
      for (const key of element === '.rental-plan' ? ['y','height','width'] : ['y']) {
        assert.ok(Math.abs(rect[key] - rectangles[0][key]) < 1, element + ' misaligned: ' + JSON.stringify(rectangles));
      }
    }
  }
}

(async () => {
  let browser, server, store;
  fs.mkdirSync(output, { recursive: true });
  try {
    const built = createApp({ dataDir: directory, uploadDir: path.join(directory, 'uploads') });
    store = built.store;
    server = built.app.listen(0, '127.0.0.1');
    await new Promise(resolve => server.once('listening', resolve));
    const base = 'http://127.0.0.1:' + server.address().port;
    const executablePath = process.env.BROWSER_EXECUTABLE || (fs.existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined);
    browser = await chromium.launch({ executablePath, args:['--no-sandbox'] });
    const page = await browser.newPage({ viewport: { width: 1440, height: 960 } });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto(base);
    const sidebar = page.locator('.commerce-header');
    const toggle = page.locator('#rail-toggle');
    await toggle.waitFor();
    assert.equal(await toggle.getAttribute('aria-expanded'), 'true');
    assert.equal(await sidebar.evaluate(node => getComputedStyle(node).position), 'fixed');
    assert.equal(await sidebar.evaluate(node => Math.round(node.getBoundingClientRect().width)), 244);
    await page.locator('.rail-disclosure').first().click();
    await page.locator('.desktop-submenu').first().waitFor();
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('.desktop-submenu').first().isVisible(), false);
    await page.locator('#mega-toggle').click();
    await page.locator('#mega-menu').waitFor();
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('#mega-menu').isVisible(), false);
    await page.screenshot({ path: path.join(output, 'graphite-desktop.png') });
    await toggle.click();
    assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
    assert.equal(await sidebar.evaluate(node => Math.round(node.getBoundingClientRect().width)), 58);
    await page.reload();
    await toggle.waitFor();
    assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
    await page.locator('.hero-slide:not([hidden]) img').evaluate(img => img.decode());
    await page.screenshot({ path: path.join(output, 'graphite-compact.png') });
    await page.locator('#rail-search').click();
    assert.equal(await page.locator('#store-search').evaluate(node => node === document.activeElement), true);
    await page.locator('#store-search').fill('Atlas');
    await page.locator('#store-search').press('Enter');
    await page.locator('.catalog-head').waitFor();
    assert.equal(await page.locator('.commerce-card').count(), 1);
    console.log('PASS desktop sidebar expansion, custom submenu, Escape, stored preference and compact search');

    await page.goto(base + '/plans');
    await page.locator('.rental-plan').first().waitFor();
    await verifyAlignedCards(page);
    await page.locator('[data-cycle=yearly]').click();
    assert.match(await page.locator('.rental-plan .plan-price').first().innerText(), /year/);
    await verifyAlignedCards(page);
    const featured = page.locator('.rental-plan.featured');
    await featured.scrollIntoViewIfNeeded();
    const before = await featured.evaluate(node => node.getBoundingClientRect().top + scrollY);
    await featured.hover();
    await page.waitForFunction(() => getComputedStyle(document.querySelector('.rental-plan.featured')).boxShadow !== 'none');
    assert.ok(Math.abs(before - (await featured.evaluate(node => node.getBoundingClientRect().top + scrollY))) < 1);
    assert.equal(await page.locator('.plan-heading h3').first().evaluate(el => getComputedStyle(el).color), 'rgb(25, 25, 25)');
    await page.locator('.rental-plans').screenshot({ path: path.join(output, 'graphite-pricing.png') });
    console.log('PASS tiers have equal outer dimensions, aligned prices and CTAs, yearly switch and stationary glow');

    for (const width of [801, 1024, 1200]) {
      await page.setViewportSize({ width, height: 860 });
      await page.goto(base + '/plans');
      await page.locator('.rental-plan').first().waitFor();
      await verifyAlignedCards(page);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
    }
    const mobile = await browser.newPage({ viewport: { width:390, height:844 }, hasTouch:true, isMobile:true });
    mobile.on('pageerror', error => errors.push(error.message));
    await mobile.goto(base);
    await mobile.locator('.hero-stage').waitFor();
    assert.equal(await mobile.locator('#rail-toggle').isVisible(), false);
    assert.equal(await mobile.locator('#drawer-toggle').isVisible(), true);
    assert.equal(await mobile.locator('.mobile-bottom-nav').evaluate(el => getComputedStyle(el).position), 'fixed');
    await mobile.locator('#drawer-toggle').click();
    await mobile.locator('#navigation-drawer[open]').waitFor();
    await mobile.locator('#drawer-close').click();
    await mobile.screenshot({ path: path.join(output, 'graphite-mobile.png') });
    await mobile.goto(base + '/product?id=template-atlas');
    await mobile.locator('#product-buybox').waitFor();
    assert.equal(await mobile.locator('.product-demo').count(), 1);
    assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
    assert.deepEqual(errors, []);
    console.log('PASS desktop breakpoints, unchanged mobile navigation and product preview availability');
  } finally {
    await browser?.close();
    if (server) await new Promise(resolve => server.close(resolve));
    store?.close();
    fs.rmSync(directory, { recursive:true, force:true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
