'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createApp}=require('../application');
test('Onyx accent upgrade snapshots live/draft and preserves merchant content, photos and paid history exactly once',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wm16-upgrade-'));let store;
 try{
  store=createApp({dataDir:dir,uploadDir:dir+'/uploads'}).store;store.db.prepare("DELETE FROM config WHERE id='onyx-v16'").run();
  const theme=store.get('config','site-live');theme.global.accent='#ed28be';theme.global.navigation[0].title='Custom menu';theme.pages.home.seoTitle='My store';store.put('config','site-live',theme);store.put('config','site-draft',theme);
  const settings=store.get('config','settings');settings.color='#ed28be';settings.heroSlides=[{image:'/uploads/merchant-banner.webp',href:'/shop?category=My%20collection',alt:'My collection'}];store.put('config','settings',settings);store.put('config','draft',settings);
  const product=store.get('products','template-atlas');product.image='/uploads/merchant-product.webp';store.put('products',product.id,product);
  const order={id:'existing-paid',total:230000,status:'active',customerId:'retained'},subscription={id:'existing-rental',expiresAt:'2030-01-31T00:00:00Z',status:'active',periods:[{price:230000}]};store.put('orders',order.id,order);store.put('subscriptions',subscription.id,subscription);
  require('../lib/onyx-v16').migrate(store);
  assert.equal(store.get('config','site-live').global.accent,'#242830');assert.equal(store.get('config','site-draft').global.accent,'#242830');assert.equal(store.get('config','settings').color,'#242830');assert.equal(store.get('config','draft').color,'#242830');
  assert.deepEqual(store.get('config','site-live-before-v16'),theme);assert.deepEqual(store.get('config','settings-before-v16'),settings);assert.equal(store.get('config','site-live').global.navigation[0].title,'Custom menu');assert.equal(store.get('config','site-live').pages.home.seoTitle,'My store');assert.deepEqual(store.get('config','settings').heroSlides,settings.heroSlides);assert.deepEqual(store.get('products',product.id),product);assert.deepEqual(store.get('orders',order.id),order);assert.deepEqual(store.get('subscriptions',subscription.id),subscription);
  const version=store.get('config','site-live').version;require('../lib/onyx-v16').migrate(store);assert.equal(store.get('config','site-live').version,version);assert.equal(store.get('config','initialized').version,16);assert.ok(fs.readdirSync(dir+'/backups').some(f=>f.startsWith('before-onyx-v16-')));
 }finally{store?.close();fs.rmSync(dir,{recursive:true,force:true});}
});
test('first-hero preload follows published images, responsive media and section visibility without exposing draft media',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wm16-preload-'));let store,server;
 try{
  const built=createApp({dataDir:dir,uploadDir:dir+'/uploads'});store=built.store;server=built.app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
  let response=await fetch(base),html=await response.text();assert.match(response.headers.get('cache-control'),/no-store/);assert.match(html,/as="image"[^>]+href="\/assets\/market\/main-websites.webp"[^>]+min-width:641px/);assert.match(html,/as="image"[^>]+main-websites-mobile.webp[^>]+max-width:640px/);
  const draft=store.get('config','draft');draft.heroSlides=[{image:'/uploads/unpublished-banner.webp'}];store.put('config','draft',draft);html=await(await fetch(base)).text();assert.equal(html.includes('unpublished-banner.webp'),false);
  const live=store.get('config','settings');live.heroSlides=[{image:'/assets/templates/atlas.webp'}];store.put('config','settings',live);html=await(await fetch(base)).text();assert.match(html,/as="image"[^>]+href="\/assets\/templates\/atlas.webp"/);assert.equal(html.includes('main-websites.webp'),false);
  const theme=store.get('config','site-live');theme.pages.home.sections.find(s=>s.source==='home-hero').enabled=false;store.put('config','site-live',theme);html=await(await fetch(base)).text();assert.equal(html.includes('as="image"'),false);assert.equal((await(await fetch(base+'/?editorPreview=1')).text()).includes('as="image"'),false);
 }finally{if(server)await new Promise(r=>server.close(r));store?.close();fs.rmSync(dir,{recursive:true,force:true});}
});
