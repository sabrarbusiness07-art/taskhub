'use strict';
const{chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const{createApp}=require('../application'),{passwordHash}=require('../lib/store');
(async()=>{
 let browser,server,store;
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wm-obsidian-browser-')),out=process.env.BROWSER_ARTIFACTS||path.join(os.tmpdir(),'webmart-obsidian-browser-results'),checks=[],errors=[];
 fs.mkdirSync(out,{recursive:true});const pass=name=>{checks.push(name);console.log('PASS',name);};
 const darkSurface=async locator=>{await locator.evaluate(el=>Promise.all(el.getAnimations().map(animation=>animation.finished.catch(()=>{}))));const colors=await locator.evaluate(el=>{const css=getComputedStyle(el),value=css.backgroundImage==='none'?css.backgroundColor:css.backgroundImage;return[...value.matchAll(/rgba?\(([^)]+)\)/g)].map(m=>m[1].split(/[ ,/]+/).slice(0,3).map(Number)).filter(a=>a.length===3&&a.every(Number.isFinite));});assert.ok(colors.some(rgb=>Math.max(...rgb)<100),'Expected a black/charcoal button surface: '+JSON.stringify(colors));};
 const noOverflow=async page=>assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 try{
  server=require('node:http').createServer();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base='http://127.0.0.1:'+server.address().port,created=createApp({dataDir:dir,uploadDir:path.join(dir,'uploads'),origin:base});store=created.store;server.on('request',created.app);
  const password=crypto.randomBytes(24).toString('hex'),credentials=await passwordHash(password);
  store.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run('merchant','merchant@example.test','Merchant','admin',credentials.salt,credentials.hash);
  browser=await chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE||(fs.existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined),args:['--no-sandbox']});
  const desktopContext=await browser.newContext({viewport:{width:1440,height:1000}}),mobileContext=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true}),merchantContext=await browser.newContext({viewport:{width:1500,height:1000}});
  const page=await desktopContext.newPage(),mobile=await mobileContext.newPage(),merchant=await merchantContext.newPage();
  for(const view of [page,mobile,merchant])view.on('pageerror',error=>errors.push(error.message));
  await page.goto(base);await page.locator('.hero-stage-split').waitFor();await page.locator('.hero-slide:not([hidden]) img').evaluate(img=>img.decode());
  assert.equal(await page.locator('.hero-fixed-promos>.hero-promo').count(),2);
  assert.equal(await page.locator('.hero-slide-dots,[data-slide-to]').count(),0);assert.equal(/\p{Emoji_Presentation}/u.test(await page.locator('body').innerText()),false);
  const sliderBox=await page.locator('.hero-slideshow').boundingBox(),promoBox=await page.locator('.hero-fixed-promos').boundingBox();assert.ok(sliderBox.x<promoBox.x&&sliderBox.width>promoBox.width*1.5);
  for(const img of await page.locator('.hero-promo img').all())await img.evaluate(el=>el.decode());await noOverflow(page);
  await page.screenshot({path:path.join(out,'obsidian-desktop-home.png'),fullPage:true});
  pass('Fresh desktop storefront uses a left carousel and two real fixed promo images with no dot controls');

  const header=await page.locator('.commerce-header').evaluate(el=>{const css=getComputedStyle(el);return{position:css.position,radius:parseFloat(css.borderRadius),background:css.backgroundColor};});assert.equal(header.position,'fixed');assert.equal(header.background,'rgb(25, 25, 25)');assert.ok(header.radius>=14);
  const action=page.locator('.home-pricing .btn').first();await darkSurface(action);assert.equal(await action.locator('.button-label').count(),1);assert.equal(await action.locator('.liquid-surface').getAttribute('aria-hidden'),'true');
  const type=await page.locator('body').evaluate(el=>{const css=getComputedStyle(el);return{size:parseFloat(css.fontSize),lineHeight:parseFloat(css.lineHeight),family:css.fontFamily};});assert.ok(type.size>=12&&type.size<=16);assert.ok(type.lineHeight>type.size);assert.match(type.family,/Noto Sans Bengali/);assert.match(type.family,/system-ui/);const localBengali=await page.evaluate(async()=>{const fonts=await document.fonts.load('400 16px "Noto Sans Bengali"','বাংলা');return fonts.length>0&&fonts.every(f=>f.status==='loaded');});assert.equal(localBengali,true);
  pass('Graphite sidebar, charcoal liquid actions and compact readable ecommerce typography render together');

  await mobile.goto(base);await mobile.locator('.hero-slideshow').waitFor();assert.equal(await mobile.locator('.hero-slide-dots,[data-slide-to]').count(),0);assert.equal(await mobile.locator('#drawer-toggle').isVisible(),true);assert.equal(await mobile.locator('.header-tools>a:visible,.header-search:visible').count(),0);assert.equal(await mobile.locator('.mobile-bottom-nav').evaluate(el=>getComputedStyle(el).position),'fixed');assert.ok(await mobile.locator('.mobile-bottom-nav a').count()>=4);await noOverflow(mobile);
  const first=await mobile.locator('[data-slide]:not([hidden])').getAttribute('data-slide');await mobile.waitForFunction(index=>document.querySelector('[data-slide]:not([hidden])').dataset.slide!==index,first,{timeout:7500});
  await mobile.screenshot({path:path.join(out,'obsidian-mobile-home.png'),fullPage:true});
  pass('Touch/mobile carousel advances automatically without dots while logo/menu and bottom navigation remain usable');

  await page.goto(base+'/product?id=template-atlas');await page.locator('#product-buybox').waitFor();await page.locator('[data-product-cycle=yearly]').click();assert.match(await page.locator('.purchase-price').innerText(),/year/);await darkSurface(page.locator('#product-add-cart'));assert.equal(await page.locator('[data-product-cycle=yearly]').getAttribute('aria-pressed'),'true');await page.locator('#product-buybox [data-save-product]').click();assert.equal(await page.locator('.header-wishlist [data-wishlist-count]').innerText(),'1');await page.locator('#product-add-cart').click();await page.locator('.header-cart').click();await page.locator('.cart-line').waitFor();assert.match(await page.locator('.cart-line').innerText(),/One calendar year/);await noOverflow(page);
  pass('Digital website yearly-plan selection, wishlist feedback and cart survive the visual update');

  await merchant.goto(base+'/admin');await merchant.locator('[name=email]').fill('merchant@example.test');await merchant.locator('[name=password]').fill(password);await merchant.locator('#auth-form [type=submit]').click();await merchant.locator('.stats').waitFor();await merchant.goto(base+'/admin/theme');await merchant.locator('#settings-form').waitFor();assert.equal(await merchant.locator('[name=heroArrangement]').inputValue(),'split');assert.equal(await merchant.locator('#hero-promo-editors .slide-editor').count(),2);
  await merchant.locator('#hero-promo-editors [data-alt]').first().fill('Explore our digital websites');await merchant.locator('#hero-promo-editors [data-link]').first().fill('/shop?type=website');await merchant.locator('#hero-slide-editors [data-alt]').first().fill('Your next digital website');await merchant.locator('#settings-form [type=submit]').click();await merchant.waitForFunction(()=>document.querySelector('#toast').textContent.includes('settings published'));
  await page.goto(base);await page.locator('.hero-promo').first().waitFor();assert.equal(await page.locator('.hero-promo').first().getAttribute('href'),'/shop?type=website');assert.equal(await page.locator('.hero-promo img').first().getAttribute('alt'),'Explore our digital websites');assert.equal(await page.locator('.hero-slide-dots,[data-slide-to]').count(),0);
  pass('Merchant settings edit and publish actual slideshow/promo destinations and descriptions without reintroducing dots');

  await merchant.goto(base+'/admin/editor');await merchant.locator('#studio-frame').waitFor();await merchant.frameLocator('#studio-frame').locator('.hero-stage-split').waitFor();await merchant.locator('[data-studio-tab=global]').click();assert.ok(await merchant.locator('[data-add-nav=navigation]').count());assert.ok(await merchant.locator('.studio-icon-library').count());
  pass('Theme Studio still previews the new split hero and exposes menu/icon customization');

  const registration=await desktopContext.request.post(base+'/api/auth/register',{headers:{Origin:base},data:{name:'Digital Customer',email:'customer@example.test',password}});assert.equal(registration.status(),201);await page.goto(base+'/account#my-rentals');await page.locator('.account-page').waitFor();await page.waitForFunction(()=>document.querySelector('.wm-account-nav [aria-current=location]')?.getAttribute('href')==='#my-rentals');assert.equal(await page.locator('.wm-account-nav [aria-current=location]').count(),1);
  pass('Customer account retains accurate active rental navigation after the redesign');

  for(const width of[360,390,768,1024,1440]){await page.setViewportSize({width,height:900});await page.goto(base);await page.locator('.commerce-card').first().waitFor();await noOverflow(page);assert.equal(await page.locator('.hero-slide-dots,[data-slide-to]').count(),0);await page.goto(base+'/product?id=template-atlas');await page.locator('#product-buybox').waitFor();await noOverflow(page);}
  const reducedContext=await browser.newContext({viewport:{width:390,height:844},reducedMotion:'reduce'}),reduced=await reducedContext.newPage();await reduced.goto(base);await reduced.locator('.home-pricing .btn').first().waitFor();assert.equal(await reduced.locator('.home-pricing .btn').first().evaluate(el=>getComputedStyle(el).transitionDuration),'0s');await reducedContext.close();
  pass('Home/product layouts fit 360–1440px and reduced-motion disables liquid transitions');

  assert.deepEqual(errors,[]);pass('No uncaught browser exceptions in the v15 customer and merchant journeys');fs.writeFileSync(path.join(out,'obsidian-results.json'),JSON.stringify({passed:checks.length,checks,errors},null,2));console.log('PASSED',checks.length,'Obsidian browser checks');
 }catch(error){console.error(error);process.exitCode=1;fs.writeFileSync(path.join(out,'obsidian-failure.txt'),String(error.stack));}
 finally{await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));store?.close();fs.rmSync(dir,{recursive:true,force:true});}
})();
