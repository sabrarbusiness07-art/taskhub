# WebMart Graphite v17

A complete Node.js ecommerce storefront for digital products, websites and monthly/yearly digital services. A collapsible charcoal desktop sidebar, black actions and aligned pricing cards give the storefront a neutral palette. The marketplace structure draws on Techland and Ghorerbazar; the page builder interaction draws on the supplied Tech Bazar source. These are design references, not copied merchant content or a Figma project file.

## Run locally

Use Node.js **24.14 or later in the 24.x line**. Extract this ZIP to a new folder; never copy old node_modules.

```sh
npm ci
npm run setup
npm start
```

Website: http://localhost:5000 · Merchant: http://localhost:5000/admin · Theme Studio: http://localhost:5000/admin/editor.

On Windows PowerShell use `npm.cmd ci`, `npm.cmd run setup`, `npm.cmd start`. You can also double-click `START-WEBMART.cmd` and `SETUP-MERCHANT.cmd`. This avoids the PowerShell npm.ps1 execution-policy issue. There is **no default email or password**: choose your own during setup. Existing installations keep their merchant login; do not run setup again unless adding/resetting a merchant.

## Desktop sidebar and pricing

The desktop sidebar starts expanded at 1200px and above and compact on narrower desktops. Its toggle remembers your preference. Search, category browsing, customizable menus and submenus, saved products, cart and account links all work in the new sidebar. Under 801px, the existing logo/menu header and glass bottom navigation use their original layout. The product preview and its desktop/mobile switch use the same sizing as v16.

Pricing cards share the same dimensions and align their titles, prices, actions and features across each desktop row. Recommendation appears beside the card icon. Hover and keyboard focus add a restrained neutral glow without shifting the card. Artwork built into the homepage uses a grayscale treatment. Merchant product photography and uploaded banners retain their colours.

The supplied Unslop reference informed the neutral palette, compact sidebar and consistent spacing. The design-md liquid and pricing components informed the button highlights and card layout. The storefront uses native CSS and browser controls.

All prior merchant functionality remains: editable images/menus/icons/sections, wishlist counts, one-time purchases, subscriptions, protected downloads, customer accounts, manual payment verification, preview visibility, product/plan removal, draft/publish/rollback and analytics.

## Store and fulfilment

- Search, categories, sort, saved products, cart and checkout.
- Product types: website, software, digital download, digital service.
- Billing: one-time, monthly/yearly subscription, or both.
- The full product form controls name/category, main image, gallery, description, highlights, specifications, date, badge, license, requirements, support, delivery, FAQ, video, live preview and every plan/price.
- Public HTTPS demo links become live website previews. Local bundled demos load immediately; external previews load on request to keep pages fast. Embedded previews scroll and support desktop/mobile widths. Open live always opens the merchant’s link; external sites may block embedding.
- Digital files: merchant uploads ZIP/PDF up to 32 MB. Files remain outside the public directory. A confirmed purchase or active entitled subscription is required to download. Images up to 5 MB; MP4 videos up to 32 MB; YouTube/Vimeo or HTTPS MP4 URLs also supported.
- Cart prices are computed on the server. A changed price requires review. Checkout retries are idempotent.
- **Payments are manually arranged/verified.** Configure bKash/Nagad/Rocket accounts in Store settings, or use invoice/payment arrangement. This release does not connect a payment gateway, automatically charge renewals, provision hosting or deploy Laravel websites.
- Merchant → Orders & customer plans → open order → verify payment → confirm. Confirmation grants purchases and starts each plan for its purchased calendar term. Repeated confirmation cannot activate twice. A declined order grants nothing.
- Account shows plan, start/expiry, status, renewal/cancellation requests, order history and confirmed digital downloads. Suspension/expiry stops subscription downloads.

## Page builder

Open Theme Studio, select a page, then use the **+ Add section** controls between sections in the preview or sidebar. Drag section rows, use Move up/down, or Alt+Up/Down. Edit text/images by clicking the preview; edit section layout, colours, links and items in the inspector.

Available blocks: hero, text, image, product/category collections, feature cards, FAQ, gallery, call to action, announcement, video, date/event, countdown, divider and spacer. Event times use Bangladesh time. Save draft first or Publish directly; drafts remain private to merchants. Built-in purchase/account controls stay functional. Custom pages, SEO, import/export, undo/redo, rollback, font/style options, custom header menus/submenus and footer links remain available. Slideshow images/mobile images, destinations and hero text are in Store settings, linked from the hero inspector.

Product content/prices belong in Products & services, not as text overrides in Theme Studio. Live viewer counts, daily views, product popularity and CSV analytics remain in Analytics; merchant and editor traffic is excluded.

## Upgrade without losing data

1. Stop the old server. Back up the complete existing folder.
2. Extract v17 separately. Copy the old private `data/`, `public/uploads/`, and `public/media/` (if present) to the matching new paths. Keep custom DATA_DIR / UPLOAD_DIR settings if you use them. Never copy old source or dependencies over v17.
3. Run `npm ci --omit=dev`, then `npm start`.

Accounts, password hashes, paid orders/plans, customised product images, hero/promo destinations, navigation, SEO and custom page order are retained. The v16 migration changes only the live/draft action accent and settings colour to graphite, increments versions and records a migration marker. It creates `data/backups/before-onyx-v16-*.sqlite` plus `site-live-before-v16`, `site-draft-before-v16`, `settings-before-v16` and `draft-before-v16` snapshots. It runs once; later merchant edits are preserved. Older installations also pass through their existing migrations. The public ZIP excludes databases, credentials, backups, user uploads and private digital files.

Use `npm run backup` to save a consistent SQLite database plus private files, uploaded images and videos. Keep backups private. Restore the database to DATA_DIR/wallet.sqlite and restore digital-files, uploads and media to their matching directories while the server is stopped.

## Verification and deployment

```sh
npm run build:assets
npm run check
npm test
npx playwright install chromium
npm run test:browser
```

Browser tests use bundled Playwright Chromium, system /usr/bin/chromium when present, or BROWSER_EXECUTABLE. Screenshots/results go to a temporary directory, configurable with BROWSER_ARTIFACTS. Run `npm run build:assets` after changing public CSS/MJS: this rebuilds the content-hashed stylesheet, updates index.html and refreshes Brotli/gzip. Restart the server after a source build; HTML is read once at startup. Generated storefront.*.css should not be edited directly.

Production requires HTTPS PUBLIC_URL, NODE_ENV=production, persistent private DATA_DIR and persistent UPLOAD_DIR/media. Default HOST is 127.0.0.1. TRUST_PROXY=1 is appropriate only behind your trusted reverse proxy. See RUN-AND-DEPLOY.md. Health release: `webmart-graphite-17.0.0`.
