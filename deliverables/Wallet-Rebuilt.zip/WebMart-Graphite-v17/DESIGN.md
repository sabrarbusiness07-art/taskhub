# WebMart Onyx v16 design

The user supplied unslop and the existing WebMart code as references. The latest uploaded “v13” source is the prior v15 release, so v16 preserves its digital-commerce/editor features. Unslop’s guidance supports neutral hierarchy, consistent spacing, native interactions, real product imagery and one line-icon set. Requested liquid glass takes precedence over its generic caution against glass. Attribution is in references/unslop.

## Material and hierarchy

Graphite actions (#242830), neutral public canvas, white product cards, compact Noto Sans Bengali / system-ui typography, and a charcoal merchant workspace replace pink UI accents. The supplied W logo retains its gradient. Uploaded advertising artwork is preserved rather than recoloured. Product grids, prices, plan terms, wishlist and checkout remain the main consumer flows. No emoji or invented sales/review metrics are added.

Action links and primary buttons share specular borders, restrained black gradients and short hover/press feedback. Readable navigation links retain their text hierarchy rather than turning every sentence into a CTA. Cards do not get expensive blur. Header and mobile dock use bounded backdrop blur; the dock is translucent with a selected glass lens. Reduced-motion removes transitions and autoplay.

## Hero and editor

The hero is a left slideshow with two independently editable fixed promos. There are no pause/resume buttons, dots or counters; autoplay, swipe, keyboard/desktop arrows and automatic pausing on hover/focus/hidden tab remain. Desktop banner height follows its artwork ratio, preventing cropped text in a narrower Studio canvas. Mobile has its own image variant and optional promo visibility.

The admin dashboard, lists, settings, Product Studio, dialogs and Theme Studio use dark surface levels and legible labels/borders. Existing active navigation, product/plan add/remove/restore, section insertion/drag, menu/icon customization, draft/publication and private order data remain functional. The preview iframe has its own storefront CSS and colour scheme; only its section-selection and insertion chrome becomes neutral.

## Loading and feedback

Eleven stylesheet layers compile to a single content-hashed public CSS file with Brotli/gzip. The generated URL and compression are checked together. HTML/API remain uncached; only fingerprinted CSS is immutable. Static fonts/artwork can be cached for one day. Only published visible first-hero media is announced in HTML; mobile media queries select the proper asset. Admin modules/styles remain deferred.

Liquid position updates run only on entry, focus and press, never pointermove. Ripple duration is 160ms; other interactions generally take 120–180ms and no timer delays navigation. Intl price/date formatters are reused. Performance measurements and their limits are in PERFORMANCE.md; no universal speed score is claimed.
