# Performance — WebMart Onyx v16

Paired synthetic comparison in the same shared workspace and Chromium 156 process, Node 24.22.1. Each value is the median of three fresh-context samples per version/mode. A warm reload used that context's browser cache. Mobile: 390px touch, CDP 4× CPU slowdown, 1.6 Mbps download, 150ms latency. These localhost/shared-host measurements are not physical-device/production guarantees or Lighthouse scores.

| Mode | v15 LCP | v16 LCP | v15 DOM ready | v16 DOM ready | v15 / v16 resources |
|---|---:|---:|---:|---:|---:|
| Desktop localhost · cold | 408 ms | 440 ms | 150 ms | 143 ms | 30 / 21 |
| Desktop localhost · warm | 136 ms | 108 ms | 50 ms | 35 ms | 30 / 21 |
| Mobile synthetic · cold | 1804 ms | 1432 ms | 1174 ms | 997 ms | 26 / 17 |
| Mobile synthetic · warm | 1320 ms | 892 ms | 925 ms | 577 ms | 29 / 20 |

Mobile median LCP improved about **21% cold / 32% warm** in this experiment. Desktop cold LCP varied upward by 32ms while DOM-ready and warm LCP improved; this does not establish a desktop cold-load speedup. Cold resource transfer fell from 399,833 to 391,154 bytes desktop, and 161,205 to 152,526 bytes mobile. The window ends 600ms after first hero decode, excludes the HTML response bytes and does not count later deferred media. External homepage resources: zero. Merchant modules/styles on homepage: zero.

## Changes that reduce work

- Eleven CSS layers compile into one Brotli/gzip, content-fingerprinted stylesheet: stylesheet requests fall from 10 to 1, and immutable caching remains safe across builds. `npm run check` verifies the generated filename, source and compressed data together.
- HTML preloads only the first published, enabled hero image. Responsive media chooses its mobile variant. Draft/editor/hidden hero media is not announced. Browser module preloads reduce import discovery delay.
- Fonts and bundled artwork can remain in browser cache for a day. HTML, sessions and APIs remain uncached; public request responses are never reused for another customer's private data.
- Liquid controls do not listen to pointermove or schedule mouse-tracking animation frames. A meaningful browser probe dispatches 100 pointer moves over a control and verifies **zero** bounding-box reads. Entry/focus/press still produce a native 160ms ripple without delaying actions.
- Per-button backdrop blur is removed. Blur remains bounded to the navigation surfaces; static product cards and admin lists do not continuously animate. Reused Intl formatters avoid repeated formatter construction when rendering prices/dates.
- Product media remains lazy, the next slide warms after initial rendering, and external live preview can load on demand or be hidden. Reduced-motion and hidden tabs stop autoplay.

Actual merchant-uploaded file weight, server/network latency, product count and client hardware still determine production speed. Keep images compressed and use appropriately sized desktop/mobile banners. No automatic hosting/Laravel provisioning or payment gateway was added.
