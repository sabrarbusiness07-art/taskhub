const preferenceKey = 'wm-desktop-rail-expanded';

export function desktopRailExpanded(preview) {
  if (preview) return false;
  try {
    const preference = localStorage.getItem(preferenceKey);
    if (preference !== null) return preference === 'true';
  } catch {
    // A blocked preference store should not affect navigation.
  }
  return matchMedia('(min-width: 1200px)').matches;
}

export function bindDesktopRail(header, preview) {
  const toggle = header.querySelector('#rail-toggle');
  const search = header.querySelector('#rail-search');
  const browse = header.querySelector('#mega-toggle');
  const categories = header.querySelector('#mega-menu');
  const disclosures = [...header.querySelectorAll('.rail-disclosure')];

  function showSubmenu(button, open) {
    button.setAttribute('aria-expanded', String(open));
    button.nextElementSibling.hidden = !open;
  }

  function setExpanded(open) {
    header.dataset.railOpen = String(open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Collapse sidebar' : 'Expand sidebar');
    if (!open) disclosures.forEach(button => showSubmenu(button, false));
  }

  setExpanded(header.dataset.railOpen === 'true');
  toggle.addEventListener('click', () => {
    const open = header.dataset.railOpen !== 'true';
    setExpanded(open);
    if (preview) return;
    try { localStorage.setItem(preferenceKey, String(open)); } catch {}
  });
  search.addEventListener('click', () => {
    setExpanded(true);
    header.querySelector('#store-search').focus();
  });
  browse.addEventListener('click', () => {
    const open = categories.hidden;
    browse.setAttribute('aria-expanded', String(open));
    categories.hidden = !open;
    if (open) categories.querySelector('a')?.focus({preventScroll:true});
  });
  disclosures.forEach(button => button.addEventListener('click', () => {
    showSubmenu(button, button.getAttribute('aria-expanded') !== 'true');
  }));
  header.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    if (!categories.hidden) {
      categories.hidden = true;
      browse.setAttribute('aria-expanded', 'false');
      browse.focus();
    } else {
      const group = event.target.closest('.desktop-nav-group');
      const disclosure = group?.querySelector('.rail-disclosure[aria-expanded=true]');
      if (disclosure) {
        showSubmenu(disclosure, false);
        disclosure.focus();
      }
    }
  });
}
