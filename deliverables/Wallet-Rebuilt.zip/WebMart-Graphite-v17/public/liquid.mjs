// Fast delegated liquid highlights. Position only on entry/focus/press, never on pointermove.
let installed=false;
export function installLiquid(){
 if(installed)return;
 installed=true;
 const pref=matchMedia('(prefers-reduced-motion: reduce)');
 const button=e=>{const b=e.target.closest?.('.liquid-button,.liquid-control');return b&&!b.disabled&&b.getAttribute('aria-disabled')!=='true'?b:null;};
 function origin(b,x,y){
  const rect=b.getBoundingClientRect();
  b.style.setProperty('--liq-x',Math.min(rect.width,Math.max(0,x===undefined?rect.width/2:x-rect.left))+'px');
  b.style.setProperty('--liq-y',Math.min(rect.height,Math.max(0,y===undefined?rect.height/2:y-rect.top))+'px');
  b.style.setProperty('--liq-size',Math.ceil(Math.hypot(rect.width,rect.height)*2.2)+'px');
 }
 document.addEventListener('pointerover',e=>{
  if(pref.matches||e.pointerType==='touch')return;
  const b=button(e);
  if(!b||(e.relatedTarget instanceof Node&&b.contains(e.relatedTarget)))return;
  origin(b,e.clientX,e.clientY);
 },{passive:true});
 document.addEventListener('focusin',e=>{
  if(pref.matches)return;
  const b=button(e);
  if(b&&b.matches(':focus-visible'))origin(b);
 });
 document.addEventListener('pointerdown',e=>{
  if(pref.matches)return;
  const b=button(e);
  if(!b)return;
  origin(b,e.clientX,e.clientY);
  const ring=b.querySelector('.liquid-ripple');
  if(!ring)return;
  ring.getAnimations().forEach(a=>a.cancel());
  ring.animate([{opacity:.6,transform:'translate(-50%,-50%) scale(.1)'},{opacity:0,transform:'translate(-50%,-50%) scale(2.3)'}],{duration:160,easing:'cubic-bezier(.2,.7,.2,1)'});
 },{passive:true});
}
export function decorateLiquid(button){
 if(button.querySelector(':scope > .liquid-surface'))return;
 const surface=document.createElement('span');
 surface.className='liquid-surface';
 surface.setAttribute('aria-hidden','true');
 surface.innerHTML='<span class="liquid-blob"></span><span class="liquid-ripple"></span>';
 button.prepend(surface);
}
