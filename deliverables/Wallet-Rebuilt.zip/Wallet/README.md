# WebMart / Wallet — clean rebuild v6

A complete replacement of the uploaded project's application code. The original archive remains separate. The new project contains a Node 24 / Express / SQLite backend, a responsive storefront, and a merchant workspace. There is no frontend build step: native browser modules are served directly.

## Start locally

Use Node.js 24.14+ in the 24.x release line.

```sh
npm ci
npm run setup
npm test
npm run check
npm start
```

Open http://localhost:5000. Merchant login: http://localhost:5000/admin. The setup command asks for your email, name and a password of at least 12 characters. There is no shipped default password. Input is hidden in a normal terminal. Non-interactive setup accepts ADMIN_EMAIL, ADMIN_NAME and ADMIN_PASSWORD environment variables. To reset an existing merchant password, run `npm run setup -- --reset`; this invalidates that user's sessions.

## Included

- All 8 original catalog products, original product/variant IDs, prices and stock; 30 referenced original product/gallery images.
- Homepage, searchable brand-filtered collection, price sorting, offers, saved products, product gallery and option selection.
- Basic / Advanced / Pro monthly service plans and a distinct permanent-purchase option. Digital-only bags have zero shipping.
- Bag quantity/removal, server-priced checkout, optional coupon, Dhaka/outside delivery, COD and configurable bKash/Nagad/Rocket manual payments.
- Transactional stock decrement, duplicate-checkout protection, stock restoration on cancellation/return, duplicate payment-reference verification protection.
- Email/password customer accounts, account order history, private guest order links, printable invoice.
- Merchant overview, product create/edit/remove and image upload, order fulfilment/payment/tracking, registered customer list, categories, coupons and order JSON export.
- Private store-setting drafts, preview, publish and previous-publication rollback; editable branding, hero, policies, delivery fees, payment numbers and service introduction.
- Aggregate page-view counts by day using Asia/Dhaka dates. These counts are not unique-visitor analytics.
- Optional merchant email/Telegram order notification integrations, disabled until configured.
- Consistent SQLite backup and offline import of the supplied legacy database.

## Run browser checks

```sh
npm ci
npx playwright install chromium
npm run test:browser
```

The browser suite starts an isolated app and temporary database and removes them afterwards. To use an installed system Chromium, set `BROWSER_EXECUTABLE=/usr/bin/chromium` (or the matching executable path). Set `BROWSER_ARTIFACTS=/absolute/path/to/artifacts` to keep screenshots and the JSON results outside the temporary directory.

## What was removed or replaced

The old storefront/admin HTML files, dozens of overlapping theme overrides, old scripts, old tests tied to those scripts, historical release-note files, unused banners/images and bundled node_modules are absent. The drag-and-drop Theme Studio and unrelated PC builder were replaced with a focused settings/draft editor. The old visitor fingerprint/session tracking, destructive store-reset screen and unused legacy admin utilities are not part of this rebuild. Existing product reviews render if present; a review-submission/moderation system is not included. Core shopping and merchant operations are reimplemented against the new API; this is not an API-compatible patch.

## Data and accounts

`seed.json` contains the product catalog and a clean public configuration, not live customer records. On first start, the application creates `data/wallet.sqlite`. This is a new filename, separate from the legacy `store.sqlite`. No uploaded admin credentials, sessions, customer records, audit history or tracking data are included in the deliverable.

The supplied database had 8 products and no orders or customer accounts. The seed keeps the business name and product prices, and starts with blank contact and payment account details. Fill in your real contact information, verified policies and payment numbers in Store settings, save draft and publish.

Saved products and the shopping bag use browser localStorage. Guest orders are accessible with their private key, saved in the checkout browser. The confirmation screen can copy a private link and print an invoice. Signed-in customer orders appear in account history; guest orders are not automatically claimed by a later account.

## Import an existing legacy store

Stop the old application and back up its database, WAL/SHM files and uploads. Work on a copy. On a fresh new destination, **before running setup**:

```sh
npm ci
npm run import:legacy -- /absolute/path/to/old/Wallet
npm start
```

The importer reads the legacy database without executing any old source code. It copies products, orders, settings, categories, coupons, merchant credentials, verified payment references and referenced images. Old sessions expire. The supplied archive's migration was tested with 8 products, 0 orders and 1 admin. Legacy username/phone-only customer records require account migration work; the importer refuses unsupported credentials instead of dropping them. Historical visual-builder settings and visitor logs are not migrated. Inspect policies, the hero image and all configuration after importing. An existing destination with users/orders or a previous import is refused. The new store is not intended to run concurrently against the old application's database.

## Deployment / cPanel

1. Back up the live installation. Deploy this as a separate app/folder; do not blindly overwrite an existing live database.
2. Select Node 24.x, startup file `server.js`, and run `npm ci --omit=dev`.
3. Set `NODE_ENV=production` and `PUBLIC_URL=https://your-domain.example` to the exact visitor-facing origin. Mutation requests must come from that origin.
4. Set `HOST` and `PORT` according to the host; `0.0.0.0` is appropriate when your reverse proxy requires it. Defaults are 127.0.0.1 and 5000. Set `TRUST_PROXY=1` only when one trusted reverse proxy fronts the app.
5. Keep writable persistent `DATA_DIR` private and `UPLOAD_DIR` persistent. The default upload folder is public/uploads. If using another folder, copy the 30 packaged uploads there before starting.
6. Create merchant access using `npm run setup`, or import the legacy store before setup as above. Restart the app and check `/api/health` for `webmart-rebuild-6.0.0`.
7. Sign in to /admin, review store settings, save/publish, and test the live domain and your actual payment/notification services.

Set runtime options in your hosting provider’s environment-variable settings. The application reads process environment variables; it does not automatically load a .env file. SQLite requires a persistent writable filesystem and one application instance; this package is not designed for stateless edge hosting or multi-server writes.

## Backup

```sh
npm run backup
# optional destination folder:
npm run backup -- /private/backup/folder
```

This uses SQLite `VACUUM INTO` for a consistent database snapshot. Back up the uploads directory separately. To restore: stop the app, replace wallet.sqlite with the chosen backup, remove stale wallet.sqlite-wal/wallet.sqlite-shm from that stopped installation if present, restore the corresponding uploads and restart. Keep backups outside the public web root.

## Optional notifications

Configure `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` for merchant Telegram notifications. For merchant email, configure `SMTP_HOST`, `SMTP_PORT`, optional `SMTP_USER`/`SMTP_PASS`, `EMAIL_FROM` and `ORDER_EMAIL`. Notification failures do not roll back an order; failures are logged. No customer-email workflow or automated courier booking is included.

## Validation and limits

See TEST-REPORT.md. All tests use isolated temporary databases. No real funds are charged by this app. Mobile payments are recorded for manual verification; changing a refund status records a refund and does not transfer money. Service checkout does not automatically renew billing, provision tenant websites, enforce hosting quotas or suspend unpaid tenants. Those capabilities need separate business integrations.

Live cPanel hosting, real SMTP/Telegram delivery and real payment processing were not tested. The clean package contains no test database, test login or node_modules. Install dependencies using the lockfile.

## Design source

The design follows the downloaded VoltAgent Oura DESIGN.md reference, adapted for WebMart. See DESIGN.md, references/OURA-DESIGN.md and references/LICENSE-VoltAgent. Original catalog images are supplied by the user. No proprietary font files or external image/font services are required.
