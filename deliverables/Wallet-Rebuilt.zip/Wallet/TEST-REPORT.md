# Validation report — WebMart rebuild v6

Validated on 10 November 2026 using Node.js 24.22.1, Playwright 1.62.1 and system Chromium in the managed development environment.

## Results

- Clean extracted ZIP + `npm ci --omit=dev`: passed; health, catalog, HTML, browser modules and CSS smoke checks passed.
- `npm run check`: passed, including server/browser/test JavaScript syntax and every seeded product/gallery image path.
- `npm test`: 16/16 API integration tests passed against an isolated SQLite database.
- `npm run test:browser`: 58 browser checks passed; zero uncaught browser JavaScript exceptions.
- Legacy import smoke test: 8 products, 0 orders and 31 referenced images (30 product/gallery assets plus legacy logo) imported from the supplied archive. Merchant credentials were imported; sessions were not.
- Fresh merchant setup command: passed in an isolated data directory.
- `npm run backup`: created a consistent SQLite snapshot using `VACUUM INTO`.

## Browser coverage

Real Chromium flows covered the home page, all seeded home images, catalog text search, empty results, brand filtering, gallery image switching, saved products, cart quantity changes, full guest COD checkout, confirmation reload with private access, permanent rental variant selection with zero shipping, customer registration/logout, merchant login, product create/edit/remove, draft/save/publish/rollback, coupon creation and order-status update.

Layout assertions covered desktop (1440px) and 390px / 768px / 320px viewport widths. The narrow-width matrix covered home, shop, watch details, rental details, cart, checkout, account, saved products, offers, shipping policy, merchant overview, merchant products and store settings. No whole-page horizontal overflow was found. Merchant data tables scroll within their own containers.

## API coverage

- Public routing, browser modules, stylesheet, 404 and response security headers.
- All 8 seed products; no exposed cost or credential fields.
- Admin authentication, customer/admin separation, CSRF and origin enforcement.
- Customer registration, duplicate-email rejection and password requirements.
- Product validation, CRUD, stock, safe uploaded image paths and version conflicts.
- Server-priced quotes, insufficient stock and transactional rollback on price mismatch.
- Digital plan shipping and single-quantity enforcement.
- Checkout idempotency, private order access and account ownership.
- Concurrent last-item checkout: one success, one stock conflict; no overselling.
- Cancellation stock restoration exactly once; invalid/stale order transitions rejected.
- COD payment collection only after delivery; collected revenue calculation.
- Draft isolation, optimistic concurrency, publish and rollback.
- Coupon calculation and usage-limit enforcement.
- Manual mobile payment account enablement and duplicate verification-reference protection.
- Invalid image rejection and authenticated image upload/serving.
- Categories, aggregate page-view statistics, order export and logout.

## Fixed while testing

- A stale admin request could render after navigation. Requests scoped to the old navigation now stop updating the page.
- A mobile merchant sidebar forced the grid wider than the viewport. Grid minimum widths and the navigation scroller were corrected.
- Populated textareas and selects needed explicit accessible labels for reliable form targeting. These are now present.
- Reused modal validation IDs collided with page-level validation. Modal forms now use scoped error elements.
- Order update timestamps are monotonic so rapid edits retain optimistic-concurrency protection.

## Practical limits

This validates the supplied clean seed, local HTTP flows and the stated viewport sizes. It does not establish that every future content combination, browser or deployment is error-free. The original drag-and-drop Theme Studio, PC builder and unused historical admin tools were intentionally replaced/removed; see README.md for the exact scope.

No production site was deployed. Real cPanel hosting, mobile-money settlement, merchant SMTP/Telegram delivery, automated courier services and tenant subscription provisioning were not tested. The app records manual-payment verification and refund states; it does not transfer funds. Live contact details, payment numbers, policies and service agreements must be supplied by the merchant.

Test databases, generated logins, orders and uploaded test files are excluded from the delivery ZIP.
