# Font provenance

Downloaded 12 November 2026 from the official Google Fonts repository, with each family's OFL file included under public/fonts. There are no paid/proprietary font files or remote runtime font requests.

| Family | Official source directory | Use |
|---|---|---|
| Inter | https://github.com/google/fonts/tree/main/ofl/inter | Reading/forms |
| Roboto | https://github.com/google/fonts/tree/main/ofl/roboto | Prices and numeric UI |
| Poppins | https://github.com/google/fonts/tree/main/ofl/poppins | Brand and selected headings |
| Playfair Display | https://github.com/google/fonts/tree/main/ofl/playfairdisplay | Editorial accents |
| Geist Sans | https://github.com/google/fonts/tree/main/ofl/geist | Storefront headings and merchant/editor UI |
| JetBrains Mono | https://github.com/google/fonts/tree/main/ofl/jetbrainsmono | Reference IDs/code |

WOFF2 derivatives preserve font outlines, layout features and hinting. Inter's optical-size axis is pinned for screen text; Roboto's width is pinned to normal. Weight variation remains available; Poppins uses its regular/semibold/bold static masters. UI subsets retain Latin/Latin Extended, available Bengali glyphs, currency, arrows and common symbols. Families do not acquire unsupported scripts through subsetting: Bengali and other missing glyphs use the system fallback. This is not a claim that these fonts supply a complete Bengali typeface.

font-display: swap keeps content visible. Only used families/weights are fetched; technical monospace remains deferred until used; Geist is used by the public headings. The raw official licenses remain alongside the files.
