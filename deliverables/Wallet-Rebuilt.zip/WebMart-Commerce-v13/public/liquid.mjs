// Reference-inspired liquid fill and click ripple, with one semantic label and no click delay.
let installed=false;
export function installLiquid(){if(installed)return;installed=true;const pref=matchMedia('(prefers-reduced-motion: reduce)');let frame=0,last;
 const button=e=>{const b=e.target.closest?.('.btn.liquid-button');return b&&!b.disabled&&b.getAttribute('aria-disabled')!=='true'?b:null;};
 function origin(b,x,y){const rect=b.getBoundingClientRect();b.style.setProperty('--liq-x',Math.min(rect.width,Math.max(0,x-rect.left))+'px');b.style.setProperty('--liq-y',Math.min(rect.height,Math.max(0,y-rect.top))+'px');b.style.setProperty('--liq-size',Math.ceil(Math.hypot(rect.width,rect.height)*2.2)+'px');}
 document.addEventListener('pointerover',e=>{const b=button(e);if(!b||pref.matches||e.pointerType==='touch'||(e.relatedTarget instanceof Node&&b.contains(e.relatedTarget)))return;origin(b,e.clientX,e.clientY);},{passive:true});
 document.addEventListener('pointermove',e=>{const b=button(e);if(!b||pref.matches||e.pointerType==='touch')return;last={b,x:e.clientX,y:e.clientY};if(!frame)frame=requestAnimationFrame(()=>{frame=0;if(last?.b.isConnected)origin(last.b,last.x,last.y);last=null;});},{passive:true});
 document.addEventListener('focusin',e=>{const b=button(e);if(!b||pref.matches)return;const r=b.getBoundingClientRect();origin(b,r.left+r.width/2,r.top+r.height/2);});
 document.addEventListener('pointerdown',e=>{const b=button(e);if(!b||pref.matches)return;origin(b,e.clientX,e.clientY);const ring=b.querySelector('.liquid-ripple');if(!ring)return;ring.getAnimations().forEach(a=>a.cancel());ring.animate([{opacity:.6,transform:'translate(-50%,-50%) scale(.1)'},{opacity:0,transform:'translate(-50%,-50%) scale(2.3)'}],{duration:360,easing:'cubic-bezier(.2,.7,.2,1)'});},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&frame){cancelAnimationFrame(frame);frame=0;last=null;}});
}
export function decorateLiquid(button){if(button.querySelector(':scope > .liquid-surface'))return;const surface=document.createElement('span');surface.className='liquid-surface';surface.setAttribute('aria-hidden','true');surface.innerHTML='<span class="liquid-blob"></span><span class="liquid-ripple"></span>';button.prepend(surface);}
