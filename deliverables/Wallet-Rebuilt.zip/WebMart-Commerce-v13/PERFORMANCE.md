# Performance — WebMart Commerce v13

Measured in this workspace with Node 24.22.1 and Chromium 156, using a fresh browser context on localhost. Single synthetic runs, not field data or an internet-hosting guarantee. The second run configured 390px viewport, 4× CPU slowdown and CDP network throttling at 1.6 Mbps / 150 ms latency; localhost results remain environment-dependent.

| Measurement | Desktop localhost | Mobile synthetic settings |
|---|---:|---:|
| HTML TTFB | 12 ms | 20 ms |
| DOMContentLoaded | 185 ms | 1,242 ms |
| Observed largest contentful paint | 464 ms | 1,916 ms |
| Resource transfer observed | 551,791 bytes | 539,595 bytes |
| Resource count | 28 | 28 |
| External resources on home | 0 | 0 |
| Merchant/editor modules on home | 0 | 0 |

Measurements were taken after the hero appeared and a 600 ms observation window. Deferred/later slideshow resources may arrive afterward. Images, fonts and scripts are bundled locally. The initial hero image uses high fetch priority; product images are lazy. Brotli/gzip versions are generated from current CSS/MJS sources. Large uploaded screenshot images are reduced client-side without increasing file size. External product demos load on request, so another website’s latency is kept out of the initial product rendering.

Native route rendering introduces no navigation timer. Button/card responses generally complete in 120–180 ms and reduced-motion disables them. Live presence uses a 25-second visible-tab heartbeat. No public whole-page mutation observer or continuously animated decorative background runs.

Changing hero images, adding many videos/sections or embedding a slow external site can change these results. Use suitably sized media and persistent hosting close to your customers. The included tests check actual transitions, responsive overflow, loaded thumbnails, native navigation and deferred admin code; they do not assert an artificial universal speed score.
