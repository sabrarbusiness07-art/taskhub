# WebMart Commerce v13 verification

Environment: Node 24.22.1, npm 11.9, Chromium 156, Linux. Tests use temporary isolated databases and generated credentials. No real customer data or test passwords are delivered.

- `npm run build:assets`: 27 CSS/MJS assets precompressed.
- `npm run check`: JavaScript syntax, seed assets and matching gzip/Brotli sources passed.
- `npm test`: 58 API/migration/security tests passed.
- `npm run test:browser`: 18 desktop/mobile customer and merchant journey checks passed.
- Clean ZIP extraction: `npm ci --omit=dev` installed 73 production packages; all 58 API tests also passed against that installation. Merchant setup/login, all main server routes, Brotli responses and complete database/private-file/media backup smoke checks passed.

API coverage includes digital upload authorization/content checks, complete product metadata, public/private projections, billing/date/link validation, mixed-cart server pricing, duplicate/unavailable items, authentication/Origin/CSRF, stale price/version rejection, idempotent checkout and confirmation, customer ownership, atomic plan activation, purchase downloads, subscription expiry/suspension, declines, MP4/date/video section validation, and migration backups. Existing rental renewal, Bangladesh calendar arithmetic, analytics, draft/publish/rollback, fonts and compatibility tests remain included.

Browser coverage includes four-column desktop and two-column mobile products, full-width slideshow, liquid controls, loaded thumbnails, search, persistent wishlist/cart, yearly plan selection, scrollable live preview, full product editor with gallery/date/specifications/FAQ/private PDF, customer registration returning to checkout, mixed-order payment confirmation, customer expiry/download access, inline section insertion, keyboard and native drag ordering, countdown publication, product video sections, functional checkout/cart/account previews, published custom menu/submenu changes, responsive overflow and reduced-motion. No uncaught browser exceptions or server errors were observed.

The new commerce journey suite replaces UI suites that asserted the previous rental-only layouts. Existing API/migration assertions were updated for the two added commerce pages and the requested branding migration; prior branding is checked in its preserved snapshot.

Limitations: no live payment gateway, production-domain deployment, third-party iframe permission changes or automatic Laravel/hosting provisioning was tested. Payment and service setup remain merchant-managed. See PERFORMANCE.md for scoped synthetic measurements.
