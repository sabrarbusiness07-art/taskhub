'use strict';
const { createInterface } = require('node:readline/promises');
const { stdin, stdout } = require('node:process');
const path = require('node:path');
const crypto = require('node:crypto');
const { openStore, passwordHash } = require('../lib/store');
const { email: validateEmail } = require('../lib/validation');
(async () => {
  const prompt = createInterface({ input: stdin, output: stdout });
  let store;
  try {
    const email = validateEmail(process.env.ADMIN_EMAIL || await prompt.question('Merchant email: '));
    const name = (process.env.ADMIN_NAME || await prompt.question('Your name: ') || 'Merchant').trim();
    let password=process.env.ADMIN_PASSWORD;
    if (!password) {
      stdout.write('Password (at least 12 characters; input hidden): ');
      prompt.close();
      password = await new Promise((resolve,reject)=>{
        if (!stdin.isTTY) { reject(Error('For non-interactive setup, set ADMIN_EMAIL, ADMIN_NAME and ADMIN_PASSWORD.')); return; }
        stdin.setRawMode(true);stdin.resume();let value='';
        function receive(chunk){for(const ch of chunk.toString()){if(ch==='\r'||ch==='\n'){stdin.setRawMode(false);stdin.pause();stdin.removeListener('data',receive);stdout.write('\n');resolve(value);return;}if(ch==='\u0003'){stdin.setRawMode(false);stdin.pause();stdin.removeListener('data',receive);reject(Error('Setup cancelled'));return;}if(ch==='\u007f'||ch==='\b')value=value.slice(0,-1);else if(ch>=' ')value+=ch;}}
        stdin.on('data',receive);
      });
    }
    if (password.length < 12 || password.length > 200) throw Error('Use a password with 12–200 characters.');
    const {salt,hash}=await passwordHash(password);
    store=openStore(process.env.DATA_DIR || path.join(__dirname,'..','data'));
    const previous=store.db.prepare('SELECT id FROM users WHERE email=?').get(email);
    if(previous&&!process.argv.includes('--reset'))throw Error('This email already exists. Run npm run setup -- --reset to reset its merchant password.');
    store.tx(()=>{const id=previous?.id||crypto.randomUUID();store.db.prepare("INSERT INTO users VALUES(?,?,?,?,?,?) ON CONFLICT(email) DO UPDATE SET name=excluded.name,role='admin',salt=excluded.salt,hash=excluded.hash").run(id,email,name,'admin',salt,hash);if(previous)store.db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);store.audit('admin.setup',id);});
    console.log('Merchant access created. Open /admin and sign in.');
  } catch(error){console.error(error.message);process.exitCode=1;} finally {prompt.close();store?.close();}
})();
