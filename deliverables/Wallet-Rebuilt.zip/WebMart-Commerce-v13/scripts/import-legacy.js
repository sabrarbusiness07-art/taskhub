'use strict';
// Offline migration only: never starts or executes source-project code.
const {DatabaseSync}=require('node:sqlite');const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const {openStore}=require('../lib/store');
const source=process.argv[2];
if(!source){console.error('Usage: npm run import:legacy -- /absolute/path/to/old/Wallet');process.exit(1);}
const sourceRoot=path.resolve(source), file=path.join(sourceRoot,'data','store.sqlite');
if(!fs.existsSync(file)){console.error('No data/store.sqlite found in source folder.');process.exit(1);}
const destDir=process.env.DATA_DIR||path.join(__dirname,'..','data'),uploadDir=process.env.UPLOAD_DIR||path.join(__dirname,'..','public','uploads');
const sourceDb=new DatabaseSync(file,{readOnly:true});const target=openStore(destDir);
try{
 if(target.all('orders').length||target.db.prepare('SELECT count(*) AS n FROM users').get().n||target.get('config','legacy-imported'))throw Error('Import requires a fresh destination with no users or orders. Import before running setup.');
 const tableExists=t=>!!sourceDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(t);
 const rows=t=>tableExists(t)?sourceDb.prepare(`SELECT * FROM ${t}`).all():[];
 const products=rows('products').map(x=>JSON.parse(x.data));const orders=rows('orders').map(x=>JSON.parse(x.data));
 const configs=new Map(rows('config').map(x=>[x.id,JSON.parse(x.data)]));
 // Copy assets before committing data, including archived product/order references.
 fs.mkdirSync(uploadDir,{recursive:true});let copied=0;
 const referenced=new Set();const scan=value=>{if(typeof value==='string'){for(const m of value.matchAll(/\/uploads\/[\w. =-]+\.(?:png|jpg|jpeg|webp)/gi))referenced.add(m[0]);}else if(value&&typeof value==='object')for(const x of Object.values(value))scan(x);};scan(products);scan(orders);scan(configs.get('settings'));
 const oldUploads=path.join(sourceRoot,'public','uploads');if(fs.existsSync(oldUploads))for(const f of fs.readdirSync(oldUploads)){if(!/^[\w. =-]+\.(?:png|jpg|jpeg|webp)$/i.test(f)||!referenced.has('/uploads/'+f))continue;const from=path.join(oldUploads,f),to=path.join(uploadDir,f);if(!fs.statSync(from).isFile())continue;if(fs.existsSync(to)){if(!fs.readFileSync(from).equals(fs.readFileSync(to)))throw Error('An upload filename conflicts: '+f);}else{fs.copyFileSync(from,to,fs.constants.COPYFILE_EXCL);copied++;}}
 target.tx(()=>{
  target.db.exec('DELETE FROM products; DELETE FROM orders;');
  for(const p of products){p.name=String(p.name).replace(/^(?:Thumbnail\s*\d\s*)+/,'').replace(/[ |]+$/,'');p.images=p.images||[];target.put('products',p.id,p);}
  for(const order of orders)target.put('orders',order.id,{...order,discount:typeof order.discount==='object'?order.discount.amount:order.discount||0});
  const settings={...target.get('config','settings'),...configs.get('settings'),version:1};
  if(products[0]){settings.heroProductId=products[0].id;settings.heroImage=products[0].image;}
  target.put('config','settings',settings);target.put('config','draft',settings);
  const categories=configs.get('categories');if(categories)target.put('config','categories',categories.items||categories);
  const coupons=configs.get('coupons');if(coupons)target.put('config','coupons',coupons.items||coupons);
  for(const admin of rows('admins')){target.db.prepare('INSERT OR IGNORE INTO users VALUES(?,?,?,?,?,?)').run(crypto.randomUUID(),admin.email,'Merchant','admin',admin.salt,admin.hash);}
  // Customers in the original version use the same scrypt credentials.
  for(const row of rows('customers')){
   const customer=row.data?JSON.parse(row.data):row;
   if(!customer.email||!customer.salt||!customer.hash)throw Error('Unsupported customer credential record; no business records were imported.');
   target.db.prepare('INSERT OR IGNORE INTO users VALUES(?,?,?,?,?,?)').run(customer.id,customer.email,customer.name||'Customer','customer',customer.salt,customer.hash);
  }
  for(const r of rows('transactions'))target.db.prepare('INSERT OR IGNORE INTO payments VALUES(?,?)').run(r.reference,r.order_id);
  target.put('config','legacy-imported',{at:new Date().toISOString(),products:products.length,orders:orders.length});target.audit('legacy.import',products.length+' products / '+orders.length+' orders');
 });
 console.log(`Imported ${products.length} products, ${orders.length} orders and ${copied} images. Legacy sessions are intentionally expired. Sign in again.`);
 console.log('Historical theme-builder configurations are not imported. Review store settings and policies before publishing.');
}catch(error){console.error(error.message);process.exitCode=1;}finally{sourceDb.close();target.close();}
