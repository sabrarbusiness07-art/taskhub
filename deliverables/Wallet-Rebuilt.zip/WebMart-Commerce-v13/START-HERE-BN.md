# WebMart Commerce v13 — শুরু করুন

এই ZIP একটি সম্পূর্ণ digital-product ecommerce website: এককালীন কেনা এবং মাসিক/বার্ষিক service plan—দুটিই আছে। আপনার logo অনুযায়ী purple–magenta রঙ, product grid, search, cart, customer account এবং visual page editor যুক্ত আছে।

## Windows-এ চালানো

Node.js 24.x (কমপক্ষে 24.14) ইনস্টল করুন। ZIP নতুন folder-এ extract করে VS Code terminal-এ চালান:

```powershell
npm.cmd ci
npm.cmd run setup
npm.cmd start
```

Setup-এ নিজের merchant email, নাম ও কমপক্ষে ১২ অক্ষরের password দিন। Password terminal-এ দেখা যাবে না। কোনো default ID/password নেই। পুরোনো data ব্যবহার করলে আগের login-ই থাকবে; আবার setup দরকার নেই।

Website: http://localhost:5000
Admin: http://localhost:5000/admin

`START-WEBMART.cmd` double-click করেও server চালাতে পারবেন। Terminal খোলা রাখুন। বন্ধ করতে Ctrl+C।

## Product যোগ করবেন যেভাবে

Admin → Products & services → Add product। Name/category/type, description, ছবি/gallery, video, release date, specifications, FAQ, license/support/delivery এবং live preview link দিন। Billing model বেছে নিন: One-time, Monthly/yearly, অথবা দুটোই। দামের ঘরে BDT লিখুন; yearly price সম্পূর্ণ বছরের মোট দাম। আগে Draft রেখে সম্পাদনা করতে পারেন; প্রস্তুত হলে Published করুন।

Public HTTPS website link দিলে product page-এ scroll করা যায় এমন live preview থাকবে। বাইরের website embed বন্ধ রাখলে Open live button ব্যবহার করতে হবে। ZIP/PDF upload করলে payment confirm হওয়ার আগে সেটি public হবে না।

## Page editor

Admin → Theme editor। ওপর থেকে page নির্বাচন করুন। Preview ও sidebar-এর মাঝখানে থাকা “+ Add section” দিয়ে section যোগ করুন। Drag করে উপরে/নিচে নিন, অথবা Move up/down ব্যবহার করুন। Text/ছবিতে click করে edit করুন। Video, date/countdown, gallery, FAQ, product collection-ও যোগ করা যাবে। Date/time বাংলাদেশ সময় ধরে ব্যবহার হয়। Save draft → Publish করুন।

Style tab থেকে header menu/submenu ও footer link edit করুন। Hero slideshow-এর ছবি/mobile ছবি, link ও text-এর জন্য Store settings-এ যান; hero section inspector-এ সরাসরি link আছে। Product-এর দাম/plan/details Products & services থেকে বদলাবেন।

## Customer order ও plan

Customer product/plan নির্বাচন করে cart → checkout করবে। Admin → Orders & customer plans থেকে order খুলুন। Payment যাচাই করে confirmation দিন। তখন one-time purchase-এর download এবং subscription-এর start/expiry account-এ দেখা যাবে। Plan মাস/বছরের calendar মেয়াদ অনুযায়ী চলে; payment বা renewal স্বয়ংক্রিয়ভাবে charge হয় না। Laravel website deploy/hosting setup আপনার team করবে।

Analytics-এ live viewer, views history এবং কোন product বেশি দেখা হয়েছে দেখা যাবে।

## পুরোনো project আপগ্রেড

আগের server বন্ধ করে পুরো folder backup রাখুন। নতুন ZIP আলাদা folder-এ extract করুন। পুরোনো `data`, `public/uploads` এবং থাকলে `public/media` নতুন folder-এর একই জায়গায় copy করুন। পুরোনো code/node_modules copy করবেন না। তারপর `npm.cmd ci` ও `npm.cmd start`। Account ও পুরোনো paid plan/order থাকে; purple–magenta design প্রথমবার apply হয়। বিস্তারিত README.md-তে আছে।
