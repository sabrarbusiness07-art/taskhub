'use strict';
const { createApp } = require('./application');
const { app, store } = createApp();
const host = process.env.HOST || '127.0.0.1', port = Number(process.env.PORT || 5000);
const server = app.listen(port, host, () => console.log(`WebMart: ${process.env.PUBLIC_URL || 'http://localhost:' + port}`));
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => { server.close(() => { store.close(); process.exit(0); }); });
