# WebMart Commerce v13 design notes

## Sources used

The supplied Wallet-Rebuilt ZIP is the functional starting point. The supplied Tech Bazar source informed section insertion, section lists, drag ordering and per-field controls. Techland and Ghorerbazar informed ecommerce hierarchy: search-led header, category navigation, category tiles, image-led product grid, a product purchase panel and order/account flows. Their brand assets, customer data and product descriptions are not bundled.

The latest supplied W logo defines the palette: purple #7209df / #861de5 and magenta #ee27bd. Soft lilac panels, off-white background, dark plum text and restrained hairlines make the product information easy to scan. The scalable W mark follows that logo’s white-letter/gradient treatment.

The supplied design archive’s Figma, Shopify and Stripe design notes inform spacing, grid, typography, editorial colour panels and inspector layout. The relevant original reference files and VoltAgent license are under references/. The component JSON references informed the liquid-button and pricing interactions. The app uses native CSS/JavaScript adaptations and does not require React/Framer Motion. “Figma style” describes the visual language and builder; no .fig file or external Figma integration is claimed.

## Storefront

Four-column desktop / two-column mobile product grid; catalogue sidebar becomes an inline mobile filter. Purple pill actions have a short liquid hover/focus response. Prices use Roboto, public headings use Geist, body copy uses Inter, branding uses Poppins, editorial accents use Playfair Display, technical identifiers use JetBrains Mono. All font files/licenses ship locally with swap rendering.

Hero uses the existing merchant-editable full-width image slideshow with mobile images, arrows, dots, pause and keyboard controls. Product pages include gallery, plan/term choice, one-time billing where offered, cart actions, metadata, FAQ, video and a real scrollable demo frame. External preview loading is explicit; Open live remains available for sites that reject embedding.

## Merchant tools

Product Studio separates essentials, media, information, preview, pricing and private delivery. Theme Studio uses a light three-pane workspace with a section list, live draft preview and inspector. Inline plus controls insert before/after sections; drag and keyboard reordering remain available. Text, images, video, dates/countdowns and collections share validated section data. Existing commerce/account controls remain functional and customer-specific data is not turned into static page copy.

## Performance

Native route changes have no added navigation delay. Transitions are generally 120–180 ms, with reduced-motion support. There are no animated whole-page snapshots, continuously running decorative canvases or remote font/CDN dependencies. Hero is eager/high-priority; product images are lazy. Uploaded screenshots are compressed client-side. Public CSS/MJS ship precompressed; admin modules/styles load on merchant routes. See PERFORMANCE.md for measured scope and limits.
