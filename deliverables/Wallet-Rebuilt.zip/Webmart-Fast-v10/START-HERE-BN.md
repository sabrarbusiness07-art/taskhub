# WebMart Fast v10 — শুরু করো

পুরোনো server বন্ধ করে পুরো folder backup রাখো। ZIP আলাদা করে extract করে পুরোনো `data` ও নিজের `public/uploads` নতুন folder-এ কপি করো। পুরোনো code/node_modules কপি কোরো না। আগের account, plans, expiry ও theme থাকবে।

Node.js 24 (24.14+) দিয়ে project terminal-এ:

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

শুধু নতুন installation হলে start-এর আগে `node scripts/setup-admin.js` চালিয়ে নিজের merchant email/password তৈরি করো। Website http://localhost:5000, admin http://localhost:5000/admin।

## Homepage thumbnail ও live preview

Services & templates → Edit service → Listing type: Website template। Service preview image-এ thumbnail upload করো। Public HTTPS demo URL-এ আসল website link দাও। Featured on homepage tick করে Save service করো। Home-এ শুধু সেই website-এর clickable thumbnail থাকবে; click করলে product page। অন্য featured website স্বয়ংক্রিয়ভাবে বাদ যাবে।

Product page-এর frame-এর ভেতর scroll করে demo দেখা যাবে। Open live preview নতুন tab-এ আসল website খুলবে। নিজের website হলে preview style Custom design / external demo দাও। কোনো website নিজে iframe block করলে সেখানে embedding allow করতে হবে; Live button দিয়ে তবু খোলা যাবে।

## Menu / submenu

Theme editor → Style → Header menu & submenus। Parent link-এর নাম/URL বদলাও; Add submenu দিয়ে child নাম/URL দাও। Remove ও ↑/↓ দিয়ে menu সাজাও। Footer links-ও বদলাতে পারবে। Publish করলে desktop ও mobile-এ দেখা যাবে। Header-এ প্রথম দুইটি parent shortcut; Explore-এ পুরো menu/submenu।

Animation এখন ছোট ও দ্রুত; লেখা দেখার জন্য animation শেষ হওয়ার অপেক্ষা করতে হয় না। PERFORMANCE.md-এ মাপা speed comparison আছে। Manual CSS/JS edit করলে `npm run build:assets` চালাবে; Theme Editor বা product পরিবর্তনে লাগবে না।

## Rental কাজের নিয়ম

- **Services & templates:** service, plans, features, monthly/yearly দাম ও visibility বদলাও।
- Customer plan বেছে নিজের account খুলে request করবে। সঙ্গে সঙ্গে active হবে না।
- **Customer rentals → Review:** বাস্তবে payment পাওয়ার পর checkbox দিয়ে confirm করো। Website link এবং customer message দিতে পারো। তখন plan-এর মেয়াদ শুরু হবে।
- Customer **My workspace**-এ plan, expiry, remaining days, history, renewal এবং cancellation request দেখবে।
- Admin subscription-এর status, expiry, customer message ও private notes manage করবে। Private notes customer দেখবে না।
- Renewal confirm করলে মেয়াদ বাড়বে। টাকা স্বয়ংক্রিয় কাটবে না; website তৈরি/hosting suspend/refund নিজে করতে হবে।
- **Settings:** contact ও manual bKash/Nagad/Rocket account দাও। না দিলে invoice arrangement থাকবে।

## Theme editor

16টি built-in page এবং custom pages সম্পাদনা করতে পারবে। Preview-এ লেখা/link/image click করো। **Add section** দিয়ে নতুন section যোগ করো। বাম পাশের section row/handle drag করে উপরে-নিচে নাও; keyboard-এ Alt+ArrowUp/Down অথবা Move up/down আছে। Touch handle-ও ব্যবহার করা যায়।

**Save draft** খসড়া রাখে; **Publish** live করে। Style-এ colours/fonts/menu, Page-এ title/SEO, More-এ import/export/rollback। Actual plan price Services & templates থেকে বদলাবে; customer data ও checkout calculation arbitrary text edit দিয়ে বদলায় না।

**Analytics**-এ live browsers, page/service views ও history দেখবে। Live মানে শেষ ৯০ সেকেন্ডে active browser; নিজের admin/preview বাদ যায়। Test করতে incognito browser-এ website খোলো।

`/api/health`-এ `webmart-fast-10.0.0` দেখাবে। চালু করতে সমস্যা হলে terminal-এর error দেখো; পুরোনো node_modules এনে বসাবে না।
