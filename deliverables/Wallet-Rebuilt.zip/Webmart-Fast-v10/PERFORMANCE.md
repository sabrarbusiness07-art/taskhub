# WebMart Fast v10 — measured comparison

Chromium on Linux; 3 fresh browser contexts per version; cache disabled; simulated 80 ms latency, 1.6 Mbps download and 4× CPU slowdown. Same starter catalogue; v10 displays the requested single homepage thumbnail. These local controlled results do not guarantee production speed on every device, connection or host.

| Homepage measurement | v9 | v10 |
|---|---:|---:|
| Encoded resource bytes | 700,364 | 199,941 |
| Resource requests | 22 | 16 |
| Admin/editor resources on public page | 4 | 0 |
| Median first contentful paint | 956 ms | 576 ms |

Resource downloads fell 71.4%; median first contentful paint improved 39.7%. Raw runs are in PERFORMANCE-RESULTS.json. This measures FCP/resource delivery, not a production Core Web Vitals audit or external-demo loading speed.

Changes: lazy admin/editor loading, precompressed Brotli/gzip static assets, asynchronous gzip store JSON, full-glyph WOFF2 fonts replacing TTF, preloaded fonts, no whole-page transition snapshots, no whole-page reveal observers, no SVG turbulence filter on every button, no blur-based content entrance, shorter 120–200 ms interactions and a single homepage thumbnail. Text stays visible immediately; reduced motion is respected. Fonts retain their original licensed outlines and glyphs.

Static code revalidates with ETags to avoid serving stale releases. API/session/draft responses remain private/no-store. Compressed responses vary by Accept-Encoding; uncompressed fallback works. External demo loading still depends on the demo site's server. No proxy is used to bypass its framing policy.

After manual public source edits, run `npm run build:assets`; `npm run check` rejects stale compressed CSS/JS. Theme-editor edits and catalogue changes need no asset rebuild.

The actual uploaded screenshot also has a negotiated WebP alternative: 536,639 → 82,770 bytes (84.6% smaller). Its existing database URL and original JPG are preserved; new uploads are optimised in the merchant browser.
