# WebMart Fast v10 verification

Verified 11 November 2026, Node 24.22.1 and Chromium 156 on Linux. All API/browser fixtures use disposable data and generated credentials.

- API/schema/migration/security: 37 cases.
- All-page visual editor: 20 browser cases.
- Rental signup, checkout, activation, renewal and account: 19 browser cases.
- Template catalogue, responsive preview, pricing and rental workflow: 13 browser cases.
- New performance/navigation/live-preview workflow: 11 cases.

**Total: 100 passed, zero failed.**

The new cases verify safe nested menu validation and publication; one featured homepage listing; Brotli, gzip and identity delivery; no admin/editor downloads on the public homepage; immediate content visibility; desktop/mobile submenus; a real scrollable HTTPS iframe with matching live button; and actual submenu creation/publication through Theme Studio. Responsive coverage includes 320/390/768 px. A browser-intercepted HTTPS demo fixture exercises iframe scrolling; arbitrary third-party website availability and framing policies are not certified.

Performance was measured with three cold-cache runs per release using throttled networking/CPU. See PERFORMANCE.md and raw PERFORMANCE-RESULTS.json. Payment settlement, production hosting, real-device Safari/iOS and Windows batch execution are outside this test environment. No private database, credentials or .env file is included in the release.

The supplied v9 database was tested on a consistent disposable copy: every users/orders/subscriptions/config row was unchanged on v10 startup. The uploaded 536,639-byte screenshot has an 82,770-byte WebP delivery alternative while the original is retained. New screenshot uploads are compressed in the merchant browser with an unchanged-original fallback.

Clean extracted production ZIP passed npm ci, compressed-asset integrity checks, merchant setup/login, actual server startup, WOFF2 fonts, Brotli/gzip, WebP image negotiation, all 16 page templates and private-data exclusion.
