'use strict';
const express = require('express');
const multer = require('multer');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { openStore, digest, passwordHash, passwordMatches } = require('./lib/store');
const v = require('./lib/validation');
function createApp(options = {}) {
  const dataDir = options.dataDir || process.env.DATA_DIR || path.join(__dirname, 'data');
  const uploadDir = options.uploadDir || process.env.UPLOAD_DIR || path.join(__dirname, 'public', 'uploads');
  fs.mkdirSync(uploadDir, { recursive: true });
  const store = openStore(dataDir), app = express();
  const origin = new URL(options.origin || process.env.PUBLIC_URL || 'http://localhost:' + (process.env.PORT || 5000)).origin;
  const secure = origin.startsWith('https:');
  if (process.env.NODE_ENV === 'production' && !secure) throw Error('Set PUBLIC_URL to your HTTPS production URL');
  app.disable('x-powered-by');
  if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);
  app.use((req, res, next) => {
    res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'same-origin', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; frame-src 'self' https:; frame-ancestors 'self'; base-uri 'none'; form-action 'self'" });
    if (secure) res.set('Strict-Transport-Security', 'max-age=31536000');
    if (req.path.startsWith('/api/')) {
      res.set('Cache-Control', 'no-store');
      if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && req.get('origin') !== origin) return res.status(403).json({ error: 'Open the configured store URL before making changes.' });
    }
    next();
  });
  app.use(express.json({ limit: '250kb' }));
  app.use('/api', (req, res, next) => { if (req.body === undefined) req.body = {}; next(); });
  const buckets = new Map();
  const limit = (name, max) => (req, res, next) => {
    const now = Date.now(); for (const [key, value] of buckets) if (value.until < now) buckets.delete(key);
    if (buckets.size > 10000) return res.status(503).json({ error: 'Please try again shortly.' });
    const key = name + ':' + req.ip, entry = buckets.get(key) || { n: 0, until: now + 900000 }; buckets.set(key, entry);
    if (++entry.n > max) return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' }); next();
  };
  function session(req) {
    const token = (req.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith('wm_session='))?.slice(11);
    if (!token) return null;
    return store.db.prepare('SELECT s.*, u.id, u.email, u.name, u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?').get(digest(token), Date.now());
  }
  const auth = (req, res, next) => {
    req.user = session(req); if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
    if (!['GET', 'HEAD'].includes(req.method) && req.get('x-csrf-token') !== req.user.csrf) return res.status(403).json({ error: 'Session expired. Reload and try again.' }); next();
  };
  const admin = [auth, (req, res, next) => req.user.role === 'admin' ? next() : res.status(403).json({ error: 'Merchant access required.' })];
  const rentals = require('./lib/rentals').attach({ app, store, auth, admin, limit, now: options.rentalNow || Date.now });
  require('./lib/site-editor').attach({ app, store, admin, session });
  const analytics = require('./lib/analytics').attach({ app, store, admin, session, limit, secure, now: options.analyticsNow || Date.now });
  function startSession(res, user) {
    const token = crypto.randomBytes(32).toString('hex'), csrf = crypto.randomBytes(24).toString('hex');
    store.db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
    store.db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(digest(token), user.id, csrf, Date.now() + 8 * 3600000);
    res.cookie('wm_session', token, { httpOnly: true, sameSite: 'strict', secure, path: '/', maxAge: 8 * 3600000 });
    return { user: { id: user.id, email: user.email, name: user.name, role: user.role }, csrf };
  }
  app.get('/api/health', (req, res) => res.json({ ok: true, release: 'webmart-fast-10.0.0' }));
  app.get('/api/session', (req, res) => { const user = session(req); res.json(user ? { user: { id: user.id, name: user.name, email: user.email, role: user.role }, csrf: user.csrf } : { user: null, csrf: '' }); });
  app.post('/api/auth/register', limit('auth', 20), async (req, res) => {
    const name = v.text(req.body.name, 'name', 100), email = v.email(req.body.email), password = v.text(req.body.password, 'password', 200);
    if (password.length < 10) v.fail('Use at least 10 characters for your password');
    if (store.db.prepare('SELECT id FROM users WHERE email=?').get(email)) v.fail('This email is already registered.', 409);
    const credentials = await passwordHash(password), user = { id: crypto.randomUUID(), name, email, role: 'customer', ...credentials };
    try { store.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run(user.id, email, name, 'customer', credentials.salt, credentials.hash); }
    catch (error) { if (error.code?.includes('CONSTRAINT')) v.fail('This email is already registered.', 409); throw error; }
    res.status(201).json(startSession(res, user));
  });
  app.post('/api/auth/login', limit('auth', 20), async (req, res) => {
    const email = v.email(req.body.email), password = v.text(req.body.password, 'password', 200);
    const user = store.db.prepare('SELECT * FROM users WHERE email=?').get(email);
    if (!await passwordMatches(password, user)) v.fail('Incorrect email or password.', 401);
    res.json(startSession(res, user));
  });
  app.post('/api/auth/logout', auth, (req, res) => { store.db.prepare('DELETE FROM sessions WHERE token=?').run(req.user.token); res.clearCookie('wm_session', { path: '/', secure, sameSite: 'strict' }); res.json({ ok: true }); });
  app.get('/api/store',(req,res)=>{const preview=req.query.editorPreview==='1';if(preview&&session(req)?.role!=='admin')return res.status(403).json({error:'Merchant access required for draft preview'});const services=rentals.services();require('./lib/performance').json(req,res,{settings:store.get('config','settings'),siteTheme:store.get('config',preview?'site-draft':'site-live'),categories:store.get('config','categories'),services,products:services});});
  app.post(['/api/quote','/api/orders'],(req,res)=>res.status(410).json({error:'This is a rental-only platform. Use plan selection and rental requests.'}));
  app.get('/api/templates',(req,res)=>res.json(rentals.services().filter(s=>s.offeringType==='template')));
  app.get('/api/products/:id',(req,res)=>res.redirect(302,'/api/services/'+encodeURIComponent(req.params.id)));
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 0 } });
  app.post('/api/admin/uploads', ...admin, upload.single('image'), (req, res) => {
    const buffer = req.file?.buffer; if (!buffer) v.fail('Choose an image'); let ext;
    if (buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) ext = '.png';
    else if (buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255) ext = '.jpg';
    else if (buffer.subarray(0, 4).toString() === 'RIFF' && buffer.subarray(8, 12).toString() === 'WEBP') ext = '.webp';
    else v.fail('Only PNG, JPEG and WebP images are allowed');
    const name = crypto.randomUUID() + ext; fs.writeFileSync(path.join(uploadDir, name), buffer, { flag: 'wx' }); res.status(201).json({ image: '/uploads/' + name });
  });
  app.get('/api/admin/theme', ...admin, (req, res) => res.json(store.get('config', 'draft')));
  app.put('/api/admin/theme', ...admin, (req, res) => {
    const old = store.get('config', 'draft'); if (req.body.version !== old.version) v.fail('Draft changed. Reload before saving.', 409);
    const s = { ...v.settings(req.body, old), version: old.version + 1 }; store.put('config', 'draft', s); store.audit('theme.draft', s.version); res.json(s);
  });
  app.post('/api/admin/theme/publish', ...admin, (req, res) => {
    const draft = store.get('config', 'draft'); if (req.body.version !== draft.version) v.fail('Draft changed. Reload before publishing.', 409);
    store.put('config', 'previous', store.get('config', 'settings')); store.put('config', 'settings', draft); store.audit('theme.publish', draft.version); res.json(draft);
  });
  app.post('/api/admin/theme/rollback', ...admin, (req, res) => {
    const previous = store.get('config', 'previous'); if (!previous) v.fail('No previous published theme is available');
    const current = store.get('config', 'settings'), restored = { ...previous, version: Math.max(current.version, store.get('config', 'draft').version) + 1 };
    store.put('config', 'previous', current); store.put('config', 'settings', restored); store.put('config', 'draft', restored); store.audit('theme.rollback', restored.version); res.json(restored);
  });
  app.use('/uploads',require('./lib/performance').image(uploadDir));
  app.use('/uploads', express.static(uploadDir, { dotfiles: 'deny', index: false, maxAge: '7d' }));
  app.use(require('./lib/performance').compressed(path.join(__dirname,'public')));
  app.use(express.static(path.join(__dirname, 'public'), { index: false, dotfiles: 'deny', maxAge: 0 }));
  const legacy = { '/index.html': '/', '/collection.html': '/shop', '/product.html': '/product', '/cart.html': '/cart', '/checkout.html': '/checkout', '/account.html': '/account', '/my-orders.html': '/account', '/login.html': '/account', '/admin.html': '/admin', '/admin-products.html': '/admin/products', '/theme-editor.html': '/admin/editor', '/admin-suite.html': '/admin', '/categories.html': '/admin/categories', '/offers.html': '/offers', '/visitor-report.html': '/admin', '/invoice.html': '/order' };
  for (const [from, to] of Object.entries(legacy)) app.get(from, (req, res) => res.redirect(302, to + (req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '')));
  app.use('/api', (req, res) => res.status(404).json({ error: 'API endpoint not found' }));
  app.get(['/', '/shop', '/product', '/cart', '/checkout', '/account', '/saved', '/offers', '/order', '/page', '/services', '/plans', '/service', '/templates', '/template', '/admin', '/admin/products', '/admin/orders', '/admin/customers', '/admin/categories', '/admin/theme', '/admin/coupons', '/admin/rentals', '/admin/services', '/admin/editor', '/admin/analytics'], (req, res) => { res.set('Cache-Control', 'no-store'); res.sendFile(path.join(__dirname, 'public', 'index.html')); });
  app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', '404.html')));
  app.use((error, req, res, next) => { const status = error.code === 'LIMIT_FILE_SIZE' ? 413 : error instanceof multer.MulterError ? 400 : error.status || 500; if (status === 500) console.error(error); res.status(status).json({ error: status === 500 ? 'Unexpected server error. Please try again.' : error.code === 'LIMIT_FILE_SIZE' ? 'Image must be smaller than 5 MB' : error.message }); });
  return { app, store };
}
module.exports = { createApp };
