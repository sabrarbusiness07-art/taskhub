# WebMart Fast v10

Start with START-HERE-BN.md. Preserve your existing private data/uploads during upgrade. No default merchant password is shipped.

## New controls

Theme editor → Style → Header menu & submenus: add/edit/remove parent links and up to 12 submenu links per parent, and reorder parent/footer links. Save/Publish updates desktop navigation, the Explore menu and mobile drawer. Menu data is validated server-side. Header quick links use the first two configured parents; Explore shows the full menu.

Services & templates → Edit service: upload the website thumbnail, set Listing type to Website template, enter Public HTTPS demo URL, and enable Featured on homepage. Saving a featured template unfeatures the others. The homepage shows one clickable thumbnail; clicking it opens its product details. The gallery still lists the other templates. The product page displays the actual demo in a scrollable sandboxed iframe and an Open live preview button. The supplied URL is used directly, including when preview style is Custom. Built-in starter demos still work without an external URL.

Some websites disallow embedding with X-Frame-Options or CSP frame-ancestors. Their server must allow your storefront's origin for inline preview; Open live preview remains available. Cross-origin policy prevents reliably detecting every blocked frame. Do not put private admin URLs or credentials into public demo links. The application neither proxies nor circumvents a target's embedding policy.

Performance improvements and measured limits are documented in PERFORMANCE.md. Font outlines remain Plus Jakarta Sans and Manrope, now locally served as smaller WOFF2 files with improved text sizing. Interactions are short; public content no longer waits for scroll reveals. Admin code/styles load only for merchant routes. After manual public-code edits run `npm run build:assets`, then `npm run check`.

## Upgrade from v9

Stop the old server and keep the complete folder as a backup. Extract this release separately, copy your private `data` and own `public/uploads` into the matching locations, then install dependencies and start. Accounts, rental expiry, requests, themes and catalogue are retained. No v9 records are reset. Existing multiple featured flags are rendered as one thumbnail; saving your chosen featured template makes it exclusive.

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

Fresh installation only: run `node scripts/setup-admin.js` before starting. Node 24.14+ in the 24.x line is required. Store http://localhost:5000; merchant /admin; Theme Studio /admin/editor.

## Full verification

```sh
npm ci
npm run check
npm test
npx playwright install chromium
npm run test:browser
npm run test:editor
npm run test:templates
npm run test:fast
```

## Rental operations

Services & templates manages service copy, imagery, enabled plans, features and separate monthly/yearly BDT prices. Customer rentals contains pending requests and confirmed subscriptions. A request does not activate a plan. The merchant must verify the actual payment before confirming; activation records its amount, start and calendar expiry. Confirmation retries cannot activate/extend twice; verified mobile payment references cannot be reused. Changed catalogue prices require the customer to review a new quote; an already submitted request retains its agreed price.

Customers see their own selected plan, billing term, expiry, remaining days, service link, merchant messages and rental history. Renewal of the same plan and term extends from the current expiry, or from confirmation when expired. Cancellation is a customer request for merchant review. Merchants can set service URLs, customer messages, private notes, suspension, cancellation and expiry adjustments. Dates display in Asia/Dhaka. Calendar billing handles short months and leap years. Expired state is computed on reads.

Payment is an invoice arrangement or configured manual bKash/Nagad/Rocket reference, verified by the merchant. This application records rental entitlements; website provisioning, actual hosting suspension, recurring charging and refunds are manual external operations. No gateway, deployment automation or recurring-charge integration is included. Fresh service features are editable starting scope, which the merchant should align with the service they supply.

## Theme Studio

16 built-in page templates: Home, Website templates, Template details, Services, Plans, Service, Checkout, Account, Login, Register, Request confirmation, About, Contact, Terms, Privacy and Help. Custom pages use `/page?name=your-handle`. Static copy, links, colours, spacing and images can be edited in the preview. Add hero, text, image, service collection, categories, feature cards, FAQ, gallery, CTA, announcement, spacer and divider sections. Drag section rows or their handles up/down; Alt+ArrowUp/Down and Move up/down provide keyboard alternatives. Touch handles support pointer dragging. Duplicate/hide/delete added sections. Required functional cores remain protected.

Presentation edits do not rewrite live customer records, calculated prices, authentication or required form logic: manage actual services and subscriptions in their merchant screens. Drafts remain private until Publish. All edited templates publish together with version checks; conflicting tabs are rejected. Undo/redo, custom pages, JSON import/export, discard and previous-publication restore are retained. Imports validate allowed fields and safe links, without arbitrary code or HTML. Limits include 40 pages, 50 sections/page, 700 copy overrides/page and 5 MB image uploads.

The liquid default uses self-hosted WOFF2 Plus Jakarta Sans and Manrope with their OFL licenses. Pointer-responsive pill buttons, glass surfaces, a notch-style header, mega menu, accessible mobile drawer and segmented pricing are adapted from the supplied JSON references; they use native DOM/CSS rather than an added React runtime. Older warm/midnight palettes remain optional. See DESIGN.md and references/components.

## Analytics

Analytics shows live browser activity, page/service popularity, daily view history, device mix and CSV export over 7/30/90-day ranges. Visible tabs send heartbeats about every 25 seconds; browsers active within 90 seconds count as live. Dashboard refreshes every 10 seconds. Merchant and editor-preview traffic is excluded. A browser is counted once across multiple tabs. Cookies provide pseudonymous browser identities; IPs, fingerprints and customer identities are not stored in analytics. Counts measure recorded browser activity, not verified unique people. Legacy aggregate views remain separately visible. New service-level history begins after the analytics upgrade.

## Hosting and backups

Use persistent single-instance Node 24 hosting with writable private data and uploads. Set NODE_ENV=production and PUBLIC_URL to the exact HTTPS origin. HOST defaults to 127.0.0.1 and PORT to 5000. TRUST_PROXY=1 is appropriate only behind one trusted reverse proxy. DATA_DIR and UPLOAD_DIR override storage locations. Configure variables on the host; .env files are not loaded automatically. Run `npm run backup` and back up uploads separately. To restore, stop the app, restore the matching database/uploads, remove stale WAL/SHM files from the stopped installation if needed and restart. Keep backups outside public/uploads.

## Verification

```sh
npm ci
npm run check
npm test
npx playwright install chromium
npm run test:browser
npm run test:editor
npm run test:templates
```

BROWSER_EXECUTABLE may point to an installed Chromium binary. BROWSER_ARTIFACTS selects a screenshot/results folder. Tests use disposable databases and generated credentials. See TEST-REPORT.md for actual results and limits. Legacy v5 import tooling is retained only for explicit older-format migration; it is not the v7 upgrade path.
