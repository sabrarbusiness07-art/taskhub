export const defaults=[{"image": "/assets/market/main-websites.webp", "mobileImage":"/assets/market/main-websites-mobile.webp", "alt": "Ready-to-launch websites", "href": "/shop?type=website"}, {"image": "/assets/market/main-store.webp", "mobileImage":"/assets/market/main-store-mobile.webp", "alt": "Online store website rentals", "href": "/product?id=template-forma"}, {"image": "/assets/market/main-services.webp", "mobileImage":"/assets/market/main-services-mobile.webp", "alt": "Digital services for your business", "href": "/services"}];
export function slideshow(settings,{esc:e,icon,money,minimum=null}){const slides=settings.heroSlides??defaults,promos=settings.heroArrangement==='split'?(settings.heroPromos||[]):[],layout=settings.heroLayout||'overlay';if(!slides.length&&!promos.length)return'';return `<div class="hero-stage ${promos.length?'hero-stage-split':''}" data-home-section="home-hero" data-mobile-promos="${settings.heroShowPromosMobile===true}">${slides.length?`<section class="hero-banner hero-slideshow" data-layout="${layout}" data-content-side="${settings.heroTextSide||'right'}" data-fit="${settings.heroImageFit||'cover'}" aria-label="Featured products" aria-roledescription="carousel" tabindex="0"><h1 class="mobile-hero-title sr-only">${e(settings.heroTitle||settings.name)}</h1><div class="hero-slide-viewport">${slides.map((s,i)=>`<a class="hero-slide" data-slide="${i}" href="${e(s.href||'/shop')}" ${i?'hidden':'data-active="true"'}><picture>${s.mobileImage?`<source media="(max-width:640px)" srcset="${e(s.mobileImage)}">`:''}<img data-portrait-stock="${s.mobileImage?.startsWith('/assets/heroes/')===true}" src="${e(s.image)}" alt="${e(s.alt||'Featured product')}" width="1920" height="840" loading="${i?'lazy':'eager'}" decoding="async" ${i?'':'fetchpriority="high"'}></picture></a>`).join('')}</div>${layout==='overlay'?`<div class="hero-banner-shade" aria-hidden="true"></div><div class="hero-copy hero-banner-copy"><p class="hero-editorial">YOUR DIGITAL MARKETPLACE</p><h1>${e(settings.heroTitle).replaceAll('\n','<br>')}</h1><p class="hero-description">${e(settings.heroText)}</p>${minimum!==null&&money?`<p class="wm-hero-price">Plans from <strong>${money(minimum)}</strong><span>/month</span></p>`:''}<div class="hero-actions"><a class="btn" href="/shop">Shop digital products ${icon('arrow')}</a><a class="btn outline" href="/plans">Compare plans ${icon('arrow')}</a></div></div>`:`<h1 class="sr-only">${e(settings.heroTitle||settings.name)}</h1>`}</section>`:''}${promos.length?`<aside class="hero-fixed-promos" aria-label="Featured collections">${promos.map(s=>`<a class="hero-promo" href="${e(s.href||'/shop')}"><img data-portrait-stock="${s.mobileImage?.startsWith('/assets/heroes/')===true}" src="${e(s.image)}" alt="${e(s.alt||'Featured collection')}" width="800" height="390" decoding="async" loading="lazy"></a>`).join('')}</aside>`:''}</div>`;}
export function bindSlideshow(state) {
 const root = document.querySelector('.hero-slideshow');
 if (!root || state.preview) return;
 const slides = [...root.querySelectorAll('[data-slide]')];
 if (slides.length < 2) return;

 const reduced = matchMedia('(prefers-reduced-motion: reduce)');
 const events = new AbortController();
 const { signal } = events;
 const animations = [];
 let index = 0;
 let timer;
 let warmTimer;
 let intersection;
 let visible = !('IntersectionObserver' in window);
 let hovered = false;
 let focused = false;
 let swipeStart = null;
 let preventClickUntil = 0;
 let revision = 0;

 function permitsAutoplay() {
  return visible && !document.hidden && !reduced.matches && !hovered && !focused;
 }

 function warmNextImage() {
  const image = slides[(index + 1) % slides.length].querySelector('img');
  if (image.loading === 'lazy') {
   image.fetchPriority = 'low';
   image.loading = 'eager';
  }
 }

 function schedule() {
  clearTimeout(timer);
  clearTimeout(warmTimer);
  if (!permitsAutoplay()) return;
  warmTimer = setTimeout(warmNextImage, 2200);
  timer = setTimeout(() => advance(1, true), 5000);
 }

 function settleSlides() {
  animations.splice(0).forEach(animation => animation.cancel());
  slides.forEach((slide, slideIndex) => {
   slide.hidden = slideIndex !== index;
   slide.inert = false;
   slide.removeAttribute('aria-hidden');
   slide.toggleAttribute('data-active', slideIndex === index);
  });
 }

 async function advance(direction, auto = false) {
  if (auto && !permitsAutoplay()) return;
  const token = ++revision;
  clearTimeout(timer);
  clearTimeout(warmTimer);
  let nextIndex;
  let next;
  for (let step = 1; step < slides.length; step++) {
   if (token !== revision || signal.aborted || (auto && !permitsAutoplay())) return;
   const candidate = (index + step * direction + slides.length) % slides.length;
   const image = slides[candidate].querySelector('img');
   image.loading = 'eager';
   try {
    await image.decode();
    next = slides[candidate];
    nextIndex = candidate;
    break;
   } catch {
    // An unavailable image should not stop the rest of the slideshow.
   }
  }
  if (token !== revision || signal.aborted || (auto && !permitsAutoplay())) return;
  if (!next) {
   schedule();
   return;
  }

  const previous = slides[index];
  const moveFocus = document.activeElement === previous;
  settleSlides();
  index = nextIndex;
  next.hidden = false;
  next.setAttribute('data-active', '');
  previous.removeAttribute('data-active');
  if (moveFocus) next.focus({ preventScroll: true });

  if (reduced.matches || typeof next.animate !== 'function') {
   settleSlides();
   schedule();
   return;
  }

  previous.inert = true;
  previous.setAttribute('aria-hidden', 'true');
  const timing = { duration: 340, easing: 'cubic-bezier(.22,.61,.36,1)', fill: 'both' };
  animations.push(
   previous.animate([{translate:'0 0'}, {translate:`${-direction * 100}% 0`}], timing),
   next.animate([{translate:`${direction * 100}% 0`}, {translate:'0 0'}], timing)
  );
  await Promise.allSettled(animations.map(animation => animation.finished));
  if (token === revision && !signal.aborted) {
   settleSlides();
   schedule();
  }
 }

 root.addEventListener('pointerenter', event => {
  if (event.pointerType === 'mouse') { hovered = true; schedule(); }
 }, { signal });
 root.addEventListener('pointerleave', () => { hovered = false; schedule(); }, { signal });
 root.addEventListener('focusin', () => { focused = true; schedule(); }, { signal });
 root.addEventListener('focusout', event => {
  focused = root.contains(event.relatedTarget);
  schedule();
 }, { signal });
 root.addEventListener('keydown', event => {
  if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
   event.preventDefault();
   advance(event.key === 'ArrowRight' ? 1 : -1);
  }
 }, { signal });
 root.addEventListener('pointerdown', event => {
  if (event.pointerType === 'touch') swipeStart = { x:event.clientX, y:event.clientY };
 }, { passive:true, signal });
 root.addEventListener('pointercancel', () => { swipeStart = null; }, { signal });
 root.addEventListener('pointerup', event => {
  if (!swipeStart) return;
  const dx = event.clientX - swipeStart.x;
  const dy = event.clientY - swipeStart.y;
  swipeStart = null;
  if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) {
   preventClickUntil = performance.now() + 350;
   advance(dx < 0 ? 1 : -1);
  }
 }, { passive:true, signal });
 root.addEventListener('click', event => {
  if (event.detail && performance.now() < preventClickUntil) event.preventDefault();
 }, { capture:true, signal });
 document.addEventListener('visibilitychange', schedule, { signal });
 reduced.addEventListener('change', () => {
  if (reduced.matches && animations.length) settleSlides();
  schedule();
 }, { signal });

 if (!visible) {
  intersection = new IntersectionObserver(entries => {
   visible = entries[0].isIntersecting;
   schedule();
  });
  intersection.observe(root);
 } else schedule();

 state.cleanup.push(() => {
  clearTimeout(timer);
  clearTimeout(warmTimer);
  intersection?.disconnect();
  events.abort();
  settleSlides();
 });
}
