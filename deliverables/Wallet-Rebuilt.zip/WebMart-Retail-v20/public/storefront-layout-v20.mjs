export const stylesheet = "/storefront.e70f16845b8d.css";
export const layout = "wm-1737ea8661f8";
