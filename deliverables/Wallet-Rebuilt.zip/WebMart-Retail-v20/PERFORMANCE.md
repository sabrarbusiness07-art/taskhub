# WebMart Retail v20 loading measurements

Each value is the median of three tests per release and device in the same Chromium process. A warm result is a reload in the same context. Mobile uses a 390px viewport, 4× CPU slowdown, 1.6 Mbps and 150ms configured latency.

| Session | v19 LCP | v20 LCP | v19 DOM ready | v20 DOM ready |
| --- | ---: | ---: | ---: | ---: |
| Desktop cold | 576 ms | 528 ms | 267 ms | 216 ms |
| Desktop warm | 168 ms | 136 ms | 77 ms | 66 ms |
| Mobile cold | 1896 ms | 1624 ms | 1321 ms | 1136 ms |
| Mobile warm | 1140 ms | 920 ms | 773 ms | 584 ms |

The boot loader and asset manifest start loading alongside the entry script. The slideshow decodes the next image before moving and stops scheduling work outside the viewport, in hidden tabs and under reduced motion. Wide navigation uses a single category disclosure. The app retains one compressed storefront CSS request and defers the merchant workspace assets. These are local measurements with bundled images. Hosting and uploaded image sizes affect live load times.
