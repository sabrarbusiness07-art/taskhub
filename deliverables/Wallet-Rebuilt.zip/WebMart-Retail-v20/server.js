'use strict';
const { createApp } = require('./application');
const { version } = require('./package.json');
const { app, store } = createApp();
const host = process.env.HOST || '127.0.0.1';
const port = Number(process.env.PORT || 5000);
const server = app.listen(port, host, error => {
  if (error) {
    if (error.code === 'EADDRINUSE') {
      console.error('Port ' + port + ' is already in use. Stop the previous WebMart server before starting v' + version + '.');
    } else {
      console.error('WebMart could not start: ' + error.message);
    }
    store.close();
    process.exitCode = 1;
    return;
  }
  const url = process.env.PUBLIC_URL || 'http://localhost:' + server.address().port;
  console.log('WebMart v' + version + ' is running at ' + url);
});
for (const signal of ['SIGTERM', 'SIGINT']) {
  process.on(signal, () => server.close(() => {
    store.close();
    process.exit(0);
  }));
}
