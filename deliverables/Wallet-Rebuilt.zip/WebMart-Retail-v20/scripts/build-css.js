'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const root = path.join(__dirname, '..', 'public');
const sources = [
  'fonts.css', 'styles.css', 'page-content.css', 'rental.css', 'rentals-v11.css', 'premium.css',
  'banner-v12.css', 'commerce.css', 'liquid-v14.css', 'obsidian-v15.css', 'onyx-v16.css', 'graphite-v17.css', 'retail-v19.css', 'finishing-v20.css'
];
const layoutModule = 'storefront-layout-v20.mjs';

function hash(content) {
  return crypto.createHash('sha256').update(content).digest('hex').slice(0, 12);
}

function bundle() {
  const css = sources.map(name => '/* ' + name + ' */\n' + fs.readFileSync(path.join(root, name), 'utf8')).join('\n');
  return css + '\n:root{--wm-layout:wm-' + hash(css) + '}\n';
}

function nameFor(content) {
  return 'storefront.' + hash(content) + '.css';
}

function manifestFor(css) {
  const layout = css.match(/--wm-layout:(wm-[a-f0-9]{12})\}\n$/)[1];
  return 'export const stylesheet = ' + JSON.stringify('/' + nameFor(css)) + ';\n' +
    'export const layout = ' + JSON.stringify(layout) + ';\n';
}

function build() {
  const css = bundle();
  const name = nameFor(css);
  fs.writeFileSync(path.join(root, name), css);
  fs.writeFileSync(path.join(root, layoutModule), manifestFor(css));

  const file = path.join(root, 'index.html');
  const html = fs.readFileSync(file, 'utf8')
    .replace(/<link rel="stylesheet" href="\/([^"?]+)(?:\?[^"\s]*)?">/g, (tag, fileName) =>
      sources.includes(fileName) || /^storefront\.[a-f0-9]{12}\.css$/.test(fileName) ? '' : tag)
    .replace('</title>', '</title><link rel="stylesheet" href="/' + name + '">')
    .replace(/"\/app\.mjs(?:\?[^"]*)?"/g, '"/app.mjs?release=20"');
  fs.writeFileSync(file, html);
  for (const previous of fs.readdirSync(root)) {
    if (previous.startsWith(name)) continue;
    if (/^storefront\.[a-f0-9]{12}\.css(?:\.br|\.gz)?$/.test(previous)) {
      fs.unlinkSync(path.join(root, previous));
    }
  }
  console.log('Built', name, 'from', sources.length, 'stylesheets.');
}

module.exports = { bundle, nameFor, manifestFor, layoutModule };
if (require.main === module) build();
