'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('node:net');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');

test('launcher identifies a port conflict instead of reporting that the new version is running', async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-port-busy-'));
  const occupied = createServer();
  try {
    await new Promise((resolve, reject) => occupied.once('error', reject).listen(0, '127.0.0.1', resolve));
    const port = occupied.address().port;
    const root = path.join(__dirname, '..');
    await assert.rejects(promisify(execFile)(process.execPath, ['server.js'], {
      cwd: root,
      env: { ...process.env, NODE_ENV:'test', HOST:'127.0.0.1', PORT:String(port), PUBLIC_URL:'http://127.0.0.1:' + port,
        DATA_DIR:directory, UPLOAD_DIR:path.join(directory, 'uploads') },
      timeout: 5000
    }), error => {
      assert.equal(error.code, 1);
      assert.match(error.stderr, /already in use/);
      assert.doesNotMatch(error.stdout, /is running at/);
      return true;
    });
  } finally {
    if (occupied.listening) await new Promise(resolve => occupied.close(resolve));
    fs.rmSync(directory, { recursive:true, force:true });
  }
});
