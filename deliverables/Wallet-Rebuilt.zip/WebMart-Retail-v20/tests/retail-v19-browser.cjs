'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { chromium } = require('playwright');
const { createApp } = require('../application');

const output = process.env.BROWSER_ARTIFACTS || path.join(os.tmpdir(), 'webmart-retail-browser');
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-retail-'));

async function loadImages(page) {
  const images = page.locator('.hero-slide:not([hidden]) img, .hero-promo img, .commerce-card img');
  await images.evaluateAll(nodes => Promise.all(nodes.map(image => {
    image.loading = 'eager';
    return image.decode();
  })));
}

async function styles(locator) {
  return locator.evaluate(el => {
    const style = getComputedStyle(el);
    return { radius: style.borderRadius, fill: style.backgroundColor, image: style.backgroundImage,
      blur: style.backdropFilter, shadow: style.boxShadow, left: el.getBoundingClientRect().left };
  });
}

(async () => {
  let browser, store, server;
  fs.mkdirSync(output, { recursive:true });
  try {
    const built = createApp({ dataDir, uploadDir: path.join(dataDir, 'uploads') });
    store = built.store;
    server = built.app.listen(0, '127.0.0.1');
    await new Promise(resolve => server.once('listening', resolve));
    const base = 'http://127.0.0.1:' + server.address().port;
    const executablePath = process.env.BROWSER_EXECUTABLE || (fs.existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined);
    browser = await chromium.launch({ executablePath, args:['--no-sandbox'] });
    const desktop = await browser.newPage({ viewport:{width:1440,height:1050} });
    const errors = [];
    desktop.on('pageerror', error => errors.push(error.message));
    await desktop.goto(base);
    await desktop.locator('.hero-stage').waitFor();
    await loadImages(desktop);
    const sidebar = desktop.locator('.commerce-header');
    const expanded = await styles(sidebar);
    assert.deepEqual(expanded,{radius:'0px',fill:'rgb(28, 32, 38)',image:'none',blur:'none',shadow:'none',left:0});
    assert.equal(await desktop.locator('.commerce-utility').isVisible(),false);
    assert.equal(await desktop.locator('#drawer-toggle').isVisible(),false);
    await desktop.screenshot({ path:path.join(output,'webmart-retail-desktop.png') });

    await desktop.locator('#rail-toggle').click();
    assert.equal(await desktop.locator('#rail-toggle').getAttribute('aria-expanded'),'false');
    assert.deepEqual(await styles(sidebar),expanded);
    assert.equal(await desktop.locator('#rail-search').isVisible(),true);
    await desktop.screenshot({ path:path.join(output,'webmart-retail-compact.png') });
    console.log('PASS opaque, square sidebar is the only desktop navigation in expanded and compact mode');

    const actions = ['.card-details','.plan-heading>.btn','.home-category-tabs>a.active'];
    for (const selector of actions) {
      const action = await styles(desktop.locator(selector).first());
      assert.equal(action.image,'none');assert.equal(action.blur,'none');assert.equal(action.shadow,'none');
    }
    assert.equal((await styles(desktop.locator('.plan-heading>.btn').first())).fill,'rgb(31, 41, 55)');
    assert.equal((await styles(desktop.locator('.home-pricing [data-cycle=monthly]'))).fill,'rgb(31, 41, 55)');
    assert.equal((await styles(desktop.locator('.home-pricing [data-cycle=yearly]'))).fill,'rgb(255, 255, 255)');
    assert.equal(await desktop.locator('.liquid-surface,.liquid-control,.liquid-button').count(),0);
    const assets = await desktop.evaluate(() => performance.getEntriesByType('resource').map(e => new URL(e.name).pathname));
    assert.ok(!assets.some(asset => /liquid\.mjs|motion\.mjs|liquid-glass-rail/.test(asset)));
    assert.equal(assets.filter(asset => asset.endsWith('.css')).length,1);
    const compact = await (await desktop.request.get(base + '/api/store?compact=1')).json();
    const full = await (await desktop.request.get(base + '/api/store')).json();
    assert.deepEqual(compact.products, full.services);
    assert.equal('services' in compact, false);
    await desktop.locator('.home-pricing').screenshot({ path:path.join(output,'webmart-retail-plans.png') });
    console.log('PASS solid retail actions, purchase accent and a single CSS request without liquid runtime');

    const mobile = await browser.newPage({ viewport:{width:390,height:844},isMobile:true,hasTouch:true });
    mobile.on('pageerror', error => errors.push(error.message));
    await mobile.goto(base);
    await mobile.locator('.hero-stage').waitFor();
    await loadImages(mobile);
    assert.equal((await styles(mobile.locator('.mobile-bottom-nav'))).blur,'none');
    assert.equal(await mobile.locator('#rail-toggle').isVisible(),false);
    await mobile.locator('#drawer-toggle').click();
    await mobile.locator('#navigation-drawer[open]').waitFor();
    await mobile.locator('#drawer-close').click();
    assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth > innerWidth),false);
    await mobile.screenshot({ path:path.join(output,'webmart-retail-mobile.png') });
    await mobile.goto(base + '/product?id=template-atlas');
    await mobile.locator('#product-buybox').waitFor();
    assert.equal(await mobile.locator('.product-demo').count(),1);
    assert.equal((await styles(mobile.locator('#product-add-cart'))).fill,'rgb(31, 41, 55)');
    assert.deepEqual(errors,[]);
    console.log('PASS flat mobile bar, drawer, product preview and checkout action render without browser errors');
  } finally {
    await browser?.close();
    if (server) await new Promise(resolve => server.close(resolve));
    store?.close();
    fs.rmSync(dataDir, { recursive:true, force:true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
