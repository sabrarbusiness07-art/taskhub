'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { chromium } = require('playwright');
const { createApp } = require('../application');

const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-retail-v20-'));
const output = process.env.BROWSER_ARTIFACTS || path.join(os.tmpdir(), 'wm-retail-v20-artifacts');

(async () => {
 let browser, server, store;
 try {
  fs.mkdirSync(output, { recursive:true });
  const built = createApp({ dataDir:directory, uploadDir:path.join(directory,'uploads') });
  store = built.store;
  server = built.app.listen(0,'127.0.0.1');
  await new Promise(resolve => server.once('listening',resolve));
  const base = 'http://127.0.0.1:' + server.address().port;
  const executablePath = process.env.BROWSER_EXECUTABLE || (fs.existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined);
  browser = await chromium.launch({ executablePath,args:['--no-sandbox'] });
  const page = await browser.newPage({ viewport:{width:1366,height:900} });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(base);

  const carousel = page.locator('.hero-slideshow');
  await carousel.waitFor();
  assert.equal(await carousel.locator('.banner-arrow,[data-slide-prev],[data-slide-next]').count(),0);
  const initial = await carousel.locator('[data-active]').getAttribute('data-slide');
  await page.waitForFunction(() => document.querySelector('.hero-slideshow').getAnimations({subtree:true})
   .some(animation => animation.effect?.getTiming().duration === 340), null, {timeout:8500});
  assert.notEqual(await carousel.locator('[data-active]').getAttribute('data-slide'),initial);
  assert.equal(await carousel.locator('[data-slide][aria-hidden=true]').count(),1);
  await page.waitForFunction(() => document.querySelectorAll('.hero-slide:not([hidden])').length===1);
  await carousel.focus();
  await page.keyboard.press('ArrowLeft');
  await page.waitForFunction(initial => document.querySelector('.hero-slide[data-active]').dataset.slide===initial,initial);
  console.log('PASS arrowless autoplay moves both slides and retains keyboard navigation');

  await page.locator('#rail-toggle').click();
  await page.locator('#mega-toggle').click();
  const categories = page.locator('.rail-scroll #mega-menu');
  await categories.waitFor();
  const rail = await page.locator('.commerce-header').boundingBox();
  const contents = await categories.boundingBox();
  assert.ok(contents.x >= rail.x && contents.x + contents.width <= rail.x + rail.width);
  assert.ok(await categories.locator('a[href*="category="]').count()>0);
  await page.keyboard.press('Tab');
  assert.equal(await page.locator('#mega-menu a:focus').count(),1);
  await page.keyboard.press('Escape');
  assert.equal(await page.locator('#mega-toggle').evaluate(el=>document.activeElement===el),true);
  assert.equal(await categories.isVisible(),false);
  await page.locator('#rail-toggle').click();
  await page.locator('#rail-search').click();
  const search = page.locator('#store-search');
  assert.equal(await search.evaluate(el=>document.activeElement===el),true);
  const input = await search.boundingBox();
  const submit = await page.locator('#header-search button').boundingBox();
  const form = await page.locator('#header-search').boundingBox();
  assert.ok(input.x+input.width<=submit.x+1);
  assert.ok(input.height===submit.height);
  for (const control of [input,submit]) {
   assert.ok(control.y >= form.y && control.y + control.height <= form.y + form.height);
  }
  assert.equal(await search.evaluate(el=>getComputedStyle(el).outlineOffset),'-2px');
  await search.fill(' Atlas ');
  await search.press('Enter');
  await page.locator('.catalog-head').waitFor();
  assert.equal(new URL(page.url()).searchParams.get('q'),'Atlas');
  assert.equal(await page.locator('.commerce-card').count(),1);
  console.log('PASS inline category layout, focus return and sidebar search geometry and results');

  await page.goto(base+'/plans');
  const action = page.locator('.plan-heading .btn').first();
  await action.waitFor();
  assert.equal(await action.evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(31, 41, 55)');
  await action.hover();
  assert.equal(await action.evaluate(el=>getComputedStyle(el).animationName),'none');
  const secondary = page.locator('[data-cycle=yearly]');
  await secondary.hover();
  assert.equal(await secondary.evaluate(el=>getComputedStyle(el).animationName),'secondary-button-bounce');
  await secondary.click();
  assert.equal(await page.locator('[data-cycle=yearly]').getAttribute('aria-pressed'),'true');
  const reduced = await browser.newPage({ reducedMotion:'reduce', viewport:{width:1366,height:900} });
  await reduced.goto(base);
  await reduced.locator('.hero-stage').waitFor();
  const before = await reduced.locator('.hero-slide[data-active]').getAttribute('data-slide');
  await reduced.clock.install();
  await reduced.clock.fastForward(7000);
  assert.equal(await reduced.locator('.hero-slide[data-active]').getAttribute('data-slide'),before);
  const reducedAction = reduced.locator('.section-head>.text-link').first();
  await reducedAction.hover();
  assert.equal(await reducedAction.evaluate(el=>getComputedStyle(el).animationName),'none');
  await reduced.close();
  console.log('PASS dark primary actions, secondary-only bounce and reduced-motion handling');

  const external = 'https://example.test/webmart-demo';
  const product = store.get('products','template-atlas');
  product.template.demoUrl = external;
  product.commerce.showPreview = false;
  store.put('products',product.id,product);
  await page.context().route(external, route=>route.fulfill({contentType:'text/html',body:'<h1>Demo destination</h1>'}));
  await page.goto(base+'/product?id=template-atlas');
  const preview = page.getByRole('link',{name:'Live Preview'});
  await preview.waitFor();
  assert.equal(await preview.getAttribute('href'),external);
  assert.equal(await page.locator('iframe').count(),0);
  assert.equal(await page.locator('#product-add-cart').evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(31, 41, 55)');
  const popupPromise = page.waitForEvent('popup');
  await preview.click();
  const popup = await popupPromise;
  await popup.getByRole('heading',{name:'Demo destination'}).waitFor();
  assert.equal(popup.url(),external);
  await popup.close();
  await page.screenshot({path:path.join(output,'retail-v20-product.png')});
  assert.deepEqual(errors,[]);
  console.log('PASS Live Preview opens the configured website even with embedding turned off');
 } finally {
  await browser?.close();
  if (server) await new Promise(resolve => server.close(resolve));
  store?.close();
  fs.rmSync(directory,{recursive:true,force:true});
 }
})().catch(error=>{console.error(error);process.exitCode=1;});
