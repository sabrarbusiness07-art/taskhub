# WebMart Retail v20 verification

Node 24.22.1 and Chromium 156 were used with temporary databases.

- 75 Node tests passed, covering commerce, theme publication, accounts and port handling.
- 65 browser checks passed across the existing storefront, merchant, editor and layout recovery suites and four v20 scenarios.
- Asset checks passed for media, source syntax, stylesheet fingerprint and compressed output.

The v20 checks verify the animated arrowless carousel, keyboard navigation, reduced motion, expanded and compact sidebar, inline categories, focus return, contained search controls and a trimmed search query. Browser checks also verify dark purchase actions, hover bounce on secondary actions, checkout regression coverage and a configured Live Preview opening in a new tab with the embed disabled.

The release refreshes generated assets and excludes the previous glass override, databases, credentials and private uploads.

The ZIP installed all 73 production dependencies in a fresh extraction. Merchant setup and login, release health, the compressed stylesheet, real hero images, square sidebar and desktop/mobile rendering passed. The extracted copy also passed all 75 Node tests.
