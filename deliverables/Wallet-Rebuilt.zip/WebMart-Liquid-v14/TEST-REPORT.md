# WebMart Liquid v14 verification

Environment: Node 24.22.1, npm 11.9, Chromium 156, Linux. Tests use isolated temporary databases and generated credentials. No real customer store or login is included in the release.

- `npm run build:assets`: 31 CSS/MJS assets precompressed.
- `npm run check`: JavaScript syntax, seed media and matching compressed sources passed.
- `npm test`: 68 API/migration/security tests passed.
- `npm run test:browser`: 18 commerce regression journeys plus 15 Liquid v14 journeys passed, 33 browser checks total.

Total: **101 API/browser checks passed**, plus syntax/assets verification.

A clean extraction installed 73 production packages with `npm ci --omit=dev`. All 68 API tests passed in that installation too. Fresh merchant setup/login, health/release, main routes, Brotli delivery, desktop/mobile rendering and the complete database/private-file/media backup passed smoke checks.

New coverage: v13-to-v14 migration preserves merchant login, customised products, imagery, colours, menus and paid history; single/split hero settings validate and publish; fixed pictures/slides can be deleted; a one-image carousel has exactly one dot; actual touch/mobile viewport autoplays without visible arrows, pause or hero-action controls; mobile header and fixed bottom navigation work; wishlist counters/selected states persist; desktop menus are readable and have vertical links; menu/submenu category/product targets and icons can be customised; custom icon artwork uploads, publishes and resets; menu/quick-link deletion after publication persists in the same editor session; embedded preview visibility/autoload can be toggled; plan deletion archives history and removes public choices; product deletion and draft restoration work; unused private files can be deleted while promised customer files remain protected; account sidebar tracks Rentals/Requests/Purchases; product layouts fit 360, 390, 768, 1024 and 1440px; reduced-motion works. No uncaught browser errors occurred.

Retained coverage: checkout pricing, CSRF/Origin/customer ownership, idempotent mixed checkout and merchant confirmation, private downloads, subscription expiry/suspension, manual payment-reference reuse prevention, monthly/yearly calendar arithmetic in Bangladesh time, renewals/cancellations, theme draft/publish/rollback, section insertion/drag/keyboard order, date/video blocks, font validation and analytics.

Visual screenshots reviewed include mobile logo/menu/bottom bar, desktop split hero, desktop mega menu, product glass controls and active customer account navigation. Full production-domain deployment, a real payment gateway, physical-device performance and third-party iframe permissions were not tested. External sites can reject embedding; the merchant can hide the preview block. Payment verification and website provisioning remain merchant-managed.
