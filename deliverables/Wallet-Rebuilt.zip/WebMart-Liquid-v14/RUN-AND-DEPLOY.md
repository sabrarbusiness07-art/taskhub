# Run and deploy WebMart Liquid v14

## Local setup

Install Node.js 24.x (24.14+). Extract to a fresh folder. Run `npm ci --omit=dev`, `npm run setup`, then `npm start`. On Windows PowerShell use `npm.cmd` in place of `npm`, or use the included CMD launchers.

Open http://localhost:5000 and /admin. Setup creates your own merchant email/password. There are no default credentials. Example listings/demos illustrate the store layout; edit them into your actual products, prices, terms and services before accepting real orders.

## Existing installations

Stop the server and keep a complete private backup. Extract v14 separately. Copy your old data directory, uploaded images and media into the matching new paths. Do not overwrite new code with old files or copy node_modules. Run `npm ci --omit=dev` and start. Existing customers/orders/subscriptions remain; first start applies the new mobile/icon/hero settings once, preserves your existing custom presentation and saves previous database/settings/theme snapshots. README.md explains recovery and backup locations.

## Production

Run one persistent Node server behind an HTTPS reverse proxy. Configure environment variables in your host’s private configuration; do not commit them:

| Variable | Purpose |
|---|---|
| NODE_ENV | production |
| PUBLIC_URL | Your exact public HTTPS origin |
| DATA_DIR | Private persistent directory for wallet.sqlite and digital-files |
| UPLOAD_DIR | Persistent uploaded-image directory; video media is stored in its sibling media directory |
| PORT | Default 5000 |
| HOST | Default 127.0.0.1; select an appropriate bind address for your proxy/container |
| TRUST_PROXY | Use 1 only behind your trusted reverse proxy |

Persist DATA_DIR, UPLOAD_DIR and its sibling media directory across releases. Keep the private database and digital-files outside the web root. `npm run backup` copies the database, private digital files, image uploads and videos to a private timestamped backup directory. Stop the server before restoring these to their matching locations.

The app uses SQLite on persistent local storage. It is not a stateless edge deployment. Payment verification, renewals, hosting and website provisioning are managed by the merchant; this release does not configure a live payment gateway or automatically deploy customer websites.

## Verification

`npm run build:assets` regenerates gzip/Brotli files after CSS/MJS edits. `npm run check` checks JavaScript and matching compressed sources. `npm test` runs API/migration/security tests. For browser tests install dev dependencies, run `npx playwright install chromium`, then `npm run test:browser`. BROWSER_EXECUTABLE can select an existing Chromium. BROWSER_ARTIFACTS selects the screenshot/result directory.
