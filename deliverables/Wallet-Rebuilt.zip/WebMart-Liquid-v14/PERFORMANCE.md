# Performance — WebMart Liquid v14

Single synthetic runs in this shared workspace with Node 24.22.1 and Chromium 156, fresh browser contexts, localhost. These are measured observations, not a production/internet speed guarantee or a Lighthouse score. The mobile run used a 390px touch viewport with CDP configured for 4× CPU slowdown, 1.6 Mbps download and 150 ms latency; localhost and shared-host scheduling affect the results.

| Measurement | Desktop localhost | Mobile synthetic settings |
|---|---:|---:|
| HTML TTFB | 50 ms | 10 ms |
| DOMContentLoaded | 179 ms | 1378 ms |
| Observed largest contentful paint | 604 ms | 2000 ms |
| Observed resource transfer | 560,964 bytes | 548,768 bytes |
| Resource count | 30 | 30 |
| External home resources | 0 | 0 |
| Merchant/editor modules on home | 0 | 0 |

The observation window ended 600 ms after the first hero image decoded. Later lazy images/slides may arrive afterward. Merchant-uploaded pictures and live external websites can change these measurements.

Glass controls use native CSS with small opacity/transform effects and a single delegated pointer listener. Button/card/menu motion is generally 120–180 ms. There is no timer delaying route navigation. The implementation avoids animated SVG displacement filters, full-page snapshots, continuously animated decorative canvases and public whole-DOM observers. Reduced-motion disables transitions and slideshow autoplay.

The header and bottom navigation use bounded backdrop blur; dropdown text sits on an opaque light surface for legibility. Split-hero dimensions are bounded independently of the source image sizes. On mobile, only the logo/menu and the bottom bar render; the carousel has no oversized copy/control overlay. The carousel stops its timer for hidden tabs, editor preview and reduced-motion users.

CSS/MJS ship with matching Brotli/gzip files. Fonts are local. Hero images are prioritised; product images and secondary media are lazy. External previews load when they enter view or when requested, and can be hidden entirely from the product editor. Analytics presence uses a 25-second visible-tab heartbeat.
