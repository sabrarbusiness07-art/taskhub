# WebMart Liquid v14 — ব্যবহার ও আপডেট

## আগে থেকে website চালু থাকলে

Server বন্ধ করে আগের পুরো folder backup রাখুন। নতুন ZIP আলাদা folder-এ extract করুন। আগের `data`, `public/uploads` এবং থাকলে `public/media` নতুন project-এর একই জায়গায় copy করুন। এগুলোতে আপনার account, product, ছবি, order ও plan থাকে। পুরোনো source/node_modules copy করবেন না।

নতুন folder-এর VS Code terminal-এ:

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

http://localhost:5000 এবং http://localhost:5000/admin খুলুন। আগের merchant login-ই ব্যবহার করুন।

প্রথমবার install হলে Node.js 24.x (কমপক্ষে 24.14) ব্যবহার করুন এবং server চালানোর আগে `npm.cmd run setup` দিয়ে নিজের email/password তৈরি করুন। কোনো default ID/password নেই। `START-WEBMART.cmd` চালালেও dependencies পরীক্ষা করে install করে।

## Mobile header ও নিচের navigation

উপরে logo ও menu button আছে। Menu খুললে search ও সব menu দেখা যাবে। নিচে Home, Shop, Saved, Cart, Account আছে। বর্তমান page-টি আলাদা আলো/রঙে দেখা যায়। Theme editor → Style → Mobile bottom navigation থেকে নিজের নাম, link ও icon দিন; নতুন link যোগ বা delete করতে পারবেন।

## Slideshow ও পাশে স্থির ছবি

Admin → Store settings → Hero image slideshow। Hero layout-এ Single slideshow অথবা Slideshow on left + fixed images on right বেছে নিন। প্রতিটি slide-এর ছবি/mobile ছবি, description ও link বদলাতে পারবেন; reorder/delete-ও আছে। Fixed promotional images-এ ডান পাশের এক/দুইটি ছবি ও link দিন। Banner display = Image only দিলে ছবিতে লেখা থাকলে দ্বিগুণ text দেখাবে না। Mobile-এ fixed ছবি দেখাবেন কি না আলাদাভাবে নির্বাচন করা যায়।

Mobile slideshow নিজে চলে; image-পিছু একটি ছোট dot থাকে। Arrow/pause/hero button mobile-এ দেখানো হয় না। Accessibility-এর reduced-motion চালু থাকলে autoplay বন্ধ থাকে।

## Wishlist, plans ও product preview

Save for later চাপলে header/bottom navigation-এর Saved count বদলায় এবং button selected হয়। একই product আবার চাপলে unsave হয়। Plan, billing cycle ও মূল action button-এ একই glass material ও দ্রুত liquid response আছে।

Products & services → Edit product → Preview & included pages-এ Show embedded live preview এবং Load preview when it comes into view আছে। বাইরের site iframe বন্ধ রাখলে embed দেখানো সম্ভব নয়; Show embedded live preview বন্ধ করে section লুকাতে পারবেন। Local demo আসল scrollable page। অন্য site-এর restrictions bypass করা হয় না।

Plan-এর Delete plan দিয়ে নতুন order থেকে plan সরাবেন; পুরোনো customer-এর কেনা history থাকে। Delete product দিয়ে product সরালে Deleted products থেকে draft হিসেবে restore করা যায়। Main/gallery ছবি, video, FAQ/specification text, slide, menu, custom section ও custom page-ও remove করা যায়। Digital file detach করে save করার পর unused file delete করা যায়; customer-এর কেনা file মুছে delivery নষ্ট করা হয় না।

## নিজের menu, category ও icons

Theme editor → Style → Navigation links। Header menu ও submenu-এর নাম/link/icon দিন। Choose page, category or product এবং Choose submenu target থেকে আপনার product/category বেছে নিতে পারবেন। Add, Move ও Remove controls আছে। শেষ menu-ও delete করলে পুরোনো default menu আবার ফিরে আসে না। Product form-এর Category বদলালে category picker-এ সেই নাম পাওয়া যায়।

Style → Icons & custom artwork খুলে icon নির্বাচন করুন অথবা PNG/JPEG/WebP upload করুন। Reset icon দিয়ে আগের icon ফেরত পাবেন। Save draft → Publish করুন। Publish করার পর একই session থেকে আবার edit/delete করে publish করা যায়।

## Customer account

My rentals, My digital purchases বা Request history-এ গেলে সংশ্লিষ্ট item selected হবে; Overview স্থিরভাবে selected থাকবে না। Checkout/payment confirmation/plan expiry/download/analytics আগের মতো কাজ করে। Payment verification এবং website/hosting setup আপনার team পরিচালনা করবে।

পরীক্ষার ফল TEST-REPORT.md-তে এবং upgrade/hosting-এর বিস্তারিত README.md ও RUN-AND-DEPLOY.md-তে আছে।
