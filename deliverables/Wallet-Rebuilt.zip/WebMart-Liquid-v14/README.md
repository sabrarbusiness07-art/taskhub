# WebMart Liquid v14

A complete Node.js ecommerce storefront for digital products, websites and monthly/yearly digital services. Purple–magenta branding follows the supplied W logo. The marketplace structure draws on Techland and Ghorerbazar; the page builder interaction draws on the supplied Tech Bazar source. These are design references, not copied merchant content or a Figma project file.

## Run locally

Use Node.js **24.14 or later in the 24.x line**. Extract this ZIP to a new folder; never copy old node_modules.

```sh
npm ci
npm run setup
npm start
```

Website: http://localhost:5000 · Merchant: http://localhost:5000/admin · Theme Studio: http://localhost:5000/admin/editor.

On Windows PowerShell use `npm.cmd ci`, `npm.cmd run setup`, `npm.cmd start`. You can also double-click `START-WEBMART.cmd` and `SETUP-MERCHANT.cmd`. This avoids the PowerShell npm.ps1 execution-policy issue. There is **no default email or password**: choose your own during setup. Existing installations keep their merchant login; do not run setup again unless adding/resetting a merchant.

## What changed in v14

- Mobile header contains only the logo and menu button. Search lives in the drawer; Home/Shop/Saved/Cart/Account links live in a fixed glass bottom bar. The active page lights up.
- Mobile slideshow advances automatically every five seconds, with exactly one small dot per image and no visible arrow/pause/hero-action controls. Desktop retains keyboard, arrow, dot and pause controls. Reduced-motion disables autoplay and transitions.
- Store settings offers Single slideshow or a left slideshow with up to two fixed promotional images on the right. Slides, promotional pictures, mobile pictures and their links can be added, reordered or removed. Mobile promotional-image visibility is separate.
- Shared liquid-glass styling applies to actions, pricing/term toggles, plan selectors and navigation controls. Motion completes in about 120–180 ms; there is no navigation delay.
- Saving/unsaving a product updates selected text, heart state and the header/mobile wishlist count, with a short visual pulse. Saved items survive reload.
- Product editor has Show embedded live preview and Load preview when it comes into view controls. If loading is manual, the product image fills the preview poster instead of an empty block. Third-party sites must allow iframe embedding; the app cannot override their restrictions.
- Theme Studio → Style edits header menus/submenus, mobile quick links, labels, destinations and icons. Destination pickers include actual product categories and products. Icons & custom artwork supports vetted SVG icons or uploaded PNG/JPEG/WebP artwork. Reset removes an override. No arbitrary executable SVG is accepted.
- Added plans, products, navigation items, slides, galleries, custom sections and custom pages have removal controls. Removed plans are archived for existing customer history and disappear from new selections. Products go to Deleted products and can be restored as drafts. Unused digital files can be permanently deleted; files promised to existing customer orders are retained.
- Account sidebar tracks Rentals, Purchases and Requests, including direct fragment links and scrolling. Publishing a theme refreshes the editor bindings, so subsequent edits/deletions save correctly in the same session.

## Store and fulfilment

- Search, categories, sort, saved products, cart and checkout.
- Product types: website, software, digital download, digital service.
- Billing: one-time, monthly/yearly subscription, or both.
- The full product form controls name/category, main image, gallery, description, highlights, specifications, date, badge, license, requirements, support, delivery, FAQ, video, live preview and every plan/price.
- Public HTTPS demo links become live website previews. Local bundled demos load immediately; external previews load on request to keep pages fast. Embedded previews scroll and support desktop/mobile widths. Open live always opens the merchant’s link; external sites may block embedding.
- Digital files: merchant uploads ZIP/PDF up to 32 MB. Files remain outside the public directory. A confirmed purchase or active entitled subscription is required to download. Images up to 5 MB; MP4 videos up to 32 MB; YouTube/Vimeo or HTTPS MP4 URLs also supported.
- Cart prices are computed on the server. A changed price requires review. Checkout retries are idempotent.
- **Payments are manually arranged/verified.** Configure bKash/Nagad/Rocket accounts in Store settings, or use invoice/payment arrangement. This release does not connect a payment gateway, automatically charge renewals, provision hosting or deploy Laravel websites.
- Merchant → Orders & customer plans → open order → verify payment → confirm. Confirmation grants purchases and starts each plan for its purchased calendar term. Repeated confirmation cannot activate twice. A declined order grants nothing.
- Account shows plan, start/expiry, status, renewal/cancellation requests, order history and confirmed digital downloads. Suspension/expiry stops subscription downloads.

## Page builder

Open Theme Studio, select a page, then use the **+ Add section** controls between sections in the preview or sidebar. Drag section rows, use Move up/down, or Alt+Up/Down. Edit text/images by clicking the preview; edit section layout, colours, links and items in the inspector.

Available blocks: hero, text, image, product/category collections, feature cards, FAQ, gallery, call to action, announcement, video, date/event, countdown, divider and spacer. Event times use Bangladesh time. Save draft first or Publish directly; drafts remain private to merchants. Built-in purchase/account controls stay functional. Custom pages, SEO, import/export, undo/redo, rollback, font/style options, custom header menus/submenus and footer links remain available. Slideshow images/mobile images, destinations and hero text are in Store settings, linked from the hero inspector.

Product content/prices belong in Products & services, not as text overrides in Theme Studio. Live viewer counts, daily views, product popularity and CSV analytics remain in Analytics; merchant and editor traffic is excluded.

## Upgrade without losing data

1. Stop the old server. Back up the complete existing folder.
2. Extract v14 separately. Copy the old private `data/`, `public/uploads/`, and `public/media/` (if present) to the matching new paths. Keep custom DATA_DIR / UPLOAD_DIR settings if you use them. Never copy old source or dependencies over v14.
3. Run `npm ci --omit=dev`, then `npm start`.

Accounts, password hashes, orders, paid subscriptions, product IDs, custom names/images, existing navigation, custom colours, page order and SEO are retained. First v14 start creates a private `data/backups/before-liquid-v14-*.sqlite` backup and `*-before-v14` theme/settings snapshots, then adds the new mobile navigation, icon and hero-layout settings once. v14 does not reset your customised products or palette. Earlier releases still pass through their existing migrations. Later restarts retain your edits. Old website URLs and renewal flows remain supported. No customer data is included in this ZIP.

Use `npm run backup` to save a consistent SQLite database plus private files, uploaded images and videos. Keep backups private. Restore the database to DATA_DIR/wallet.sqlite and restore digital-files, uploads and media to their matching directories while the server is stopped.

## Verification and deployment

```sh
npm run build:assets
npm run check
npm test
npx playwright install chromium
npm run test:browser
```

Browser tests use bundled Playwright Chromium, system /usr/bin/chromium when present, or BROWSER_EXECUTABLE. Screenshots/results go to a temporary directory, configurable with BROWSER_ARTIFACTS. Rebuild precompressed assets after changing public CSS/MJS.

Production requires HTTPS PUBLIC_URL, NODE_ENV=production, persistent private DATA_DIR and persistent UPLOAD_DIR/media. Default HOST is 127.0.0.1. TRUST_PROXY=1 is appropriate only behind your trusted reverse proxy. See RUN-AND-DEPLOY.md. Health release: `webmart-liquid-14.0.0`.
