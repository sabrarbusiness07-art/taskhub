# WebMart Onyx v16 verification

Environment: Node 24.22.1, npm 11.9, Chromium 156, Linux. Temporary databases/generated merchant credentials were used and removed. No actual customer database, credential or uploads are bundled.

- `npm run build:assets`: one hashed storefront stylesheet from 11 source layers; 35 public CSS/MJS/SVG assets precompressed.
- `npm run check`: syntax, seed media, generated CSS hash/index reference and matching Brotli/gzip passed.
- `npm test`: **74/74** API/migration/security tests passed.
- Commerce browser regression: **18/18** passed.
- Liquid/editor/mobile regression: **15/15** passed.
- Obsidian storefront regression: **9/9** passed.
- New Onyx browser suite: **9/9** passed.

**125 API/browser checks passed, including 51 browser checks.** No uncaught browser exceptions were observed.

v16 coverage: graphite All products / All plans and product actions; wishlist counts and selected state; yearly-plan/cart behavior after rerender; no pause/resume/dot markup with genuine mobile autoplay; transparent bottom glass dock and active tab; readable charcoal dashboard/product editor with actual save; Theme Studio and actual add-page modal; responsive consumer/admin screens; reduced-motion; single immutable compressed CSS; and zero button geometry reads for 100 pointer moves.

New migration tests verify that only live/draft action accents/settings colour change, with snapshots/private SQLite backup, retained uploaded hero/product paths, navigation, SEO, paid orders/subscriptions, version increments and idempotence. HTTP checks verify published responsive first-hero preloads, immediate publication updates, no draft disclosure and no preloads for hidden/editor hero sections.

Retained regression coverage includes server pricing, authentication/Origin/CSRF, ownership, idempotent mixed checkout/manual confirmation, protected downloads, expiry/suspension, renewals/cancellation, monthly/yearly calendar terms, payment-reference reuse, product/plan removal and restore, custom menu/submenu/icon upload/reset, section insertion/drag/keyboard order, theme save/publish/rollback, media/date blocks, account selection and analytics.

Visual review includes public mobile glass dock and controls, desktop/mobile admin, Theme Studio/preview and product screens. Corrections include residual purple action links, modal controls missing liquid decoration, Studio canvas padding, and banner text cropping at intermediate preview widths. Combined CSS and pointer work were measured in a paired three-sample performance experiment; PERFORMANCE.md records the results and scope.

No real external payment gateway, live hosting/Laravel provisioning or third-party iframe permission was tested. Customer payment review and service activation remain manual.

Clean distribution verification: extracted the release ZIP into a fresh folder, ran `npm ci --omit=dev` (73 production packages installed), created a temporary merchant account through the setup script, and verified merchant login, v16 health, the hashed Brotli stylesheet, decoded banner assets, two fixed promos, no dots, dark actions and desktop/mobile rendering. All 74 API tests also passed in the extracted installation. Temporary account/database files were removed; they are absent from the release.
