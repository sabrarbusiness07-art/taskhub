'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.join(__dirname,'..','public');
const sources=['fonts.css','styles.css','page-content.css','rental.css','rentals-v11.css','premium.css','banner-v12.css','commerce.css','liquid-v14.css','obsidian-v15.css','onyx-v16.css'];
function bundle(){return sources.map(name=>'/* '+name+' */\n'+fs.readFileSync(path.join(root,name),'utf8')).join('\n');}
function nameFor(content){return 'storefront.'+crypto.createHash('sha256').update(content).digest('hex').slice(0,12)+'.css';}
function build(){const css=bundle(),name=nameFor(css);for(const name of fs.readdirSync(root))if(/^storefront\.[a-f0-9]{12}\.css(?:\.br|\.gz)?$/.test(name))fs.unlinkSync(path.join(root,name));fs.writeFileSync(path.join(root,name),css);const file=path.join(root,'index.html');let html=fs.readFileSync(file,'utf8');html=html.replace(/<link rel="stylesheet" href="\/(?:fonts|styles|page-content|rental|rentals-v11|premium|banner-v12|commerce|liquid-v14|obsidian-v15|onyx-v16)\.css">/g,'').replace(/<link rel="stylesheet" href="\/storefront\.[a-f0-9]{12}\.css">/g,'');html=html.replace('</title>','</title><link rel="stylesheet" href="/'+name+'">');fs.writeFileSync(file,html);console.log('Built',name,'from',sources.length,'stylesheets.');}
module.exports={bundle,nameFor};if(require.main===module)build();
