'use strict';
const {test,before,after}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {createApp}=require('../application'),{passwordHash}=require('../lib/store');
const origin='http://localhost:5000',password=crypto.randomBytes(24).toString('hex');
let store,server,dir,base,merchant;
async function request(url,method='GET',body,user=merchant){
 const response=await fetch(base+url,{method,headers:{Origin:origin,...(body?{'Content-Type':'application/json'}:{}),...(user?{Cookie:user.cookie,'X-CSRF-Token':user.csrf}:{})},body:body?JSON.stringify(body):undefined});
 return{status:response.status,headers:response.headers,data:await response.json()};
}
before(async()=>{
 dir=fs.mkdtempSync(path.join(os.tmpdir(),'wm-obsidian-api-'));
 const created=createApp({dataDir:dir,uploadDir:path.join(dir,'uploads'),origin});store=created.store;
 const credentials=await passwordHash(password);
 store.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run('merchant','merchant@example.test','Merchant','admin',credentials.salt,credentials.hash);
 server=created.app.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));base='http://127.0.0.1:'+server.address().port;
 const login=await request('/api/auth/login','POST',{email:'merchant@example.test',password},null);
 assert.equal(login.status,200);merchant={...login.data,cookie:login.headers.get('set-cookie').split(';')[0]};
});
after(async()=>{await new Promise(resolve=>server.close(resolve));store.close();fs.rmSync(dir,{recursive:true,force:true});});

test('v15 starts with an editable split hero, two actual promo images and digital-product billing',async()=>{
 assert.equal((await request('/api/health')).data.release,'webmart-onyx-16.0.0');
 const publicStore=(await request('/api/store','GET',null,null)).data;
 assert.equal(publicStore.settings.heroArrangement,'split');
 assert.equal(publicStore.siteTheme.global.bodyFont,'store');assert.equal(publicStore.siteTheme.global.displayFont,'store');
 assert.equal(publicStore.settings.heroLayout,'image');
 assert.equal(publicStore.settings.heroPromos.length,2);
 assert.ok(publicStore.settings.heroSlides.length>1);
 for(const item of [...publicStore.settings.heroSlides,...publicStore.settings.heroPromos]){
  assert.ok(item.image.startsWith('/'));
  assert.ok(fs.existsSync(path.join(__dirname,'../public',item.image)),'Bundled hero image must exist: '+item.image);
 }
 assert.ok(publicStore.products.length>0);
 assert.ok(publicStore.products.every(p=>p.kind==='service'&&p.commerce?.billing));
 assert.ok(publicStore.products.every(p=>!Object.hasOwn(p,'variants')));
 assert.ok(store.get('config','obsidian-v15'));
});

test('merchant edits both fixed promo pictures and slideshow links through draft/publication with conflict protection',async()=>{
 const original=(await request('/api/admin/theme')).data;
 const body={...original,heroArrangement:'split',heroLayout:'image',heroSlides:original.heroSlides.map((slide,i)=>({...slide,alt:'Digital website '+i,href:'/product?id=template-atlas'})),heroPromos:[{image:'/assets/templates/atlas.webp',alt:'Browse websites',href:'/shop?type=website'},{image:'/assets/templates/forma.webp',alt:'Compare service plans',href:'/plans'}]};
 const saved=await request('/api/admin/theme','PUT',body);
 assert.equal(saved.status,200,JSON.stringify(saved.data));
 assert.equal((await request('/api/admin/theme','PUT',body)).status,409);
 assert.equal((await request('/api/admin/theme/publish','POST',{version:saved.data.version})).status,200);
 const published=(await request('/api/store','GET',null,null)).data.settings;
 assert.deepEqual(published.heroPromos,body.heroPromos);
 assert.deepEqual(published.heroSlides,body.heroSlides);
});

test('hero editing still rejects unsafe media/link inputs and unsupported arrangements',async()=>{
 const current=(await request('/api/admin/theme')).data;
 for(const changed of [
  {heroArrangement:'unknown'},
  {heroPromos:[{image:'/assets/templates/atlas.webp',href:'javascript:alert(1)'}]},
  {heroPromos:[{image:'https://example.com/arbitrary.png',href:'/shop'}]},
  {heroPromos:Array(3).fill(current.heroPromos[0])}
 ])assert.equal((await request('/api/admin/theme','PUT',{...current,...changed})).status,400);
 assert.equal((await request('/api/admin/theme','PUT',current,null)).status,401);
});

test('v14-to-v15 presentation upgrade retains merchant products, links, accounts and paid history and runs once',()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'wm-v15-upgrade-'));let old;
 try{
  old=createApp({dataDir:temp,uploadDir:path.join(temp,'uploads'),origin}).store;
  old.db.prepare("DELETE FROM config WHERE id='obsidian-v15'").run();old.put('config','initialized',{version:14});
  const customizedSlides=[{image:'/uploads/my-banner.webp',mobileImage:'/uploads/my-phone.webp',alt:'My real business',href:'/product?id=template-atlas'}];
  const customizedPromos=[{image:'/uploads/my-promo-one.webp',alt:'My collection',href:'/shop?category=Custom'},{image:'/uploads/my-promo-two.webp',alt:'My plans',href:'/plans'}];
  for(const key of ['settings','draft']){const settings=old.get('config',key);settings.name='Merchant Business';settings.heroSlides=customizedSlides;settings.heroPromos=customizedPromos;settings.heroArrangement='split';old.put('config',key,settings);}
  for(const key of ['site-live','site-draft']){const theme=old.get('config',key);theme.global.navigation=[{title:'My chosen collection',href:'/shop?category=Custom',icon:'tag',children:[]}];theme.pages.home.sections.reverse();theme.pages.home.seoTitle='Merchant SEO';old.put('config',key,theme);}
  const product=old.get('products','template-atlas');product.name='Merchant Laravel Website';product.image='/uploads/my-product.webp';old.put('products',product.id,product);
  const paid={id:'retained-plan',customerId:'existing-buyer',serviceId:product.id,planId:'basic',status:'active',expiresAt:'2030-01-31T00:00:00Z',periods:[{price:450000}]};
  const order={id:'retained-order',customerId:'existing-buyer',status:'active',total:450000};
  old.put('subscriptions',paid.id,paid);old.put('orders',order.id,order);
  old.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run('existing-merchant','existing@example.test','Existing','admin','retained-test-salt','retained-test-hash');old.close();old=null;
  const created=createApp({dataDir:temp,uploadDir:path.join(temp,'uploads'),origin});old=created.store;
  assert.equal(old.get('products',product.id).name,product.name);assert.equal(old.get('products',product.id).image,product.image);
  assert.deepEqual(old.get('subscriptions',paid.id),paid);assert.deepEqual(old.get('orders',order.id),order);
  assert.equal(old.db.prepare("SELECT hash FROM users WHERE id='existing-merchant'").get().hash,'retained-test-hash');
  assert.equal(old.get('config','site-live').global.navigation[0].title,'My chosen collection');
  assert.equal(old.get('config','site-live').pages.home.seoTitle,'Merchant SEO');
  assert.deepEqual(old.get('config','settings').heroSlides,customizedSlides);
  assert.deepEqual(old.get('config','settings').heroPromos,customizedPromos);
  const version=old.get('config','site-live').version;
  require('../lib/obsidian-v15').migrate(old);
  assert.equal(old.get('config','site-live').version,version);
 }finally{old?.close();fs.rmSync(temp,{recursive:true,force:true});}
});
