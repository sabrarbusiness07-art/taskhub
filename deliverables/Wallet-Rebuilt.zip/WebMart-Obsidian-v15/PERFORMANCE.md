# Performance — WebMart Obsidian v15

Single synthetic runs in this shared workspace, Node 24.22.1 and Chromium 156, fresh browser contexts on localhost. Mobile used a 390px touch viewport with CDP configured for 4× CPU slowdown, 1.6 Mbps download and 150ms latency. Localhost/shared scheduling affects measurements; these are not production guarantees or Lighthouse scores.

| Measurement | Desktop localhost | Mobile synthetic settings |
|---|---:|---:|
| HTML TTFB | 43 ms | 9 ms |
| DOMContentLoaded | 165 ms | 1235 ms |
| Observed LCP | 564 ms | 1856 ms |
| Observed resource transfer | 399,833 bytes | 161,205 bytes |
| Resource count | 30 | 26 |
| External home resources | 0 | 0 |
| Merchant/editor code on home | 0 | 0 |

The window ended 600ms after first hero image decoding; deferred assets may load later. The new main banner WEBPs are about 42–55KB, mobile variants 22–29KB and promo images 14–15KB. The Bengali font uses a Bengali-only Unicode range; Latin uses the system UI font. No remote runtime font/CDN dependency is required.

Controls use native CSS with small delegated pointer effects, generally 120–180ms, with no timer delaying navigation. Glass blur is bounded. No animated SVG displacement filters, whole-page snapshots or continuously animated decorative canvases run. Reduced-motion disables transitions and autoplay. Hidden tabs and editor previews stop the carousel timer. Public CSS/MJS ship with matching Brotli/gzip sources; admin modules are deferred. Product media is lazy; external preview loading can be configured or hidden.
