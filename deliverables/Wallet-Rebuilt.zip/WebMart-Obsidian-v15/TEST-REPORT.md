# WebMart Obsidian v15 verification

Environment: Node 24.22.1, npm 11.9, Chromium 156, Linux. Isolated temporary databases and generated credentials were used; no actual merchant login or customer database is bundled.

- `npm run build:assets`: 32 CSS/MJS assets precompressed.
- `npm run check`: JavaScript syntax, seed media and matching compressed assets passed.
- `npm test`: 72 API/migration/security tests passed.
- Commerce browser regression: 18/18 passed.
- Liquid/editor/mobile regression: 15/15 passed.
- New v15 browser suite: 9/9 passed.

**114 API/browser checks passed, including 42 browser checks.** No uncaught browser exceptions were observed.

v15 checks cover split hero with two real promo assets; no dots in DOM on any viewport; real-touch autoplay; merchant promo/slide edits and publication; black primary fills after plan rerender; glass header; compact typography; local Noto Sans Bengali decoding and system-ui fallback; responsive fit at 360–1440px; reduced-motion; digital billing/cart/wishlist; account selection; and draft Studio previews.

Migration tests retain customised product names/images, merchant account hashes, uploaded hero/promo links, navigation, SEO, custom page order and paid order/subscription snapshots. Only known factory hero artwork is replaced. Earlier migration assertions were updated for the intentional font/artwork presentation change while retaining history/link/order checks.

Retained checks cover server pricing, authentication/Origin/CSRF, private order ownership, idempotent mixed checkout/confirmation, protected downloads, expiry/suspension, payment-reference reuse protection, monthly/yearly Bangladesh-calendar terms, renewals/cancellation, product/plan deletion and restore, custom icon upload/reset, menus/submenus, section insertion/drag/keyboard ordering, theme save/publish/rollback, date/video blocks and analytics.

Actual styling issues caught during review were fixed: old high-specificity brand gradients overrode black primary controls; lower-specificity reduced-motion rules left transitions enabled. Desktop/mobile screenshots were reviewed, including the split banner, product grid, category icons, black pricing/actions and glass navigation.

Limits: no live payment gateway or hosting/Laravel provisioning was tested or added. Third-party iframe embedding remains controlled by that website. Synthetic performance figures in PERFORMANCE.md are not production/physical-device guarantees.

Clean distribution check: the release ZIP was extracted into a new folder and `npm ci --omit=dev` installed all 73 production packages successfully. Merchant setup/login, v15 health, Brotli delivery, decoded banner assets, two fixed promos, no-dot slideshow, black actions and desktop/mobile layout passed against that installation. All 72 API tests also passed from the extracted copy. Test credentials and temporary databases were removed after verification.
