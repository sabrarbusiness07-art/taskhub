# WebMart Obsidian v15 — ব্যবহার ও আপডেট

এটি digital product, website rental এবং monthly/yearly service plan-এর ecommerce site। নতুন version-এ glass header, black liquid buttons, Techland-এর মতো compact typography এবং বামে auto slideshow / ডানে দুইটি fixed image আছে। Desktop/mobile কোথাও slideshow dots নেই।

## আগের site আপডেট করুন

আগের server বন্ধ করে পুরো project folder backup রাখুন। নতুন ZIP আলাদা folder-এ extract করুন। আগের `data`, `public/uploads`, এবং থাকলে `public/media` নতুন folder-এর একই জায়গায় copy করুন। এগুলোতে আপনার account, product, ছবি, order, plan ও settings থাকে। পুরোনো source বা node_modules copy করবেন না।

নতুন folder-এর terminal-এ:

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

Website: http://localhost:5000
Admin: http://localhost:5000/admin

আগের login ব্যবহার করুন। প্রথমবার install হলে Node.js 24.x (কমপক্ষে 24.14) ব্যবহার করে server start-এর আগে `npm.cmd run setup` দিয়ে নিজের merchant email/password তৈরি করুন। কোনো default password নেই। START-WEBMART.cmd launcher dependencies পরীক্ষা করেও চালাতে পারে।

## Hero-এর ছবি ও links

Admin → Store settings → Hero image slideshow। মূল slideshow ও ডান পাশের Fixed promotional images নিজের ছবি দিয়ে বদলান। প্রতিটি ছবির description ও destination link আলাদা। Add, Remove ও reorder controls আছে। প্রথমবার v15 চালু হলে split/image layout apply হবে এবং প্রয়োজন হলে default দুইটি promo দেওয়া হবে। আপনার upload করা hero/promo ছবি ও custom links থাকে। পুরোনো factory banner-গুলো শুধু নতুন digital-commerce artwork পায়।

মূল desktop banner 1920×760 এবং fixed ছবি প্রায় 960×400 ভালো মানায়। Mobile image optional; included mobile artwork 900×500। Mobile-এ fixed ছবি দেখাবেন কি না checkbox আছে। Slideshow প্রতি পাঁচ সেকেন্ডে বদলায়। Reduced-motion চালু থাকলে autoplay বন্ধ থাকে। Desktop-এ SVG arrow controls এবং hover/focus-এ pause option আছে; dot/counter নেই।

## Fonts ও কালো liquid controls

Techland-এর প্রকাশ্য CSS অনুযায়ী বাংলা text-এ local Noto Sans Bengali এবং ইংরেজিতে system-ui font ব্যবহার হয়েছে। ফলে Windows, macOS বা Android-এ Latin face কিছুটা আলাদা হবে। Theme editor → Style থেকে font, menu, submenu, mobile bottom links ও icon বদলাতে পারেন। Primary/secondary buttons black liquid style-এ থাকে; WebMart logo-এর purple identity রাখা হয়েছে।

## Product, plan ও customer account

Products & services → Add/Edit product থেকে ছবি/gallery, video, description, specifications, FAQ, license, delivery, prices, monthly/yearly plans ও preview link দিন। এককালীন purchase এবং subscription—দুটিই আছে। Preview Show/Hide ও auto-load controls আছে; বাইরের site iframe বন্ধ রাখলে preview hide করুন। Product, plan, menu, custom section, page ও slide remove করা যায়; product Deleted products থেকে draft হিসেবে restore করা যায়। পুরোনো paid history সংরক্ষিত থাকে।

Wishlist count, cart, checkout, protected download, plan expiry, renewal request, account sidebar active state ও analytics কাজ করে। Payment verification এবং website/hosting setup আপনার team পরিচালনা করবে; automatic payment gateway/provisioning যুক্ত করা হয়নি।

## দেওয়া reference ZIP সম্পর্কে

unslop-এর design guidance ও design-md references ব্যবহার করা হয়েছে; intentionally bad “before” example দোকানটি copy করা হয়নি। Attribution/license ZIP-এর references folder-এ আছে। Public release-এ আপনার private database, sessions, password, .env, backup বা customer uploads নেই। Uploaded v13 folder-এর code v14 base-এর সঙ্গে একই ছিল; merchant data রাখার জন্য উপরের copy steps জরুরি।

বিস্তারিত README.md, RUN-AND-DEPLOY.md, DESIGN.md এবং TEST-REPORT.md-তে আছে।
