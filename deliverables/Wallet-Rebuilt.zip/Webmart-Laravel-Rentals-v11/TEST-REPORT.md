# WebMart Laravel Website Rentals v11 verification

Verified 11 November 2026 on Linux, Node 24.22.1 and Chromium 156. Fixtures use disposable databases and generated credentials.

| Suite | Passed |
|---|---:|
| API, validation, pricing, migration, security and analytics | 39 |
| Rental/signup/account browser regression | 19 |
| All-page visual editor browser regression | 20 |
| Website catalogue/live preview/rental browser regression | 13 |
| Compression, uploads, nested navigation and remote iframe | 11 |
| New slideshow, merchant picture editing, grid and hover | 10 |
| Total | **112** |

New tests validate hero slide images/URLs, six-slide limit, ownership/CSRF-protected settings publication, unsafe URL rejection, actual merchant screenshot upload, alt text, destination edits, reordering and publication. Browser cases cover carousel next/previous/dots/pause, hero CTA dispatch with no overlay, ecommerce cards and canonical website detail links, iframe preview, fast pricing-card hover, reduced motion and no document overflow at 320/390/768px. Raw focused results and hero click-handler time are in INTERACTION-RESULTS.json; this is not full network response time.

The v11 upgrade test preserves account hashes, paid subscription amounts/expiry and custom section order/SEO, retains an existing hero image, snapshots the previous theme, creates a private backup and checks repeat-start idempotence. Public catalogue/menu wording changes deliberately; historical financial records are not rewritten. Old routes continue to work.

All browser suites recorded zero uncaught JavaScript exceptions. The compression-integrity check verifies generated Brotli/gzip assets match source. The supplied pricing/liquid JSON references were retained; the hero CTA intentionally removes the liquid overlay to meet the latest speed requirement.

Windows launchers were inspected but not executed on Windows. Safari/iOS hardware, production hosting, real payment settlement, actual customer Laravel deployment and arbitrary external framing policies are not certified. Starter HTML previews are demonstration assets, not Laravel application source. Existing manual rental activation remains the operating model.

The final ZIP excludes private databases/backups, .env files, credentials, node_modules, logs and test screenshots. Public screenshots and font licenses are included.

Clean extracted production ZIP passed npm ci, asset compression integrity, merchant setup/login, actual server startup, canonical and legacy URLs, slideshow/editor modules, WOFF2 fonts and private-data exclusion.
