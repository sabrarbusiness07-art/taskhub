# WebMart Laravel Website Rentals v11

A rental storefront for complete Laravel website offerings, with an editable hero image carousel, ecommerce-style website cards, live demos and merchant-managed monthly/yearly plans. Bengali instructions: START-HERE-BN.md.

## Start

Use Node.js 24.14+ in the 24.x line. Windows PowerShell:

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

Fresh installation only: run `node scripts/setup-admin.js` before starting and create your own merchant credentials. There are no default credentials. Website: http://localhost:5000; merchant /admin; editor /admin/editor. Health release: `webmart-rentals-11.0.0`. Keep the server terminal open.

## Hero pictures

Store settings → Hero image slideshow. Add up to six pictures, upload PNG/JPEG/WebP, write alt descriptions, set slide destinations, move slides up/down or remove them. Save & publish settings applies all changes. A destination can be `/website?id=your-listing-id` or an HTTPS link. Images are validated server-side and large uploads are optimized in the merchant browser. First image is eager/high-priority; other images are lazy. Rotation is every five seconds, with immediate previous/next, dot, keyboard and pause controls. Hover, focus, a hidden tab, editor preview and reduced-motion preference pause automatic playback. An empty slide list displays a simple brand visual.

Hero CTA buttons use short 80 ms feedback, without turbulence filters, liquid overlays, pointer-tracking effects or page-snapshot transitions. Pricing cards have a 100 ms hover/focus lift. See PERFORMANCE.md for measurement scope.

## Websites and rental plans

Websites & services → Add/Edit service → Listing type: Laravel website. Upload its screenshot, set its description, features, website pages, public HTTPS live demo URL and monthly/yearly plan prices. The homepage and `/websites` show website product grids. Each card links to `/website?id=...`, where visitors can scroll the live preview, open the website in a separate tab and choose a rental plan. Existing `/templates` and `/template` links remain compatible.

The included Atlas/Forma/Folio HTML previews are demonstration assets, not complete Laravel applications or independently provisioned customer websites. Replace their screenshots/demo links and agree the actual Laravel application, modules, deployment and support scope before offering your own live services. This release changes the rental storefront and merchant tools; it does not create the Laravel source code of customer applications. The storefront runtime remains Node/SQLite.

A rental request remains pending until the merchant verifies payment and activates it. Customer accounts show their plan, start/end dates, remaining days, messages and renewal history. Hosting/provisioning, recurring charging and refunds are manual external operations. External demo websites must permit framing for inline previews; Open live preview remains available if their policy blocks embedding.

## Upgrade

Stop the previous server and retain its full folder as a backup. Extract v11 separately. Copy your existing private `data` and own `public/uploads` into the matching locations. Do not copy old code or node_modules. Install dependencies, then start.

The one-time v11 migration backs up an existing merchant database under private data/backups, updates public template wording and local links, preserves custom page order/SEO and retains prior live/draft themes as `site-live-before-v11` and `site-draft-before-v11`. Existing accounts, paid subscription records, amounts and expiry are retained. An existing legacy hero image becomes the first slideshow image. Custom hero text remains unless it is the stock old headline. Product storage keys/IDs and API compatibility remain stable. The release ZIP contains no private database, password or .env.

## Editing and delivery

Theme Studio retains 16 page templates, custom pages, safe content editing, drag/touch/keyboard section ordering, draft/publish/version checks and rollback. Header menu/submenu and footer links remain editable under Style. Use Store settings for the slideshow image list. Local WOFF2 Plus Jakarta Sans and Manrope include their OFL licenses. References/components contains the supplied design references; layouts are adapted to native DOM/CSS.

Brotli/gzip assets and API compression are retained; public pages do not load merchant/editor code. Run `npm run build:assets` after manual public-code edits; `npm run check` detects stale compressed files. Catalogue/theme edits do not require a build. Back up with `npm run backup` and back up uploads separately. For production use persistent single-instance Node hosting, HTTPS PUBLIC_URL, NODE_ENV=production and private writable DATA_DIR. SQLite is not a stateless edge database.

## Verification

```sh
npm ci
npm run check
npm test
npx playwright install chromium
npm run test:browser
npm run test:editor
npm run test:templates
npm run test:fast
npm run test:slideshow
```

BROWSER_EXECUTABLE can select an installed Chromium; BROWSER_ARTIFACTS sets a screenshot folder. Tests use disposable databases and generated credentials. See TEST-REPORT.md for actual coverage and limits.
