export const stylesheet = "/storefront.088fd449c758.css";
export const layout = "wm-2b4f739eb509";
