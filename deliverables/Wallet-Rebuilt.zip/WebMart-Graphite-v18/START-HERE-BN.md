# WebMart Graphite v18 — চালু ও আপডেট

Desktop-এ কালো sidebar। উপরের toggle দিয়ে আইকন বা আইকন ও label দেখানো যায়। Pricing card সমান এবং hover-এ হালকা glow হয়। Mobile logo/menu, glass bottom navigation এবং product preview-এর layout আগের মতো আছে।

## পুরোনো site আপডেট

আগের server বন্ধ করে পুরো folder backup রাখুন। নতুন ZIP আলাদা folder-এ extract করুন। আগের `data`, `public/uploads`, এবং থাকলে `public/media` নতুন folder-এর একই জায়গায় copy করুন। এগুলোতে account, product, ছবি, order, plan ও settings আছে। পুরোনো source বা node_modules copy করবেন না। নিজের DATA_DIR / UPLOAD_DIR ব্যবহার করলে সেই private settings বজায় রাখুন।

নতুন folder-এর PowerShell terminal-এ:

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

Website: http://localhost:5000
Admin: http://localhost:5000/admin

Terminal-এ `WebMart v18.0.0 is running` দেখা গেলে নতুন version চলছে। পুরোনো server ৫০০০ পোর্টে চালু থাকলে আগে সেটা বন্ধ করুন। Browser-এ http://localhost:5000/api/health খুলে `webmart-graphite-18.0.0` মিলিয়ে নিতে পারেন।

আগের login ব্যবহার করুন। নতুন install হলে Node.js 24.x (24.14+) ব্যবহার করুন; start-এর আগে `npm.cmd run setup` দিয়ে নিজের merchant account তৈরি করুন। কোনো default password নেই। START-WEBMART.cmd দিয়েও চালানো যায়।

## কী পরিবর্তন হয়েছে

- Desktop navigation শুধু বাঁ পাশে। পুরোনো CSS পাওয়া গেলে v18 সঠিক CSS লোড করার পরে পেজ দেখায়।
- Mobile dock-এ transparent glass, আলোর rim ও স্পষ্ট active tab। Header-এ logo/menu আছে।
- বামে auto slideshow, ডানে দুইটি fixed promo; নিজের ছবি/link ঠিক থাকে। Pause/resume control নেই। Mouse hover/keyboard focus, hidden tab ও reduced-motion preference-এ slideshow নিজে pause হয়।
- Admin dashboard, product editor, settings, tables, Theme Studio ও modal কালো-ধূসর; লেখা/form স্পষ্ট রাখা হয়েছে।
- Loading-এর জন্য একটিমাত্র compressed CSS bundle, published hero preload, native module preload ও cache যোগ হয়েছে। Liquid effect-এ প্রতি mouse move-এ কাজ হয় না; ছোট press ripple থাকে। PERFORMANCE.md-তে তুলনামূলক পরীক্ষার ফল আছে।

## নিজের content সম্পাদনা

Admin → Store settings → Hero image slideshow থেকে slide/mobile image ও দুইটি promotional image, link, description, add/remove/reorder বদলান। Theme Studio থেকে page/section, drag ordering, menu/submenu, mobile quick links, SVG/custom icons, ছবি/text/video/date সম্পাদনা করুন। Products & services থেকে product/gallery, description, preview, private download, one-time price ও monthly/yearly plans দিন। Wishlist/cart/customer account ও analytics আছে। Payment যাচাই ও activation আপনার team করবে।

v16 প্রথমবার চালু হলে live/draft action accent graphite হয়। আগের theme/settings এবং database-এর private backup `data/backups` ও `*-before-v16` snapshots-এ থাকে। Customer, paid history ও নিজের uploaded hero/product ছবি মুছে যায় না। Public ZIP-এ private database, password, .env, backup ও customer uploads নেই।

Source CSS/MJS বদলালে `npm.cmd run build:assets` চালিয়ে server restart করুন। Bundle file সরাসরি edit করবেন না। বিস্তারিত README.md, RUN-AND-DEPLOY.md, TEST-REPORT.md-তে আছে।
