# WebMart Graphite v18 verification

Node 24.22.1 and Chromium 156. Browser checks used isolated temporary databases.

- Asset check passed for source syntax, seed media, the fingerprinted stylesheet and its Brotli/gzip copies.
- 74 API and migration tests and 1 launcher test passed.
- 58 browser checks passed across the commerce, liquid, Obsidian, Onyx, Graphite and layout recovery suites.

The Graphite tests cover expanded and compact desktop navigation, preference persistence, custom submenus, Escape, search and the mobile drawer. At desktop widths from 801–1440px the three pricing cards share the same position and dimensions, with aligned prices, calls to action and details. The yearly price switch preserves alignment. Hover changes the shadow without moving the card.

The existing commerce tests verify the mobile preview device switch, cart, account, private downloads, editorial controls and storefront publication. A visual comparison at 390px verified that the mobile header, hero, promos and glass dock retain their layout with the new palette. A computed style audit checked home, catalog, product, plans, account, admin sign-in, cart, wishlist and help on desktop and mobile for residual pink or purple UI colors.

The reported layout was reproduced by serving v16 styles to the v17 markup. In that run desktop navigation was a 1334px sticky top bar and the featured pricing card was offset 16px. v18 tests verify recovery from an outdated HTML stylesheet URL and from old CSS at the expected URL. They also check a missing stylesheet retry, an uploaded banner path, published section order and the mobile menu. The launcher test holds the port open and confirms that a second server reports the conflict and exits unsuccessfully.

The extracted ZIP installed all 73 production dependencies. Setup, merchant login, release health, compressed CSS and desktop/mobile rendering passed, as did all 75 Node tests from that extraction.
