# v12 interface changes

The supplied Premium v11 app remains the base. The wallet poster reference informs the full-width composition, not the business or colour palette: the store continues to rent websites, and its supplied blue–violet W logo is retained.

The hero has full-width desktop/mobile artwork, overlay or image-only modes, configurable text side and cover/contain fitting. Its carousel reuses the existing controls and editor workflow. Local typefaces now use the six requested families. Liquid controls follow the supplied JSON's cursor-origin fill, changing blob and ripple, adapted to native DOM/CSS with one semantic label and no click delay.

Marketplace cards, FAQ, live demo previews, account navigation, collapsible merchant sidebar, rental activation and all-page Theme Studio are preserved from the uploaded project. Safe font enums, mobile picture validation and an idempotent presentation migration were added. Private financial/customer history is retained.
