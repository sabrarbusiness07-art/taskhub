# WebMart Premium v12

An update to the supplied WebMart-Premium-v11 project: a full-width image hero, editable desktop/mobile pictures, six local fonts and liquid hover/focus/click controls. The supplied W logo's blue–violet palette is retained. Rental management, website listings, merchant/customer accounts and the all-page editor remain available.

## Start or upgrade

Use Node.js 24.14+ in the 24.x line. Stop the old server and keep its complete folder as backup. Extract v12 separately; copy your existing private `data` and your `public/uploads` into their matching locations. Do not copy old code or node_modules. Existing users and paid rental history are preserved. First startup makes a private database backup and theme snapshot before migrating presentation settings.

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

Fresh installation only: run `node scripts/setup-admin.js` before starting and choose your own credentials. No default password is shipped. Website: http://localhost:5000 · merchant: /admin · Theme Studio: /admin/editor. Health release: `webmart-premium-12.0.0`. START-HERE-BN.md has Bengali instructions.

## Full-width hero

Store settings → Hero image slideshow. Upload desktop images, optional mobile images, descriptions and destination links; reorder/remove slides and Save & publish settings. Up to six slides are supported. Recommended desktop artwork is 1920×840, with a separate 800×1000 mobile image. Wide uploads retain up to 2400px, while ordinary screenshots retain up to 1600px when compression is needed.

Banner display offers:

- Image with text and buttons: the existing hero headline/description sit over the banner. Choose left/right text placement.
- Image only: for finished advertising pictures with their own text, like the supplied layout reference. The whole picture links to the configured destination.
- Cover or contain: crop to fill the hero, or show the complete artwork. Optional mobile pictures avoid unreadable desktop banner text on phones.

The hero is full-width even when ordinary page sections use the contained content width. First image is high priority; other slides are lazy. Controls include arrows, dots, position, keyboard navigation and pause. Automatic rotation pauses for hover, focus, hidden tabs, editor preview and reduced motion. The included banners are original project artwork using demonstration website screenshots; references/hero-artwork.html retains their composition source.

## Typefaces and liquid buttons

Inter handles reading and forms; Poppins handles brand/headings; Roboto handles numeric pricing; Playfair Display supplies the editorial banner line; Geist Sans handles merchant/editor UI; JetBrains Mono handles reference IDs and code. Theme Studio → Style exposes all six for headings/body and displays samples. Fonts are self-hosted WOFF2 with official OFL licenses. See FONT-LICENSES.md for provenance and glyph coverage.

Buttons use the supplied liquid-button JSON as a visual/interaction reference: a cursor-origin fill, smooth shape change, keyboard focus fill and click ripple. One accessible label is retained. Pointer work runs only when needed; animation never gates navigation or form submission. Reduced motion disables the visual transition. This is a native DOM/CSS/Web Animations adaptation, not an added React animation runtime.

## Data and migration

A one-time v12 migration maps the previous four font aliases to the new font families, updates the stock rounded-button setting and creates `site-live-before-v12`/`site-draft-before-v12` snapshots. Existing custom colours, page ordering, SEO, custom hero pictures, accounts, sessions and paid subscription records are retained. Old three-image stock previews gain wide/mobile artwork while preserving their order, descriptions and links. The migration does not reseed merchant edits on restart.

The ZIP excludes private databases/backups, .env files, node_modules and credentials. Copying your own data is essential to keep the existing merchant login. Never publish your private data directory.

## Rental operations and compatibility

Website cards lead to product pages with scrollable live demos and a separate Open live preview link. Requests stay pending until the merchant verifies payment and activates a rental. Customers see their plan, start/expiry dates and renewal history. Provisioning, recurring charges and refunds remain manual external operations. Demo websites must permit framing to display inline; their external links remain available when embedding is blocked.

Starter HTML previews are demonstration assets, not the source code of customer Laravel applications. Replace their screenshots/demo links with your actual Laravel offerings and agree service scope before publishing. The rental storefront runtime remains Node/SQLite. Existing catalogue IDs, routes, API compatibility, header/submenus, account UI, analytics and section ordering are retained.

Use persistent single-instance Node hosting with HTTPS PUBLIC_URL and NODE_ENV=production; private DATA_DIR and writable uploads are required. Run `npm run backup` and back up uploads separately. Do not use ephemeral edge storage for SQLite.

## Verification and asset rebuilds

```sh
npm ci
npm run build:assets
npm run check
npm test
npx playwright install chromium
npm run test:browser
npm run test:editor
npm run test:templates
npm run test:fast
npm run test:slideshow
npm run test:premium
npm run test:banner
```

Manual public-code changes require `npm run build:assets`; Theme Studio/catalogue edits do not. Brotli/gzip and source-integrity checks are retained. BROWSER_EXECUTABLE selects an installed Chromium; BROWSER_ARTIFACTS chooses a screenshot folder. Tests use isolated fixtures. See TEST-REPORT.md for actual results and limits.
