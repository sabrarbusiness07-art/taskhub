# WebMart Premium v12 verification

Verified 12 November 2026 on Linux, Node 24.22.1 and Chromium 156. Fixtures use isolated temporary databases and generated credentials.

| Suite | Passed |
|---|---:|
| API/security/schema/migration/font/mobile-image validation | 44 |
| Rental, signup, checkout, activation and account | 19 |
| All-page Theme Studio | 20 |
| Website catalogue, live preview and rental identity | 13 |
| Compression, uploads, nested navigation and remote iframe | 11 |
| Slideshow editing, picture upload, website grid and pricing hover | 10 |
| Uploaded Premium v11 FAQ/sidebar/account regressions | 7 |
| New full-width banner, six fonts and liquid controls | 12 |
| Total | **136** |

All suites passed with zero uncaught browser exceptions. New browser cases verify true viewport-width imagery, readable headline/first-line colour, absence of browser-panel chrome, actual decoding of all six local fonts, deferred merchant/technical font requests, visible pointer/focus liquid fill, one accessible label, immediate navigation during ripple, preserved wide-upload resolution, desktop/mobile images, image-only/overlay display, cover/contain fit, text side, font publication and reduced-motion autoplay behavior.

The full-width banner was checked at 320/390/768/1024/1920px. The uploaded Premium regression additionally checks six public routes at eight widths from 320 to 1920px, FAQ keyboard toggles, the collapsible merchant sidebar, account anchors and logout. Existing real remote-preview fixture checks are retained; arbitrary third-party iframe availability is not guaranteed.

Migration tests cover private backup/snapshot creation, account hashes, paid amounts/periods/expiry, custom colours, custom banner images, page order/SEO and repeat-start idempotence. A stock-banner upgrade specifically retains merchant order, descriptions and destination links. A consistent copy of the actual supplied v11 database was also opened with v12: users/orders/subscriptions/sessions and section ordering were unchanged, the new font aliases were applied, and private backup/theme snapshots were present.

Windows batch execution, real iOS/Safari hardware, production hosting, payment settlement and customer Laravel application provisioning were not exercised. Starter previews remain demonstration assets. No database, backup, credentials, .env, node_modules or test screenshots are included in the release.

Clean extracted production ZIP passed npm ci, compressed-source integrity, merchant setup/login, actual server startup, all 16 page templates, desktop/mobile banner assets, all eight WOFF2 files, liquid/editor modules, Brotli/gzip and private-data exclusion.
