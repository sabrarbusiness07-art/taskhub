# WebMart Premium v12

আগের server বন্ধ করে পুরো folder backup রাখো। নতুন ZIP আলাদা folder-এ extract করো। পুরোনো `data` ও নিজের `public/uploads` নতুন folder-এ কপি করো; পুরোনো code/node_modules নয়। আগের account/password ও paid rental থাকবে। Upgrade-এর আগে private backup ও theme snapshot হবে।

Node.js 24 (24.14+) দিয়ে project terminal-এ:

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

শুধু নতুন installation হলে start-এর আগে `node scripts/setup-admin.js` চালিয়ে নিজের merchant credentials দাও। Website http://localhost:5000; admin http://localhost:5000/admin।

## Reference-এর মতো full-width banner

**Store settings → Hero image slideshow**। Desktop ছবি upload করো; চাইলে প্রতিটি slide-এর আলাদা mobile ছবি দাও। ছবি, description, destination link, slide order—সব বদলানো যাবে। **Save & publish settings** দিলে live হবে।

- **Banner display → Image with text and buttons:** banner-এর ওপর headline, description ও liquid CTA থাকবে।
- **Image only:** নিজের ছবির মধ্যেই লেখা/design থাকলে এটি বেছে নাও; আলাদা overlay থাকবে না।
- **Banner text position:** Left/Right।
- **Banner image fit:** Cover বা সম্পূর্ণ ছবি দেখানোর জন্য Contain।
- Desktop-এর জন্য 1920×840, mobile-এর জন্য 800×1000 ছবি ভালো। সর্বোচ্চ ৬টি slide রাখা যায়।

Arrows, dots, keyboard ও pause আছে। Hover/focus, editor preview, hidden tab ও Reduce motion-এ autoplay থামে। Source ZIP-এর W logo-এর blue–violet রঙ রাখা হয়েছে।

## ছয়টি font

**Theme editor → Style → Heading font / Body font** থেকে Inter, Roboto, Poppins, Playfair Display, Geist Sans, JetBrains Mono বেছে Publish করো। Font samples-ও দেখা যাবে। Fontগুলো local WOFF2; visitor-এর Google Fonts connection লাগে না। যেসব script এই fonts-এ নেই, সেগুলো system fallback ব্যবহার করবে।

Liquid button-এ hover/focus fill এবং click ripple আছে। Click বা submit animation শেষ হওয়ার জন্য আটকে থাকে না। Reduce motion চালু থাকলে motion বন্ধ থাকবে।

Website listings, Laravel demo links, monthly/yearly plans, customer expiry ও merchant confirmation আগের মতো আছে। Starter demo-গুলো HTML illustration; নিজের actual Laravel website-এর screenshot/demo link দিয়ে offering সাজাবে। External site iframe block করলে Open live preview দিয়ে খোলা যাবে।

Manual CSS/JS edit করলে `npm run build:assets` চালাবে। Theme Editor বা product/settings edit-এ build লাগে না। Health endpoint `/api/health`-এ release `webmart-premium-12.0.0` দেখাবে।
