# Main v12 files

- public/slideshow.mjs and hero-defaults.json: full-width banner markup and default images; existing controller lifecycle retained.
- public/banner-v12.css, fonts.css and liquid.mjs: full-width/responsive layout, requested typefaces, fill/ripple interaction.
- public/hero-editor.mjs and admin.mjs: mobile images and banner display/position/fitting controls.
- public/page-content.mjs, studio.mjs and lib/site-editor.js: full-width hero wrapper and six editable font options.
- lib/validation.js and premium-v12.js: validated mobile/banner settings and safe one-time migration.
- public/assets/heroes and references/hero-artwork.html: original wide/mobile artwork and composition source.
- public/fonts: local WOFF2 families with official OFL licenses.
- Tests and source-matched Brotli/gzip delivery assets were updated.
