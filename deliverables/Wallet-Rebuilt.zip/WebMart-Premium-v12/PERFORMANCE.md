# v12 delivery and interaction notes

Liquid buttons use a pointer-origin CSS fill and a Web Animations click ripple. No animation completion is awaited before following a link or submitting a form. Pointer work is limited to the hovered button and at most one scheduled frame; no idle liquid animation loop or per-frame SVG turbulence is used. Reduced motion removes transitions/ripples.

The new full-width hero uses local compressed WebP artwork: desktop files are approximately 40–45 KB and mobile files approximately 30–33 KB. One first picture is high priority; later slides are lazy. The carousel retains one cleanup-managed timer and pauses for hidden tabs, focus/hover, editor preview and reduced motion. Banner image-only mode avoids duplicate HTML copy on precomposed promotional images.

Fonts are local WOFF2 and font-display: swap preserves immediate text. The six requested families are available; only styles/families actually used are fetched. Merchant/editor and technical fonts are deferred until needed. The font choices and wide imagery change the page's transfer profile, so previous v10 resource-reduction percentages are not claimed for this release.

Brotli/gzip assets, source integrity checks, asynchronous store JSON compression, lazy merchant-code loading, image upload optimization and private/no-store APIs remain enabled. Wide images preserve up to 2400px when optimized; ordinary screenshots preserve up to 1600px. INTERACTION-RESULTS.json records the focused local browser result, not production latency or a complete Core Web Vitals audit. External demo performance depends on its host.
