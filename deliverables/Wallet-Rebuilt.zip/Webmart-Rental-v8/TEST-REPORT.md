# WebMart Rental v8 verification

Verified 11 November 2026 on Linux with Node 24.22.1, npm 11.9.0 and Chromium 156.0.8078.79. Automated tests use temporary SQLite databases and generated credentials; no real payment or customer account is exercised.

- JavaScript syntax and seed assets: passed (`npm run check`).
- API/schema tests: **30 passed, 0 failed** (`npm test`).
- Rental browser journey: **19 passed, 0 failed** (`npm run test:browser`).
- All-page editor browser journey: **20 passed, 0 failed** (`npm run test:editor`).
- Extracted production ZIP: clean dependency installation, syntax, real server startup, rental-only catalogue, all 14 templates, static assets/routes and private-data exclusion passed.
- Supplied v7 database migration on a disposable consistent copy: passed; account hashes and historical orders unchanged, physical catalogue archived, one rental service retained, private backup created. Synthetic migration tests also cover custom pages, original monthly prices, yearly conversion and repeat-start safety.

API coverage includes rental-only catalogue, monthly/yearly server pricing, Bangladesh calendar month-end/leap-year boundaries, authentication/CSRF/origin/customer ownership, pending-only requests, price-change rejection, idempotency, payment verification, duplicate payment references, activation/renewal, expiry, suspension/cancellation, private notes, decline, plan editing/version conflicts, safe URLs, editor draft/publish/rollback, all 14 template schemas, validated content imports, live-browser deduplication/TTL, service popularity, date ranges and CSV.

Chromium journeys cover premium self-hosted fonts, liquid button labels, desktop mega menu and Escape dismissal, annual pricing, plan-preserving signup, checkout, merchant activation, customer plan/expiry/history/service link, renewal, suspension/private-note privacy and actual service price editing. Editor checks cover copy/button-link changes, private drafts, extra sections, FAQ items, visibility, duplicate/delete, publish, custom pages, all 14 page previews, illustrative customer-account preview, real HTML drag, keyboard reorder, actual Chromium touch input on section handles, persisted ordering, presets, mobile preview, custom mega-menu links, theme export and rollback. No uncaught browser JavaScript exceptions were recorded.

Customer/store pages and merchant overview, rentals, services, editor and analytics were checked for document overflow at **320, 390 and 768px**, alongside desktop screenshots. Native mobile drawer and reduced-motion behavior were exercised. This is automated Chromium/Linux coverage; Windows batch scripts were inspected, but were not executed on Windows. Safari/iOS and real mobile hardware were not tested.

Rental activation is a merchant-managed record. Real payment settlement, refunds, recurring charging, website provisioning, external hosting suspension, production deployment and real service URLs were not exercised. The application does not automate those operations. Analytics describes pseudonymous browser activity rather than verified unique people.

The release excludes private databases, backups, .env files, credentials, node_modules, logs, test screenshots and obsolete physical-product upload assets. Runtime dependencies are locked and should be installed with `npm ci --omit=dev`.
