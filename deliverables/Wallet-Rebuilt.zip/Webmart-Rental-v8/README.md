# WebMart Rental v8

A rental-only website and digital-services platform rebuilt from the supplied WebMart Studio v7. Customers choose monthly or yearly plans, submit requests, and see their confirmed plans, expiry dates and renewal history in their account. Merchants verify payment and activate/manage rentals. Bengali startup instructions: START-HERE-BN.md.

## Local startup

Use Node.js 24.14+ in the 24.x line. Windows: double-click START-WEBMART.cmd. For a new merchant, run SETUP-MERCHANT.cmd first. There are no default credentials. PowerShell commands:

```powershell
npm.cmd ci --omit=dev
node scripts/setup-admin.js
npm.cmd start
```

Existing merchants keep their existing login after copying their private data as described below. Store: http://localhost:5000 · Merchant: /admin · Theme Studio: /admin/editor · Analytics: /admin/analytics. Keep the terminal open. The health endpoint reports `webmart-rental-8.0.0`. Native browser modules require no frontend build.

## Upgrade from v7

Stop the old server and retain its entire folder as a backup. Extract v8 into a separate folder; copy the old `data` directory and your `public/uploads` into the matching locations. Do not copy old code or node_modules. On first startup a consistent SQLite backup is written to private `data/backups/before-rental-v8-*.sqlite`. Accounts, orders and history remain in the database. Physical products are archived and excluded from the public catalogue. The old Basic/Advanced/Pro service becomes a rental service with the original monthly prices; initial yearly prices are exactly 12 times monthly, without an invented discount. Permanent-purchase options disappear.

Built-in page layouts and rental-specific store copy switch to v8. Previous live/draft page configurations are retained as private `site-live-before-v8` and `site-draft-before-v8` database records, and custom pages remain. Contact details and configured manual payment accounts are retained. The ZIP contains no customer database, backup, merchant password or .env file. Your private data must be copied locally to retain your existing login.

## Rental operations

Services & plans manages service copy, imagery, enabled plans, features and separate monthly/yearly BDT prices. Customer rentals contains pending requests and confirmed subscriptions. A request does not activate a plan. The merchant must verify the actual payment before confirming; activation records its amount, start and calendar expiry. Confirmation retries cannot activate/extend twice; verified mobile payment references cannot be reused. Changed catalogue prices require the customer to review a new quote; an already submitted request retains its agreed price.

Customers see their own selected plan, billing term, expiry, remaining days, service link, merchant messages and rental history. Renewal of the same plan and term extends from the current expiry, or from confirmation when expired. Cancellation is a customer request for merchant review. Merchants can set service URLs, customer messages, private notes, suspension, cancellation and expiry adjustments. Dates display in Asia/Dhaka. Calendar billing handles short months and leap years. Expired state is computed on reads.

Payment is an invoice arrangement or configured manual bKash/Nagad/Rocket reference, verified by the merchant. This application records rental entitlements; website provisioning, actual hosting suspension, recurring charging and refunds are manual external operations. No gateway, deployment automation or recurring-charge integration is included. Fresh service features are editable starting scope, which the merchant should align with the service they supply.

## Theme Studio

14 built-in page templates: Home, Services, Plans, Service, Checkout, Account, Login, Register, Request confirmation, About, Contact, Terms, Privacy and Help. Custom pages use `/page?name=your-handle`. Static copy, links, colours, spacing and images can be edited in the preview. Add hero, text, image, service collection, categories, feature cards, FAQ, gallery, CTA, announcement, spacer and divider sections. Drag section rows or their handles up/down; Alt+ArrowUp/Down and Move up/down provide keyboard alternatives. Touch handles support pointer dragging. Duplicate/hide/delete added sections. Required functional cores remain protected.

Presentation edits do not rewrite live customer records, calculated prices, authentication or required form logic: manage actual services and subscriptions in their merchant screens. Drafts remain private until Publish. All edited templates publish together with version checks; conflicting tabs are rejected. Undo/redo, custom pages, JSON import/export, discard and previous-publication restore are retained. Imports validate allowed fields and safe links, without arbitrary code or HTML. Limits include 40 pages, 50 sections/page, 700 copy overrides/page and 5 MB image uploads.

The liquid default uses self-hosted Plus Jakarta Sans and Manrope with their OFL licenses. Pointer-responsive pill buttons, glass surfaces, a notch-style header, mega menu, accessible mobile drawer and segmented pricing are adapted from the supplied JSON references; they use native DOM/CSS rather than an added React runtime. Older warm/midnight palettes remain optional. See DESIGN.md and references/components.

## Analytics

Analytics shows live browser activity, page/service popularity, daily view history, device mix and CSV export over 7/30/90-day ranges. Visible tabs send heartbeats about every 25 seconds; browsers active within 90 seconds count as live. Dashboard refreshes every 10 seconds. Merchant and editor-preview traffic is excluded. A browser is counted once across multiple tabs. Cookies provide pseudonymous browser identities; IPs, fingerprints and customer identities are not stored in analytics. Counts measure recorded browser activity, not verified unique people. Legacy aggregate views remain separately visible. New service-level history begins after the analytics upgrade.

## Hosting and backups

Use persistent single-instance Node 24 hosting with writable private data and uploads. Set NODE_ENV=production and PUBLIC_URL to the exact HTTPS origin. HOST defaults to 127.0.0.1 and PORT to 5000. TRUST_PROXY=1 is appropriate only behind one trusted reverse proxy. DATA_DIR and UPLOAD_DIR override storage locations. Configure variables on the host; .env files are not loaded automatically. Run `npm run backup` and back up uploads separately. To restore, stop the app, restore the matching database/uploads, remove stale WAL/SHM files from the stopped installation if needed and restart. Keep backups outside public/uploads.

## Verification

```sh
npm ci
npm run check
npm test
npx playwright install chromium
npm run test:browser
npm run test:editor
```

BROWSER_EXECUTABLE may point to an installed Chromium binary. BROWSER_ARTIFACTS selects a screenshot/results folder. Tests use disposable databases and generated credentials. See TEST-REPORT.md for actual results and limits. Legacy v5 import tooling is retained only for explicit older-format migration; it is not the v7 upgrade path.
