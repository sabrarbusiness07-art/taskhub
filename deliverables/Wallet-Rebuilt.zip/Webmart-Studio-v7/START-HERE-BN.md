# WebMart Theme Studio v7 — শুরু করার নিয়ম

## আগে থেকেই v6 ব্যবহার করলে

1. পুরোনো server বন্ধ করো (terminal-এ Ctrl+C)। পুরোনো ফোল্ডারটি backup হিসেবে রাখো।
2. নতুন ZIP **আলাদা ফোল্ডারে** extract করো।
3. পুরোনো `data` ফোল্ডার নতুন project-এর ভেতরে কপি করো। পুরোনো `public/uploads`-এর নিজের আপলোড করা ছবিগুলোও নতুন `public/uploads`-এ রাখো। অন্য পুরোনো code বা node_modules কপি কোরো না।
4. Windows-এ `START-WEBMART.cmd` double-click করো। Node 24 লাগবে; dependencies না থাকলে script নিজেই `npm.cmd ci --omit=dev` চালাবে। ইন্টারনেট লাগবে।
5. `http://localhost:5000/admin` খোলো। **আগের merchant email/password-ই কাজ করবে**। আবার setup করে account মুছতে হবে না।

প্রথম v6→v7 startup-এ private `data/backups` ফোল্ডারে consistent database backup হয়। Products, orders, accounts, store settings ও আগের aggregate views রাখা হয়। ZIP-এ তোমার private database বা password দেওয়া নেই; নিজের data কপি করা গুরুত্বপূর্ণ।

## সম্পূর্ণ নতুনভাবে চালালে

Node.js 24 ইনস্টল করো। `SETUP-MERCHANT.cmd` চালিয়ে নিজের email, নাম ও কমপক্ষে ১২ অক্ষরের password দাও। Password টাইপ করার সময় দেখা যাবে না। তারপর `START-WEBMART.cmd` চালাও।

Terminal দিয়েও করা যায়:

```powershell
npm.cmd ci --omit=dev
node scripts/setup-admin.js
npm.cmd start
```

## সব page সম্পাদনা

Merchant workspace → **Theme editor**। উপরের page selector থেকে Home, Collection, Services, Product, Rental, Cart, Checkout, Login, Register, Account, Order, About, Contact বা policy page বেছে নাও।

- Preview-এর লেখা বা ছবি click করলে ডান পাশে তার settings খুলবে।
- **Add section** দিয়ে text, hero/banner, FAQ, feature cards, image, gallery, products, categories, CTA, announcement, spacer বা divider যোগ করা যায়।
- বাম পাশ থেকে section বেছে Move up/down, visibility, duplicate বা delete ব্যবহার করো। Functional checkout/account block মুছে দিয়ে checkout নষ্ট করা যাবে না।
- **Page** tab-এ page name ও SEO। **Style** tab-এ colours, fonts, layout, header menu এবং extra footer links।
- **New page** দিয়ে নতুন page বানাও। উদাহরণ handle `care-guide`; প্রকাশের পর URL `/page?name=care-guide`। Menu বা CTA-তে এই link যোগ করতে পারো।
- **Save draft** শুধু খসড়া রাখে। **Publish** খসড়া save করে সব edited page live করে। Desktop/Mobile preview আছে।
- **More** থেকে theme JSON export/import, draft discard বা আগের publication restore করা যায়।
- Products-এর নাম, দাম, stock, variant, gallery এবং description বদলাতে **Products** ব্যবহার করো। Contact, shipping fee ও payment account বদলাতে **Store settings** ব্যবহার করো। Theme editor page-এর presentation বদলায়; checkout-এর নিরাপত্তা বা payment হিসাব বদলায় না।

## Live visitors ও views

Merchant workspace → **Analytics**। এখানে live viewer count, page/product popularity, daily history, device mix এবং CSV export আছে। ৭/৩০/৯০ দিনের range বেছে নিতে পারো।

Live count মানে গত ৯০ সেকেন্ডে active থাকা visible browser। Heartbeat প্রায় ২৫ সেকেন্ড পরপর যায়; dashboard ১০ সেকেন্ড পরপর refresh হয়। একই browser-এর একাধিক tab এক visitor; একাধিক page তালিকায় একই browser থাকতে পারে। Admin এবং preview বাদ দেওয়া হয়। পরীক্ষা করতে store একটি private/incognito window-এ খোলো। Cookie মুছে গেলে নতুন browser identity হবে; এটি verified unique people count নয়।

নতুন product-level history upgrade-এর পর থেকে তৈরি হয়। আগের aggregate view totals হারায় না; আলাদা করে দেখানো হয় কারণ পুরোনো data-তে product identity ছিল না।

## চালু হয়েছে কি না

`http://localhost:5000/api/health`-এ release হবে `webmart-studio-7.0.0`। Server-এর terminal চালু রাখবে। `multer` error হলে startup script-এ installation-এর error আগে সমাধান করো; পুরোনো node_modules কপি কোরো না।
