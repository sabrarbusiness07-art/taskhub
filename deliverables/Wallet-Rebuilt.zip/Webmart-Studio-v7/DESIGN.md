# WebMart design system

Primary reference: VoltAgent awesome-design-md, Oura analysis. The full downloaded source is in references/OURA-DESIGN.md with its MIT license. This implementation uses the reference's warm paper, serif hierarchy, stone neutrals, generous spacing and photography-led composition, adapted to the user's existing WebMart products and images.

## Atmosphere
Quiet, considered and editorial. An everyday watch store with a separate website-service offering. Large display headlines introduce a chapter; small sans-serif labels carry facts. Keep the shopping journey clear.

## Tokens
- Paper / page: #f7f1e8
- Elevated surface: #fffdf9
- Primary ink: #1c1b1a
- Stone / secondary actions: #4a4741
- Secondary text: #6d6a64
- Hairline: #e1dcd3
- Primary action: #2464c5, merchant-editable
- Forest: #224228
- Error: #992d20
- Display: Georgia, Times New Roman, serif. A local system serif is used so the package has no external font dependency or proprietary font files.
- Reading / UI: Inter if locally installed, then platform sans-serif. No remote fonts are required.

## Layout and components
Content width is at most 1320px. Desktop gutters are 48px; mobile gutters are 18px. Use 8px-based spacing with a 4px half-step. Display hierarchy ranges from 98px desktop hero to 38–64px mobile headings. Body text stays sans-serif. Product names wrap or clamp to two lines in cards and wrap fully on detail pages.

Pill actions have a minimum 44px tap area (primary buttons 48px). Small product-card controls have accessible labels and remain keyboard reachable. Product media has 14–28px rounding. The large homepage hero uses an arched upper edge and restrained lower rounding. Surfaces separate by hairlines and color, without stacked shadow effects.

Product grids collapse from four to two columns. Detail, checkout and merchant layouts become one column at narrow widths. Data tables scroll within their own container. A responsive menu preserves account and bag access. No whole-page horizontal overflow at 320, 390, 768 or 1440px.

## States and interaction
Every important form has visible validation, pending and error states. Native dialog provides focus containment and Escape dismissal. Focus indicators are visible. Saved hearts expose pressed state. Navigation uses real URLs and browser history. Reduced-motion preference disables smooth scrolling and transitions. Unknown routes provide an explicit 404. Product images have descriptive alt text; decorative icons are hidden from assistive technology.

## Guardrails
Keep conversion blue for decisive actions. Let the existing product photography supply visual richness. Do not add decorative gradients or stack multiple theme patches. Keep one stylesheet, one storefront module and one merchant module. Do not display invented reviews, unsupported warranty promises or automatic-subscription claims.

## v7 Theme Studio and analytics

The uploaded Linear DESIGN.md now supplies the editor's dark surface ladder, quiet hairlines, compact system-sans typography and scarce lavender action colour. The supplied Oura reference remains the default storefront language. Both relevant reference files are included with the original license.

The editor uses three working areas: page/section list, same-origin live page preview and a context inspector. Selection outlines use lavender. Dark chrome stays separate from the rendered storefront. Narrow screens stack panels without document overflow; data tables scroll within their containers. Every field has an explicit accessible label and mutations show draft/publish/error state.

The public section renderer shares semantic validated configuration across all 18 templates and custom pages. It keeps interactive commerce nodes intact, escapes text, restricts links and uploaded images, and applies presentation overrides without executing merchant-supplied HTML or scripts. Warm and midnight theme presets use the supplied reference palettes and platform font fallbacks.

Analytics follows the existing merchant workspace's restrained panels, a single green live indicator, daily bar chart and clear tables. Zero-view days are included, dates use Asia/Dhaka, and labels distinguish live browsers, total views and unique browser identities.
