# WebMart Theme Studio v7

An upgrade to the supplied WebMart v6 application, informed by the uploaded Tech Bazar editor and VoltAgent design documents. It preserves the storefront and merchant operations, adds an all-public-page visual editor, and records live presence plus page/product view history. Start with START-HERE-BN.md for Bengali instructions.

## Run

Node.js 24.14+ in the 24.x line is required. On Windows, double-click `START-WEBMART.cmd`; missing runtime dependencies are installed with npm.cmd. For a fresh merchant account use `SETUP-MERCHANT.cmd`. There are no default credentials. If upgrading, keep your existing private data and sign in with your existing account.

```sh
npm ci --omit=dev
npm run setup       # fresh installation only
npm start
```

Store: http://localhost:5000 · Merchant: /admin · Theme Studio: /admin/editor · Analytics: /admin/analytics. The app serves native browser modules; no frontend build step is required. `/api/health` reports `webmart-studio-7.0.0`.

## Upgrade from v6

Stop the old server and retain a complete backup. Extract this release separately. Copy the old `data` directory and all uploaded images into the matching locations in the new project, without replacing new code or carrying over node_modules. On first startup, the v6 database is backed up with SQLite `VACUUM INTO` under private `data/backups`, then editor configuration and analytics tables are added. Existing users, sessions, products, orders, store settings and legacy aggregate views are retained. Migration was tested against a copy of the actual supplied database without exposing its credentials. The delivery ZIP does not contain that database, its backups or any user credentials.

## Visual editor

The page selector covers 18 built-in templates: home, collection, website services, offers, saved pieces, watch details, rental details, shopping bag, checkout, login, registration, account, order/invoice, about, contact and three policies. New custom pages use `/page?name=your-handle` and can be linked from header navigation, extra footer links and CTAs.

Click static text, images, buttons or links in the same-origin authenticated preview to edit their text, destination, colour, size, image, alternative text, fit and visibility. Add hero, text, image, product collection, category links, feature cards, FAQ, gallery, CTA, announcement, spacer and divider sections to any page. Reorder, duplicate, hide or delete added sections. The homepage has five independently editable/reorderable built-in sections. Commerce page content remains a functional built-in section; its application logic, calculated prices, customer data and required forms are not arbitrary HTML blocks. Edit product data in Products and contact/payment/shipping configuration in Store settings.

Global controls cover colours, heading/body font stacks, button/card shape, content width, service/footer/announcement visibility, header menu and extra footer links. Oura warm and Linear midnight presets come from the supplied design documents. The editor chrome follows Linear's dark surface ladder; the default storefront keeps the Oura-inspired warm editorial identity. No proprietary fonts, external image services or remote font dependencies are required.

Drafts stay private. Publish saves pending edits and publishes all edited templates atomically. Version checks reject conflicting editor tabs. Undo/redo operates within the current editing session. More offers theme JSON export/import, discard and previous-publication restore. Import validates allowed fields, link protocols, colours, image paths and limits before previewing. Built-in templates and functional checkout/account cores cannot be removed from a saved theme. Preview interaction selects content instead of submitting orders or changing accounts.

Limits: 40 total page templates, 50 sections per page, 30 items per section, 20 navigation/footer links, 700 copy overrides per page, 5 MB per uploaded image, and the API's 250 KB request limit. Theme imports are limited to 220 KB. Custom code, arbitrary scripts and arbitrary HTML injection are not supported. Structural copy selectors are tied to this release's templates; reset affected page overrides if a future code update changes their structure.

## Analytics

Visible customer tabs send a 25-second heartbeat. Browsers active within 90 seconds count as live; hidden/closed tabs send a departure event, with expiry handling failed departure requests. One browser cookie is counted once across multiple tabs. Navigation/reload creates a page view; heartbeat, quantity changes and theme preview do not add views. Merchant sessions and known crawler user agents are excluded.

The merchant-only dashboard refreshes every 10 seconds and includes live browser count, active pages/products, total page views, unique browser identities, product-view ranking, device mix, daily history with zero-view dates, popular pages and CSV export. Dates use Asia/Dhaka. Reports accept 1–90 days; the UI offers 7, 30 and 90. Older aggregate views remain separately visible and cannot be retroactively assigned to products. Product analytics begins after upgrade.

A random HttpOnly same-site browser cookie provides pseudonymous identity; no raw IP, browser fingerprint or customer identity is stored in these analytics tables. Multiple devices, cleared cookies, blocked JavaScript, bots and disconnected browsers affect measurement. Counts describe recorded browser activity, not audited unique people. SQLite stores event history persistently; include it in backups.

## Existing functionality retained

The original 8 catalog products and referenced uploads; search/brand filters/sorting; saved items; product galleries/options; Basic/Advanced/Pro and Permanent service variants; cart; server-quoted checkout; delivery zones; coupons; COD and configured manual bKash/Nagad/Rocket; customer accounts; private guest order links; printable invoice; product CRUD and image uploads; order fulfilment/payment/tracking; registered customer list; categories; discounts; settings drafts; order export; optional merchant email/Telegram notifications; database backup and legacy import tooling.

Order stock and payment validation remain server-side. Subscription checkout records a service order; it does not automatically charge renewals, provision websites, enforce hosting quotas or transfer refunds. Manual mobile payments are verified by the merchant. Real payment settlement, SMTP/Telegram delivery and production cPanel hosting were not tested.

## Deployment

Use persistent Node 24 hosting with a writable private data directory and uploads folder. Set `NODE_ENV=production` and `PUBLIC_URL=https://your-real-domain` to the exact public origin. `HOST` defaults to 127.0.0.1 and `PORT` to 5000. Set these as required by the hosting reverse proxy; `TRUST_PROXY=1` is only for one trusted proxy. `DATA_DIR` and `UPLOAD_DIR` override storage paths; copy included uploads into a custom upload folder. Set environment variables through your host; this package does not load .env files. SQLite is for a persistent single-instance app, not a stateless edge deployment.

Optional notifications: TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID; or SMTP_HOST, SMTP_PORT, optional SMTP_USER/SMTP_PASS, EMAIL_FROM and ORDER_EMAIL. No values or passwords are shipped. Notification errors do not roll back an order. Keep real credentials out of Git.

Back up with `npm run backup` and back up uploads separately. To restore, stop the app, restore the matching wallet.sqlite and uploads, remove stale WAL/SHM files from the stopped installation if present, and restart. Never place private backups in public/uploads.

## Verification

```sh
npm ci
npm run check
npm test
npx playwright install chromium
npm run test:browser
npm run test:editor
```

Set BROWSER_EXECUTABLE to an installed Chromium binary if desired. BROWSER_ARTIFACTS selects a directory to retain screenshots and JSON results. Browser tests start isolated apps with generated credentials and disposable databases; they do not use your real account. TEST-REPORT.md records the actual results and practical limits.

## Reference files

DESIGN.md is the project design guide. references/OURA-DESIGN.md and references/LINEAR-DESIGN.md are the relevant documents from the supplied collection, with the VoltAgent MIT license. Product images are user-provided assets. No other source project's credentials, database, node_modules or historical patch layers are included.
