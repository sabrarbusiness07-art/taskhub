# WebMart Studio v7 — validation report

Validated on 10 November 2026 with Node 24.22.1, Playwright 1.62.1 and system Chromium.

- JavaScript syntax and seed asset checks: passed.
- Existing commerce/auth/settings API suite: 16 passed.
- New editor and analytics API suite: 11 passed.
- Existing browser regression suite: 58 checks passed.
- New visual-editor/analytics browser suite: 20 checks passed.
- Zero uncaught browser JavaScript exceptions in either browser suite.

## New API coverage

Migration/defaults; all 18 page templates; merchant/CSRF restrictions and private draft preview; adding sections across all page templates; private drafts; atomic publication and stale-version rejection; custom pages; safe copy overrides; unsafe-link/selector/image rejection; functional-core preservation; restore/discard; analytics event deduplication; heartbeat behavior; shared browser identity across tabs; hidden/expired presence; product ranking and distinct browser counts; Asia/Dhaka daily buckets; admin exclusion; date range checks; protected reports; CSV export.

## New browser coverage

Five homepage core sections retained; authenticated embedded preview; direct selection and editing of homepage and collection copy; private unsaved drafts; FAQ add/item edit/reorder/duplicate/delete/hide/show; save and public publication; custom page creation/routing; all 18 template previews, including checkout/auth/invoice; warm and midnight presets; mobile/desktop preview; image upload/alternative text; adding a published header link; theme JSON export; previous-publication restore; real guest product-view recording; no view inflation from cart actions; analytics date filtering/product ranking/daily history; no full-page horizontal overflow for editor and analytics at 320, 390 and 768px.

The existing suite additionally checks real COD checkout and private guest confirmation access, customer registration/logout, product create/edit/remove, settings drafts, coupons, order status updates, mobile navigation and storefront/merchant layouts at desktop, 320, 390 and 768px. API tests cover transactional stock, checkout idempotency, last-item concurrency, payment-reference verification, stock restoration and role/CSRF/origin enforcement.

## Actual supplied database upgrade

A separate copy of the uploaded v6 database was upgraded. Hash comparisons confirmed that product records, orders, merchant account/credential records, sessions, published store settings and prior aggregate view rows stayed unchanged. The pre-upgrade SQLite backup was created and verified. That private data and its backup are excluded from the delivered ZIP and GitHub upload.

## Scope

No live production service was deployed or charged. Actual cPanel hosting, Windows double-click execution, SMTP/Telegram transport, mobile-money settlement and subscription provisioning were not tested in this Linux environment. Windows launchers use cmd-compatible commands and npm.cmd to avoid the previously observed PowerShell npm.ps1 restriction. The final package requires Node 24 and npm installation; node_modules is intentionally excluded.

Browser activity is measured with a pseudonymous cookie and JavaScript heartbeat. It is not audited unique-person measurement. Earlier aggregate-only statistics cannot be reconstructed into historical product views. Templates edit presentation and safe content; prices/stock/product details are managed through Products, while orders, required checkout fields and payment calculations retain application behavior.
