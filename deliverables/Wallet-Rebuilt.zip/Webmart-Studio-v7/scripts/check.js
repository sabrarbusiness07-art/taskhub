'use strict';
const fs=require('node:fs');const path=require('node:path');const {spawnSync}=require('node:child_process');
const root=path.join(__dirname,'..');let failures=0;
function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){if(['node_modules','data','backups'].includes(entry.name))continue;const p=path.join(dir,entry.name);if(entry.isDirectory())walk(p);else if(/\.(?:c|m)?js$/.test(p)){const result=spawnSync(process.execPath,['--check',p],{encoding:'utf8'});if(result.status){console.error(result.stderr);failures++;}}}}
walk(root);const seed=JSON.parse(fs.readFileSync(path.join(root,'seed.json'),'utf8'));for(const p of seed.products){for(const url of [p.image,...p.images])if(url&&!fs.existsSync(path.join(root,'public',url))) {console.error('Missing asset:',url);failures++;}}
console.log(failures?`${failures} checks failed`:'JavaScript syntax and seed asset checks passed.');process.exitCode=failures?1:0;
