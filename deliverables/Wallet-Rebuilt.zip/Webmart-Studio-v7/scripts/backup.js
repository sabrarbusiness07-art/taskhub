'use strict';
const path=require('node:path');const fs=require('node:fs');const {openStore}=require('../lib/store');
const dataDir=process.env.DATA_DIR||path.join(__dirname,'..','data');const store=openStore(dataDir);
try{const dir=path.resolve(process.argv[2]||path.join(__dirname,'..','backups'));fs.mkdirSync(dir,{recursive:true,mode:0o700});const target=path.join(dir,'wallet-'+new Date().toISOString().replace(/[:.]/g,'-')+'.sqlite');store.db.prepare('VACUUM INTO ?').run(target);console.log('Consistent database backup saved:',target);console.log('Also back up public/uploads (or your configured UPLOAD_DIR) separately.');}finally{store.close();}
