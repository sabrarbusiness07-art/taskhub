@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js 24 LTS first, then run this file again.
 pause
 exit /b 1
)
node -e "if(process.versions.node.split('.')[0]!=='24')process.exit(1)"
if errorlevel 1 (
 echo This project requires Node.js 24.x.
 pause
 exit /b 1
)
node -e "try{require('express');require('multer');require('nodemailer')}catch(e){process.exit(1)}"
if errorlevel 1 goto install
goto run
:install
call npm.cmd ci --omit=dev
if errorlevel 1 (
 echo Dependency installation failed. Check your internet connection and the error above.
 pause
 exit /b 1
)
:run
echo WebMart: http://localhost:5000
echo Merchant workspace: http://localhost:5000/admin
echo Keep this window open while using your local store.
node server.js
pause
