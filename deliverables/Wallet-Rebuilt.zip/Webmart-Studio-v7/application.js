'use strict';
const express = require('express');
const multer = require('multer');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { openStore, digest, passwordHash, passwordMatches } = require('./lib/store');
const v = require('./lib/validation');
const { notify } = require('./lib/notifications');
function createApp(options = {}) {
  const dataDir = options.dataDir || process.env.DATA_DIR || path.join(__dirname, 'data');
  const uploadDir = options.uploadDir || process.env.UPLOAD_DIR || path.join(__dirname, 'public', 'uploads');
  fs.mkdirSync(uploadDir, { recursive: true });
  const store = openStore(dataDir), app = express();
  const origin = new URL(options.origin || process.env.PUBLIC_URL || 'http://localhost:' + (process.env.PORT || 5000)).origin;
  const secure = origin.startsWith('https:');
  if (process.env.NODE_ENV === 'production' && !secure) throw Error('Set PUBLIC_URL to your HTTPS production URL');
  app.disable('x-powered-by');
  if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);
  app.use((req, res, next) => {
    res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'same-origin', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; frame-ancestors 'self'; base-uri 'none'; form-action 'self'" });
    if (secure) res.set('Strict-Transport-Security', 'max-age=31536000');
    if (req.path.startsWith('/api/')) {
      res.set('Cache-Control', 'no-store');
      if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && req.get('origin') !== origin) return res.status(403).json({ error: 'Open the configured store URL before making changes.' });
    }
    next();
  });
  app.use(express.json({ limit: '250kb' }));
  app.use('/api', (req, res, next) => { if (req.body === undefined) req.body = {}; next(); });
  const buckets = new Map();
  const limit = (name, max) => (req, res, next) => {
    const now = Date.now(); for (const [key, value] of buckets) if (value.until < now) buckets.delete(key);
    if (buckets.size > 10000) return res.status(503).json({ error: 'Please try again shortly.' });
    const key = name + ':' + req.ip, entry = buckets.get(key) || { n: 0, until: now + 900000 }; buckets.set(key, entry);
    if (++entry.n > max) return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' }); next();
  };
  function session(req) {
    const token = (req.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith('wm_session='))?.slice(11);
    if (!token) return null;
    return store.db.prepare('SELECT s.*, u.id, u.email, u.name, u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?').get(digest(token), Date.now());
  }
  const auth = (req, res, next) => {
    req.user = session(req); if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
    if (!['GET', 'HEAD'].includes(req.method) && req.get('x-csrf-token') !== req.user.csrf) return res.status(403).json({ error: 'Session expired. Reload and try again.' }); next();
  };
  const admin = [auth, (req, res, next) => req.user.role === 'admin' ? next() : res.status(403).json({ error: 'Merchant access required.' })];
  require('./lib/site-editor').attach({ app, store, admin, session });
  const analytics = require('./lib/analytics').attach({ app, store, admin, session, limit, secure, now: options.analyticsNow || Date.now });
  function startSession(res, user) {
    const token = crypto.randomBytes(32).toString('hex'), csrf = crypto.randomBytes(24).toString('hex');
    store.db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
    store.db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(digest(token), user.id, csrf, Date.now() + 8 * 3600000);
    res.cookie('wm_session', token, { httpOnly: true, sameSite: 'strict', secure, path: '/', maxAge: 8 * 3600000 });
    return { user: { id: user.id, email: user.email, name: user.name, role: user.role }, csrf };
  }
  app.get('/api/health', (req, res) => res.json({ ok: true, release: 'webmart-studio-7.0.0' }));
  app.get('/api/session', (req, res) => { const user = session(req); res.json(user ? { user: { id: user.id, name: user.name, email: user.email, role: user.role }, csrf: user.csrf } : { user: null, csrf: '' }); });
  app.post('/api/auth/register', limit('auth', 20), async (req, res) => {
    const name = v.text(req.body.name, 'name', 100), email = v.email(req.body.email), password = v.text(req.body.password, 'password', 200);
    if (password.length < 10) v.fail('Use at least 10 characters for your password');
    if (store.db.prepare('SELECT id FROM users WHERE email=?').get(email)) v.fail('This email is already registered.', 409);
    const credentials = await passwordHash(password), user = { id: crypto.randomUUID(), name, email, role: 'customer', ...credentials };
    try { store.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run(user.id, email, name, 'customer', credentials.salt, credentials.hash); }
    catch (error) { if (error.code?.includes('CONSTRAINT')) v.fail('This email is already registered.', 409); throw error; }
    res.status(201).json(startSession(res, user));
  });
  app.post('/api/auth/login', limit('auth', 20), async (req, res) => {
    const email = v.email(req.body.email), password = v.text(req.body.password, 'password', 200);
    const user = store.db.prepare('SELECT * FROM users WHERE email=?').get(email);
    if (!await passwordMatches(password, user)) v.fail('Incorrect email or password.', 401);
    res.json(startSession(res, user));
  });
  app.post('/api/auth/logout', auth, (req, res) => { store.db.prepare('DELETE FROM sessions WHERE token=?').run(req.user.token); res.clearCookie('wm_session', { path: '/', secure, sameSite: 'strict' }); res.json({ ok: true }); });
  const publicProduct = p => { const { details, ...rest } = p; return { ...rest, details: { sku: details?.sku || '' } }; };
  app.get('/api/store', (req, res) => { const preview = req.query.editorPreview === '1'; if (preview && session(req)?.role !== 'admin') return res.status(403).json({ error: 'Merchant access required for draft preview' }); res.json({ settings: store.get('config', 'settings'), siteTheme: store.get('config', preview ? 'site-draft' : 'site-live'), categories: store.get('config', 'categories'), products: store.all('products').filter(p => p.active && !p.deleted).map(publicProduct) }); });
  app.get('/api/products/:id', (req, res) => { const p = store.get('products', req.params.id); if (!p?.active || p.deleted) v.fail('Product not found', 404); res.json(publicProduct(p)); });
  const rental = p => ['basic', 'advanced', 'pro'].every(name => p.variants.some(x => x.color.toLowerCase() === name));
  function quote(body) {
    if (!Array.isArray(body.items) || !body.items.length || body.items.length > 50) v.fail('Your bag must contain 1–50 items');
    const requested = new Map();
    for (const item of body.items) {
      const productId = v.text(item.productId, 'product ID', 80), variantId = v.text(item.variantId, 'variant ID', 80), quantity = v.integer(item.quantity, 'quantity', 20);
      if (!quantity) v.fail('Quantity must be positive');
      const key = productId + ':' + variantId, existing = requested.get(key);
      const totalQuantity = (existing?.quantity || 0) + quantity; if (totalQuantity > 20) v.fail('Maximum 20 of each option');
      requested.set(key, { productId, variantId, quantity: totalQuantity });
    }
    const items = [...requested.values()].map(item => {
      const p = store.get('products', item.productId), variant = p?.variants.find(x => x.id === item.variantId);
      if (!p?.active || p.deleted || !variant) v.fail('A product in your bag is no longer available.', 409);
      if (rental(p) && item.quantity !== 1) v.fail('Choose one subscription or permanent plan per order');
      if (variant.stock < item.quantity) v.fail('Not enough stock for ' + p.name, 409);
      return { ...item, name: p.name, image: p.image, color: variant.color, size: variant.size, price: variant.price, lineTotal: variant.price * item.quantity, rental: rental(p) };
    });
    const subtotal = items.reduce((sum, x) => sum + x.lineTotal, 0), zone = body.zone || 'inside';
    if (!['inside', 'outside'].includes(zone)) v.fail('Choose a delivery zone');
    const settings = store.get('config', 'settings');
    const shipping = items.every(i => i.rental) ? 0 : settings[zone === 'inside' ? 'insideShipping' : 'outsideShipping'];
    const code = v.text(body.couponCode || '', 'coupon', 40, false).toUpperCase(); let discount = 0;
    if (code) {
      const coupon = store.get('config', 'coupons').find(x => x.code === code);
      if (!coupon?.active || (coupon.expires && coupon.expires < new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka', year: 'numeric', month: '2-digit', day: '2-digit' }).format(Date.now())) || (coupon.maxUses && coupon.used >= coupon.maxUses) || subtotal < coupon.minSpend) v.fail('This coupon is invalid, expired or does not apply to your bag');
      discount = Math.min(subtotal, coupon.type === 'percent' ? Math.round(subtotal * coupon.value / 100) : coupon.value);
    }
    return { items, subtotal, shipping, discount, couponCode: code, zone, total: subtotal + shipping - discount };
  }
  app.post('/api/quote', limit('quote', 500), (req, res) => res.json(quote(req.body)));
  app.post('/api/orders', limit('checkout', 30), (req, res) => {
    const body = req.body, key = v.text(body.idempotencyKey, 'checkout key', 80);
    if (!/^[\w-]{16,80}$/.test(key)) v.fail('Invalid checkout key');
    const fingerprint = digest(JSON.stringify({ items: body.items, customer: body.customer, zone: body.zone, paymentMethod: body.paymentMethod, trxId: body.trxId, expectedTotal: body.expectedTotal, couponCode: body.couponCode || '', notes: body.notes || '' }));
    const prior = store.db.prepare('SELECT * FROM requests WHERE id=?').get(key);
    if (prior) {
      if (prior.fingerprint !== fingerprint) v.fail('Your checkout changed. Start a new checkout.', 409);
      const order = store.get('orders', prior.order_id); return res.status(200).json({ id: order.id, number: order.number, accessKey: prior.access_key });
    }
    const customer = { name: v.text(body.customer?.name, 'full name', 100), phone: v.text(body.customer?.phone, 'mobile number', 20).replace(/^\+880/, '0'), address: v.text(body.customer?.address, 'delivery address', 500), district: v.text(body.customer?.district, 'district', 80), email: body.customer?.email ? v.email(body.customer.email) : '' };
    if (!/^01[3-9]\d{8}$/.test(customer.phone)) v.fail('Enter a valid Bangladesh mobile number');
    const method = body.paymentMethod; if (!['cod', 'bkash', 'nagad', 'rocket'].includes(method)) v.fail('Choose a payment method');
    if (method !== 'cod' && !store.get('config', 'settings').manual[method]) v.fail('This payment method is not enabled');
    const trxId = method === 'cod' ? '' : v.text(body.trxId, 'transaction ID', 80).toUpperCase();
    if (trxId && !/^[A-Z0-9-]{5,80}$/.test(trxId)) v.fail('Invalid transaction ID');
    const notes = v.text(body.notes || '', 'order notes', 1000, false), user = session(req);
    const accessKey = crypto.randomBytes(32).toString('hex');
    const order = store.tx(() => {
      const q = quote(body); if (q.total !== v.integer(body.expectedTotal, 'expected total')) v.fail('Prices changed. Review your updated order total.', 409);
      for (const item of q.items) { const p = store.get('products', item.productId); p.variants.find(x => x.id === item.variantId).stock -= item.quantity; p.version++; store.put('products', p.id, p); }
      const id = crypto.randomUUID(), now = new Date().toISOString();
      const o = { ...q, id, number: 'WM-' + id.slice(0, 8).toUpperCase(), customerId: user?.id || '', customer, notes, status: 'Pending', payment: { method, trxId, status: method === 'cod' ? 'unpaid' : 'pending_verification' }, accessHash: digest(accessKey), createdAt: now, updatedAt: now, stockReleased: false, courier: { provider: '', tracking: '' } };
      if (q.couponCode) { const coupons = store.get('config', 'coupons'); coupons.find(x => x.code === q.couponCode).used++; store.put('config', 'coupons', coupons); }
      store.put('orders', id, o); store.db.prepare('INSERT INTO requests VALUES(?,?,?,?)').run(key, fingerprint, id, accessKey); store.audit('order.create', id); return o;
    });
    void notify(order); res.status(201).json({ id: order.id, number: order.number, accessKey });
  });
  app.get('/api/orders/:id', (req, res) => {
    const order = store.get('orders', req.params.id); if (!order) v.fail('Order not found', 404);
    const user = session(req), key = req.get('x-order-key') || '';
    if (!(user?.role === 'admin' || (user && order.customerId === user.id) || (order.accessHash && digest(key) === order.accessHash))) v.fail('Sign in or use your order confirmation link.', 403);
    const { accessHash, ...publicOrder } = order; res.json(publicOrder);
  });
  app.get('/api/account/orders', auth, (req, res) => res.json(store.all('orders').filter(o => o.customerId === req.user.id).map(({ accessHash, ...o }) => o)));
  app.post('/api/visits', limit('visits', 1000), (req, res) => {
    const page = v.text(req.body.path, 'page path', 150); if (!/^\/[a-z0-9/_-]*$/i.test(page)) v.fail('Invalid page path');
    const day = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka', year: 'numeric', month: '2-digit', day: '2-digit' }).format(Date.now());
    store.db.prepare('INSERT INTO visits VALUES(?,?,1) ON CONFLICT(day,path) DO UPDATE SET count=count+1').run(day, page); res.json({ ok: true });
  });
  app.get('/api/admin/overview', ...admin, (req, res) => {
    const orders = store.all('orders'), products = store.all('products').filter(x => !x.deleted);
    const revenue = orders.filter(x => x.payment.status === 'paid').reduce((n, x) => n + x.total, 0);
    const statuses = orders.reduce((acc, x) => (acc[x.status] = (acc[x.status] || 0) + 1, acc), {});
    const visits = store.db.prepare('SELECT day, SUM(count) AS count FROM visits GROUP BY day ORDER BY day DESC LIMIT 14').all().reverse();
    res.json({ liveViewers: analytics.report(1).live, revenue, orderCount: orders.length, productCount: products.length, customerCount: store.db.prepare("SELECT count(*) AS n FROM users WHERE role='customer'").get().n, statuses, visits, recent: orders.slice(0, 5), lowStock: products.filter(p => p.active && p.variants.some(v => v.stock < 5)) });
  });
  app.get('/api/admin/products', ...admin, (req, res) => res.json(store.all('products').filter(x => !x.deleted)));
  app.post('/api/admin/products', ...admin, (req, res) => { const p = v.product(req.body); store.put('products', p.id, p); store.audit('product.create', p.id); res.status(201).json(p); });
  app.put('/api/admin/products/:id', ...admin, (req, res) => {
    const old = store.get('products', req.params.id); if (!old || old.deleted) v.fail('Product not found', 404);
    if (req.body.version !== old.version) v.fail('This product changed in another tab or order. Reload before editing.', 409);
    const p = v.product(req.body, old); store.put('products', p.id, p); store.audit('product.update', p.id); res.json(p);
  });
  app.delete('/api/admin/products/:id', ...admin, (req, res) => { const p = store.get('products', req.params.id); if (!p) v.fail('Product not found', 404); p.active = false; p.deleted = true; p.version++; store.put('products', p.id, p); store.audit('product.delete', p.id); res.json({ ok: true }); });
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 0 } });
  app.post('/api/admin/uploads', ...admin, upload.single('image'), (req, res) => {
    const buffer = req.file?.buffer; if (!buffer) v.fail('Choose an image'); let ext;
    if (buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) ext = '.png';
    else if (buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255) ext = '.jpg';
    else if (buffer.subarray(0, 4).toString() === 'RIFF' && buffer.subarray(8, 12).toString() === 'WEBP') ext = '.webp';
    else v.fail('Only PNG, JPEG and WebP images are allowed');
    const name = crypto.randomUUID() + ext; fs.writeFileSync(path.join(uploadDir, name), buffer, { flag: 'wx' }); res.status(201).json({ image: '/uploads/' + name });
  });
  app.get('/api/admin/orders', ...admin, (req, res) => res.json(store.all('orders').map(({ accessHash, ...o }) => o)));
  app.patch('/api/admin/orders/:id', ...admin, (req, res) => {
    const order = store.tx(() => {
      const o = store.get('orders', req.params.id); if (!o) v.fail('Order not found', 404);
      if (req.body.updatedAt !== o.updatedAt) v.fail('This order changed. Reload before updating.', 409);
      const transitions = { Pending: ['Confirmed', 'Processing', 'Cancelled'], Confirmed: ['Processing', 'Cancelled'], Processing: ['Shipped', 'Delivered', 'Cancelled'], Shipped: ['Delivered', 'Returned'], Delivered: ['Returned'], Cancelled: [], Returned: [] };
      const target = req.body.status || o.status;
      if (target !== o.status && !transitions[o.status]?.includes(target)) v.fail('Invalid order status transition');
      if (['Cancelled', 'Returned'].includes(target) && !o.stockReleased) {
        for (const item of o.items) { const p = store.get('products', item.productId), variant = p?.variants.find(x => x.id === item.variantId); if (variant) { variant.stock += item.quantity; p.version++; store.put('products', p.id, p); } } o.stockReleased = true;
      }
      o.status = target;
      const payment = req.body.paymentStatus || o.payment.status;
      if (payment !== o.payment.status) {
        if (payment === 'paid') {
          if (!['unpaid', 'pending_verification'].includes(o.payment.status) || ['Cancelled', 'Returned'].includes(o.status)) v.fail('Cannot collect payment for this order');
          if (o.payment.method === 'cod' && o.status !== 'Delivered') v.fail('Mark COD orders delivered before collecting payment');
          if (o.payment.method !== 'cod') { const reference = o.payment.method + ':' + o.payment.trxId; const existing = store.db.prepare('SELECT order_id FROM payments WHERE reference=?').get(reference); if (existing && existing.order_id !== o.id) v.fail('This payment transaction has already been used', 409); store.db.prepare('INSERT OR IGNORE INTO payments VALUES(?,?)').run(reference, o.id); }
          o.payment.paidAt = new Date().toISOString();
        } else if (payment === 'refunded') { if (o.payment.status !== 'paid' || !['Cancelled', 'Returned'].includes(o.status)) v.fail('Return or cancel a paid order before refunding'); }
        else v.fail('Invalid payment transition'); o.payment.status = payment;
      }
      o.courier = { provider: v.text(req.body.courier?.provider || '', 'courier', 80, false), tracking: v.text(req.body.courier?.tracking || '', 'tracking reference', 150, false) };
      o.updatedAt = new Date(Math.max(Date.now(), Date.parse(o.updatedAt || 0) + 1)).toISOString(); store.put('orders', o.id, o); store.audit('order.update', o.id); return o;
    }); res.json(order);
  });
  app.get('/api/admin/customers', ...admin, (req, res) => res.json(store.db.prepare("SELECT id,name,email FROM users WHERE role='customer' ORDER BY rowid DESC").all().map(user => ({ ...user, orders: store.all('orders').filter(o => o.customerId === user.id).length }))));
  app.get('/api/admin/categories', ...admin, (req, res) => res.json(store.get('config', 'categories')));
  app.put('/api/admin/categories', ...admin, (req, res) => {
    if (!Array.isArray(req.body.items) || req.body.items.length > 100) v.fail('Maximum 100 categories');
    const names = new Set(); const items = req.body.items.map(c => { const name = v.text(c.name, 'category', 80), key = name.toLowerCase(); if (names.has(key)) v.fail('Duplicate category'); names.add(key); return { id: c.id ? v.text(c.id, 'category ID', 80) : crypto.randomUUID(), name, parent: '' }; });
    store.put('config', 'categories', items); store.audit('categories.update', 'store'); res.json(items);
  });
  app.get('/api/admin/theme', ...admin, (req, res) => res.json(store.get('config', 'draft')));
  app.put('/api/admin/theme', ...admin, (req, res) => {
    const old = store.get('config', 'draft'); if (req.body.version !== old.version) v.fail('Draft changed. Reload before saving.', 409);
    const s = { ...v.settings(req.body, old), version: old.version + 1 }; store.put('config', 'draft', s); store.audit('theme.draft', s.version); res.json(s);
  });
  app.post('/api/admin/theme/publish', ...admin, (req, res) => {
    const draft = store.get('config', 'draft'); if (req.body.version !== draft.version) v.fail('Draft changed. Reload before publishing.', 409);
    store.put('config', 'previous', store.get('config', 'settings')); store.put('config', 'settings', draft); store.audit('theme.publish', draft.version); res.json(draft);
  });
  app.post('/api/admin/theme/rollback', ...admin, (req, res) => {
    const previous = store.get('config', 'previous'); if (!previous) v.fail('No previous published theme is available');
    const current = store.get('config', 'settings'), restored = { ...previous, version: Math.max(current.version, store.get('config', 'draft').version) + 1 };
    store.put('config', 'previous', current); store.put('config', 'settings', restored); store.put('config', 'draft', restored); store.audit('theme.rollback', restored.version); res.json(restored);
  });
  app.get('/api/admin/coupons', ...admin, (req, res) => res.json(store.get('config', 'coupons')));
  app.put('/api/admin/coupons', ...admin, (req, res) => {
    if (!Array.isArray(req.body.items) || req.body.items.length > 100) v.fail('Maximum 100 coupons');
    const previous = store.get('config', 'coupons'), codes = new Set();
    const items = req.body.items.map(c => {
      const code = v.text(c.code, 'coupon code', 40).toUpperCase(); if (!/^[A-Z0-9_-]{2,40}$/.test(code) || codes.has(code)) v.fail('Use unique coupon codes with letters, numbers, hyphens or underscores'); codes.add(code);
      if (!['percent', 'fixed'].includes(c.type)) v.fail('Invalid discount type');
      const value = v.integer(c.value, 'discount', c.type === 'percent' ? 100 : 100000000); if (!value) v.fail('Discount must be positive');
      const expires = c.expires || ''; if (expires && (!/^\d{4}-\d{2}-\d{2}$/.test(expires) || !Number.isFinite(Date.parse(expires)))) v.fail('Invalid expiry date');
      return { code, type: c.type, value, minSpend: v.integer(c.minSpend || 0, 'minimum spend'), maxUses: v.integer(c.maxUses || 0, 'usage limit'), used: previous.find(x => x.code === code)?.used || 0, active: c.active === true, expires };
    }); store.put('config', 'coupons', items); store.audit('coupons.update', 'store'); res.json(items);
  });
  app.get('/api/admin/export', ...admin, (req, res) => { res.attachment('webmart-orders.json').json(store.all('orders').map(({ accessHash, ...o }) => o)); });
  app.use('/uploads', express.static(uploadDir, { dotfiles: 'deny', index: false, maxAge: '7d' }));
  app.use(express.static(path.join(__dirname, 'public'), { index: false, dotfiles: 'deny', maxAge: 0 }));
  const legacy = { '/index.html': '/', '/collection.html': '/shop', '/product.html': '/product', '/cart.html': '/cart', '/checkout.html': '/checkout', '/account.html': '/account', '/my-orders.html': '/account', '/login.html': '/account', '/admin.html': '/admin', '/admin-products.html': '/admin/products', '/theme-editor.html': '/admin/editor', '/admin-suite.html': '/admin', '/categories.html': '/admin/categories', '/offers.html': '/offers', '/visitor-report.html': '/admin', '/invoice.html': '/order' };
  for (const [from, to] of Object.entries(legacy)) app.get(from, (req, res) => res.redirect(302, to + (req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '')));
  app.use('/api', (req, res) => res.status(404).json({ error: 'API endpoint not found' }));
  app.get(['/', '/shop', '/product', '/cart', '/checkout', '/account', '/saved', '/offers', '/order', '/page', '/admin', '/admin/products', '/admin/orders', '/admin/customers', '/admin/categories', '/admin/theme', '/admin/coupons', '/admin/editor', '/admin/analytics'], (req, res) => { res.set('Cache-Control', 'no-store'); res.sendFile(path.join(__dirname, 'public', 'index.html')); });
  app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', '404.html')));
  app.use((error, req, res, next) => { const status = error.code === 'LIMIT_FILE_SIZE' ? 413 : error instanceof multer.MulterError ? 400 : error.status || 500; if (status === 500) console.error(error); res.status(status).json({ error: status === 500 ? 'Unexpected server error. Please try again.' : error.code === 'LIMIT_FILE_SIZE' ? 'Image must be smaller than 5 MB' : error.message }); });
  return { app, store };
}
module.exports = { createApp };
