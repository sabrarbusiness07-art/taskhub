'use strict';
const {test,before,after}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const crypto=require('node:crypto');
const {createApp}=require('../application');const {passwordHash}=require('../lib/store');
let app,store,server,root,base,admin,customer;
const origin='http://localhost:5000';
const merchantPassword=crypto.randomBytes(24).toString('hex'),buyerPassword=crypto.randomBytes(24).toString('hex');
async function request(url,method='GET',body,session,headers={}){
 const r=await fetch(base+url,{method,headers:{Origin:origin,...(body?{'Content-Type':'application/json'}:{}),...(session?{Cookie:session.cookie,'X-CSRF-Token':session.csrf}:{}),...headers},body:body?JSON.stringify(body):undefined});
 const data=r.headers.get('content-type')?.includes('application/json')?await r.json():await r.text();return{status:r.status,data,headers:r.headers};
}
async function login(email,password){const r=await request('/api/auth/login','POST',{email,password});assert.equal(r.status,200,JSON.stringify(r.data));return{...r.data,cookie:r.headers.get('set-cookie').split(';')[0]};}
function cartBody(p,extra={}){return{items:[{productId:p.id,variantId:p.variants[0].id,quantity:1}],zone:'inside',...extra};}
async function place(p,extra={},user){const b=cartBody(p,extra),q=await request('/api/quote','POST',b);assert.equal(q.status,200);return request('/api/orders','POST',{...b,customer:{name:'Test Customer',phone:'01712345678',address:'Test Road 1',district:'Dhaka',email:'buyer@example.test'},paymentMethod:'cod',idempotencyKey:crypto.randomUUID(),expectedTotal:q.data.total,...extra},user);}
function product(){return store.all('products').find(p=>p.category==='Titan');}
before(async()=>{
 root=fs.mkdtempSync(path.join(os.tmpdir(),'wallet-api-'));({app,store}=createApp({dataDir:path.join(root,'data'),uploadDir:path.join(root,'uploads'),origin}));
 const h=await passwordHash(merchantPassword);store.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run('admin','merchant@example.test','Merchant','admin',h.salt,h.hash);
 server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));base='http://127.0.0.1:'+server.address().port;admin=await login('merchant@example.test',merchantPassword);
 const r=await request('/api/auth/register','POST',{name:'Buyer',email:'buyer@example.test',password:buyerPassword});assert.equal(r.status,201);customer={...r.data,cookie:r.headers.get('set-cookie').split(';')[0]};
});
after(async()=>{await new Promise(r=>server.close(r));store.close();fs.rmSync(root,{recursive:true,force:true});});
test('all public routes, browser modules, stylesheet and missing paths return correctly',async()=>{
 for(const url of ['/','/shop','/product','/cart','/checkout','/account','/saved','/offers','/page','/order','/admin','/admin/products','/admin/theme','/app.mjs','/admin.mjs','/styles.css']){const r=await request(url);assert.equal(r.status,200,url);assert.ok(r.headers.get('content-security-policy'));}
 assert.equal((await request('/missing-page')).status,404);assert.equal((await request('/api/missing')).status,404);
});
test('catalog imports all eight products and exposes no private product cost or credentials',async()=>{
 const r=await request('/api/store');assert.equal(r.status,200);assert.equal(r.data.products.length,8);assert.ok(r.data.products.every(p=>!('cost'in p.details)));assert.ok(!JSON.stringify(r.data).includes('hash'));assert.ok(!r.data.products.some(p=>p.name.startsWith('Thumbnail')));
});
test('admin requires session, admin role, CSRF and configured origin',async()=>{
 assert.equal((await request('/api/admin/products')).status,401);assert.equal((await request('/api/admin/products','GET',undefined,customer)).status,403);
 const b=store.get('config','draft');assert.equal((await request('/api/admin/theme','PUT',b,{...admin,csrf:'bad'})).status,403);assert.equal((await request('/api/admin/theme','PUT',b,admin,{Origin:'https://other.test'})).status,403);
 assert.equal((await request('/api/auth/login','POST',{email:'merchant@example.test',password:'wrong'})).status,401);
});
test('registration cannot elevate a role; duplicate and short-password inputs are rejected',async()=>{
 assert.equal(customer.user.role,'customer');const duplicate=await request('/api/auth/register','POST',{name:'Buyer',email:'buyer@example.test',password:buyerPassword,role:'admin'});assert.equal(duplicate.status,409);
 assert.equal((await request('/api/auth/register','POST',{name:'Other',email:'other@example.test',password:'short'})).status,400);
});
test('product CRUD validates variants, price, version conflicts and safe image paths',async()=>{
 const p={name:'Test watch',category:'Test',description:'Details',image:'',images:[],active:true,variants:[{color:'Black',size:'40 mm',price:10000,compareAt:12000,stock:3}]};
 let r=await request('/api/admin/products','POST',p,admin);assert.equal(r.status,201);const created=r.data;
 r=await request('/api/admin/products/'+created.id,'PUT',{...created,name:'Edited watch'},admin);assert.equal(r.status,200);assert.equal(r.data.name,'Edited watch');
 assert.equal((await request('/api/admin/products/'+created.id,'PUT',created,admin)).status,409);
 assert.equal((await request('/api/admin/products','POST',{...p,image:'javascript:alert(1)'},admin)).status,400);
 assert.equal((await request('/api/admin/products','POST',{...p,variants:[{...p.variants[0],price:0}]},admin)).status,400);
 assert.equal((await request('/api/admin/products','POST',{...p,variants:[p.variants[0],p.variants[0]]},admin)).status,400);
 assert.equal((await request('/api/admin/products/'+created.id,'DELETE',undefined,admin)).status,200);assert.equal((await request('/api/products/'+created.id)).status,404);
});
test('quotes use server prices, aggregate quantities and reject stock overages',async()=>{
 const p=product(),body=cartBody(p);let r=await request('/api/quote','POST',body);assert.equal(r.status,200);assert.equal(r.data.subtotal,p.variants[0].price);assert.equal(r.data.shipping,6000);
 assert.equal((await request('/api/quote','POST',{...body,items:[{...body.items[0],quantity:20}]})).status,409);
 r=await request('/api/orders','POST',{...body,customer:{name:'Buyer',phone:'01712345678',address:'Road',district:'Dhaka'},paymentMethod:'cod',idempotencyKey:crypto.randomUUID(),expectedTotal:1});assert.equal(r.status,409);assert.equal(product().variants[0].stock,p.variants[0].stock);
});
test('monthly and permanent service variants have zero shipping and quantity fixed to one',async()=>{
 const p=store.all('products').find(p=>p.category==='Tech');for(const variant of p.variants){const r=await request('/api/quote','POST',{items:[{productId:p.id,variantId:variant.id,quantity:1}],zone:'outside'});assert.equal(r.status,200);assert.equal(r.data.shipping,0);assert.equal(r.data.total,variant.price);}
 assert.equal((await request('/api/quote','POST',cartBody(p,{items:[{productId:p.id,variantId:p.variants[0].id,quantity:2}]}))).status,400);
});
test('checkout idempotency, account ownership, order access and stock updates work together',async()=>{
 const p=product(),body={...cartBody(p),customer:{name:'Test Buyer',phone:'01712345678',address:'Road 4',district:'Dhaka'},paymentMethod:'cod',idempotencyKey:crypto.randomUUID(),expectedTotal:p.variants[0].price+6000};
 const a=await request('/api/orders','POST',body,customer);assert.equal(a.status,201);const b=await request('/api/orders','POST',body,customer);assert.equal(b.status,200);assert.equal(a.data.id,b.data.id);assert.equal(a.data.accessKey,b.data.accessKey);assert.equal(product().variants[0].stock,p.variants[0].stock-1);
 assert.equal((await request('/api/orders','POST',{...body,notes:'changed'},customer)).status,409);
 assert.equal((await request('/api/orders/'+a.data.id)).status,403);assert.equal((await request('/api/orders/'+a.data.id,'GET',undefined,undefined,{'X-Order-Key':a.data.accessKey})).status,200);assert.equal((await request('/api/orders/'+a.data.id,'GET',undefined,customer)).status,200);assert.ok((await request('/api/account/orders','GET',undefined,customer)).data.some(o=>o.id===a.data.id));
});
test('last item cannot be oversold by concurrent checkouts',async()=>{
 const p=product(),old=p.variants[0].stock;p.variants[0].stock=1;store.put('products',p.id,p);
 const results=await Promise.all([place(p),place(p)]);assert.deepEqual(results.map(x=>x.status).sort(),[201,409]);assert.equal(product().variants[0].stock,0);p.variants[0].stock=old;store.put('products',p.id,p);
});
test('cancel restores stock exactly once and stale order updates are rejected',async()=>{
 const p=product(),r=await place(p),id=r.data.id;let o=store.get('orders',id);let result=await request('/api/admin/orders/'+id,'PATCH',{status:'Cancelled',updatedAt:o.updatedAt},admin);assert.equal(result.status,200);assert.equal(product().variants[0].stock,p.variants[0].stock);
 o=result.data;result=await request('/api/admin/orders/'+id,'PATCH',{status:'Cancelled',updatedAt:o.updatedAt},admin);assert.equal(result.status,200);assert.equal(product().variants[0].stock,p.variants[0].stock);
 assert.equal((await request('/api/admin/orders/'+id,'PATCH',{status:'Delivered',updatedAt:'stale'},admin)).status,409);
});
test('COD cannot be marked paid until delivered; transitions and collected revenue agree',async()=>{
 const p=product(),r=await place(p),id=r.data.id;let o=store.get('orders',id);
 assert.equal((await request('/api/admin/orders/'+id,'PATCH',{paymentStatus:'paid',updatedAt:o.updatedAt},admin)).status,400);
 let a=await request('/api/admin/orders/'+id,'PATCH',{status:'Processing',updatedAt:o.updatedAt},admin);assert.equal(a.status,200);o=a.data;
 a=await request('/api/admin/orders/'+id,'PATCH',{status:'Delivered',paymentStatus:'paid',updatedAt:o.updatedAt},admin);assert.equal(a.status,200);assert.equal(a.data.payment.status,'paid');
 assert.ok((await request('/api/admin/overview','GET',undefined,admin)).data.revenue>=a.data.total);
});
test('draft/publish/version conflicts/rollback isolate public settings',async()=>{
 const old=store.get('config','settings');let draft=store.get('config','draft');let r=await request('/api/admin/theme','PUT',{...draft,heroTitle:'A test headline'},admin);assert.equal(r.status,200);assert.equal(store.get('config','settings').heroTitle,old.heroTitle);
 assert.equal((await request('/api/admin/theme','PUT',draft,admin)).status,409);draft=r.data;
 assert.equal((await request('/api/admin/theme/publish','POST',{version:draft.version-1},admin)).status,409);assert.equal((await request('/api/admin/theme/publish','POST',{version:draft.version},admin)).status,200);assert.equal(store.get('config','settings').heroTitle,'A test headline');
 r=await request('/api/admin/theme/rollback','POST',{},admin);assert.equal(r.status,200);assert.equal(store.get('config','settings').heroTitle,old.heroTitle);
});
test('coupons apply server-side, honor usage limits and cannot change price calculation',async()=>{
 const coupons=[{code:'TEN',type:'percent',value:10,minSpend:0,maxUses:1,active:true,expires:''}];assert.equal((await request('/api/admin/coupons','PUT',{items:coupons},admin)).status,200);
 const p=product(),q=await request('/api/quote','POST',cartBody(p,{couponCode:'TEN'}));assert.equal(q.status,200);assert.equal(q.data.discount,Math.round(p.variants[0].price*.1));assert.equal((await place(p,{couponCode:'TEN'})).status,201);assert.equal((await request('/api/quote','POST',cartBody(p,{couponCode:'TEN'}))).status,400);
});
test('manual payments require enabled account and transaction references cannot be reused',async()=>{
 const settings=store.get('config','settings');settings.manual.bkash='01712345678';store.put('config','settings',settings);const p=product();
 const a=await place(p,{paymentMethod:'bkash',trxId:'TESTPAY123'});const b=await place(p,{paymentMethod:'bkash',trxId:'TESTPAY123'});assert.equal(a.status,201);assert.equal(b.status,201);
 let o=store.get('orders',a.data.id);assert.equal((await request('/api/admin/orders/'+o.id,'PATCH',{paymentStatus:'paid',updatedAt:o.updatedAt},admin)).status,200);
 o=store.get('orders',b.data.id);assert.equal((await request('/api/admin/orders/'+o.id,'PATCH',{paymentStatus:'paid',updatedAt:o.updatedAt},admin)).status,409);
 settings.manual.bkash='';store.put('config','settings',settings);
});
test('uploads reject non-images; authenticated image upload is served',async()=>{
 let form=new FormData();form.append('image',new Blob(['not an image'],{type:'image/png'}),'bad.png');let r=await fetch(base+'/api/admin/uploads',{method:'POST',headers:{Origin:origin,Cookie:admin.cookie,'X-CSRF-Token':admin.csrf},body:form});assert.equal(r.status,400);
 const sample=fs.readFileSync(path.join(__dirname,'..','public',product().image));form=new FormData();form.append('image',new Blob([sample],{type:'image/webp'}),'watch.webp');r=await fetch(base+'/api/admin/uploads',{method:'POST',headers:{Origin:origin,Cookie:admin.cookie,'X-CSRF-Token':admin.csrf},body:form});assert.equal(r.status,201);const {image}=await r.json();assert.equal((await request(image)).status,200);
});
test('categories, analytics, exports and logout are functional',async()=>{
 assert.equal((await request('/api/admin/categories','PUT',{items:[{name:'Same'},{name:'Same'}]},admin)).status,400);
 assert.equal((await request('/api/admin/categories','PUT',{items:[{name:'Titan'},{name:'Tech'}]},admin)).status,200);
 assert.equal((await request('/api/visits','POST',{path:'/shop'})).status,200);assert.ok((await request('/api/admin/overview','GET',undefined,admin)).data.visits.length);
 assert.equal((await request('/api/admin/export','GET',undefined,admin)).status,200);
 assert.equal((await request('/api/auth/logout','POST',{},customer)).status,200);assert.equal((await request('/api/session','GET',undefined,customer)).data.user,null);
});
