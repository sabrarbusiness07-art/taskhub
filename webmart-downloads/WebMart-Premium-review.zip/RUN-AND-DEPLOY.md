# Run and deploy WebMart Premium

## Fresh installation

Use Node.js 24.14 or later in the 24.x line. From the extracted project directory:

```sh
npm ci --omit=dev
npm run setup
npm start
```

Create your own merchant credentials during setup. There is no default password. Open http://localhost:5000; merchant workspace: `/admin`; Theme Studio: `/admin/editor`.

The release contains no private database, sessions, credentials, backups, installed dependencies or uploaded customer media. Fresh installation creates the SQLite store from the included seed catalogue. Replace the illustrative website listings and demo links with your actual offerings before taking real requests.

## Upgrade an existing installation

1. Stop the old server and make a private backup of its full installation and uploaded media.
2. Extract this release separately. Run `npm ci --omit=dev`.
3. Copy your existing private `data/` directory and your own `public/uploads/` directory into the new installation, or keep using your existing configured persistent paths. Do not copy old source files, old precompressed assets or old `node_modules`.
4. Do not run fresh-admin setup over an existing account store. Start the application and sign in with your own merchant account.
5. Verify listings, saved theme, prices, pending requests and active rentals before switching traffic.

Existing saved v11 themes retain their configured palette. To adopt the fresh-install palette, set the following values in Theme Studio's global style controls, save the draft, preview it, and publish when ready: background `#f7f9fd`, surface `#ffffff`, ink `#15213b`, muted `#53617a`, accent `#3558ea`, border `#dfe5f0`, footer background `#101d3a`, button radius 10, card radius 18. This avoids silently overwriting merchant customization.

## Production hosting

Use a persistent, single-instance Node server with HTTPS and a private writable database directory. Configure `NODE_ENV=production`, `PUBLIC_URL` as your actual HTTPS origin, and `DATA_DIR` as your private persistent database directory. `HOST` defaults to `127.0.0.1`; use an appropriate bind address behind your reverse proxy. `PORT` defaults to 5000. Retain uploaded media on persistent storage. Back up SQLite and uploads separately.

This Express/SQLite application is not a stateless edge application. The UI release does not add automated provisioning, recurring billing or domain purchase. Review real plan scope and costs before activation. Existing README.md documents backend setup and operation in more detail.

## Development and verification

```sh
npm ci
npm run build:assets
npm run check
npm test
npx playwright install chromium
npm run test:browser
npm run test:editor
npm run test:templates
npm run test:fast
npm run test:slideshow
npm run test:premium
```

Set `BROWSER_EXECUTABLE` to an installed Chromium path where needed, for example `/usr/bin/chromium`. Set `BROWSER_ARTIFACTS` to the desired screenshot directory. Browser suites use temporary stores and generated credentials; they do not need your real customer database.

After any public asset edits, run `npm run build:assets` so Brotli/gzip versions match their sources, then `npm run check`. Catalogue and Theme Studio changes do not require an asset rebuild.
