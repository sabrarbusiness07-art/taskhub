# WebMart Premium verification — 12 November 2026

Tests ran in the managed Linux environment using Node 24.22.1 and installed Chromium. Each API/browser suite used isolated temporary databases and generated accounts. No real customer database or credentials were used. Logs are provided in the delivery's `verification/` folder.

| Check | Result | Coverage |
| --- | --- | --- |
| Supplied baseline `npm test` | 39 passed | Establish existing API/migration suite health before changes |
| Updated `npm test` | 39 passed, 0 failed, 0 skipped | Authentication, rentals, admin, theme editor, validation and migration compatibility |
| `npm run check` | Passed | JavaScript syntax, seed assets, matching gzip/Brotli sources |
| `npm run test:browser` | 19 grouped checks passed | Registration, pricing cycles, pending request, merchant activation, account status and dates, renewal, suspension/privacy, service pricing edits, Theme Studio reordering/publish, analytics, responsive forms/navigation |
| `npm run test:editor` | 20 grouped checks passed | Editor preview, text/section changes, FAQ editing, visibility, draft privacy, publish, custom pages, 16 built-in page previews, touch ordering, presets, mobile preview, export and rollback |
| `npm run test:templates` | 13 grouped checks passed | Catalogue search/filter/empty state, demo devices, synchronized plans/cycles, checkout after signup, merchant activation, metadata editing, analytics, responsive detail/editor pages |
| `npm run test:fast` | 11 grouped checks passed | Navigation persistence and URL validation, featured listing configuration, asset/API compression, image formats/uploads, public bundle separation, remote demo links and Theme Studio menus |
| `npm run test:slideshow` | 10 grouped checks passed | Hero images and links, next/previous/dots/pause, immediate CTA, pricing hover, upload/reorder/publish, public update, responsive pages and reduced motion |
| `npm run test:premium` | 7 grouped checks passed | Keyboard FAQ, actual local demo links, plan-section links, six public routes across eight widths, drawer focus return, merchant sidebar collapse/expand, customer anchors, both logout sessions and browser exceptions |

Total: 39 automated API/migration tests plus 80 grouped browser checks across six browser suites. These grouped checks contain multiple assertions; they are not 80 individual unit tests. All six browser suites reported no uncaught JavaScript exceptions.

## Release archive check

The full release ZIP passed CRC integrity and exclusion checks. It was extracted separately and started with a disposable database using the installed dependencies. Homepage, premium CSS, app module, store API, brand SVG and Atlas demo all returned HTTP 200. A new network dependency installation was not run for this smoke check.

## Responsive checks

The new premium suite checks horizontal overflow at 320, 375, 390, 430, 768, 1024, 1440 and 1920 pixels for `/`, `/websites`, `/website?id=template-atlas`, `/plans`, `/account` and `/page?name=help`. Existing suites additionally cover signed-in customer, checkout, service detail, merchant rentals/services, editor and analytics pages at 320, 390 and 768 pixels. Screenshots include desktop/mobile homepage and account, desktop pricing and merchant dashboard.

## Changes to existing tests

Two old assertions specifically expected the former purple brand color. They now expect the new royal-blue default; the migration preservation and functional assertions are retained. The new `test:premium` suite tests added keyboard/navigation behavior and requested additional viewport widths.

An initial browser run found that the new final CTA reused the hero action class, making an existing hero-only test selector ambiguous. The final CTA now has its own class. The complete browser suite passed after the correction. No unresolved reproducible regression was observed in the executed checks.

## Limits and checks not executed

- No measured Lighthouse score, formal WCAG certification, visual-regression pixel comparison, load test or production infrastructure audit.
- Chromium testing only; Safari, Firefox, physical touch devices and assistive-technology sessions were not run.
- External demo framing, real merchant payment verification, domain/hosting setup, actual Laravel application deployment, third-party payments and production credentials were not tested.
- Existing v11 saved-theme values intentionally remain; fresh-install screenshots show the new defaults.
- The configured user-facing `/codex/.../output` directory was unavailable to this cloud executor (filesystem permission denied; no administrator utility available). Packages were prepared in the writable workspace pending a supported download handoff.
