# Changed files

Compared byte-for-byte with the supplied project ZIP. Compressed companions are regenerated from the corresponding source assets.

- `README.md`
- `RUN-AND-DEPLOY.md`
- `TEST-REPORT.md`
- `UI-CHANGES.md`
- `lib/templates.js`
- `package.json`
- `public/admin.mjs`
- `public/app.mjs`
- `public/assets/brand-mark.svg`
- `public/assets/favicon.svg`
- `public/index.html`
- `public/premium.css`
- `public/site-defaults.json`
- `public/slideshow.mjs`
- `public/studio.css`
- `public/templates.mjs`
- `tests/premium-browser.cjs`
- `tests/templates-api.test.js`
- `tests/templates-browser.cjs`

`CHANGED-FILES.md` is an additional generated release manifest. No application source files were deleted. Private databases, uploads, installed dependencies and old interaction results are deliberately excluded from the release.
