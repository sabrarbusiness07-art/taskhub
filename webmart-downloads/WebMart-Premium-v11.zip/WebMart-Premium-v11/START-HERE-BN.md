# WebMart Laravel Website Rentals v11

পুরোনো server বন্ধ করে পুরো folder backup রাখো। ZIP আলাদা folder-এ extract করো। আগের `data` এবং নিজের `public/uploads` কপি করো; পুরোনো code/node_modules নয়। Account, password, paid rental ও expiry থাকবে। প্রথম upgrade-এ private backup ও আগের theme snapshot রাখা হবে।

Node.js 24 (24.14+) দিয়ে terminal-এ:

```powershell
npm.cmd ci --omit=dev
npm.cmd start
```

নতুন installation হলেই start-এর আগে `node scripts/setup-admin.js` চালাও। Website http://localhost:5000; admin http://localhost:5000/admin।

## Hero slideshow-এর ছবি বদলাও

**Store settings → Hero image slideshow**। Add slide দিয়ে সর্বোচ্চ ৬টি ছবি যোগ করো। Image upload, description ও destination দাও। নিজের product page-এর link হতে পারে `/website?id=...`। Move up/down দিয়ে সাজাও, Remove দিয়ে বাদ দাও। **Save & publish settings** দিলে live হবে।

ছবি ৫ সেকেন্ড পরপর বদলাবে; next/previous/dots/keyboard/pause আছে। Mouse বা keyboard focus থাকলে autoplay থামে। Reduce motion ও Theme Editor preview-তেও autoplay বন্ধ থাকে। Button feedback ৮০ ms; liquid overlay সরানো হয়েছে। Pricing cards-এ দ্রুত hover আছে।

## Laravel website listings

**Websites & services → Add/Edit service → Listing type: Laravel website**। নিজের website screenshot, features, included pages, HTTPS live demo link এবং monthly/yearly দাম দাও। Home ও Websites page-এ ecommerce-style grid থাকবে। Card click করলে product page ও scrollable live preview খুলবে। Customer plan বেছে rental request করবে; তুমি payment যাচাই করে activate করবে।

Atlas/Forma/Folio-এর দেওয়া previews উদাহরণ HTML design, সম্পূর্ণ Laravel application নয়। নিজের আসল Laravel website-এর demo/screenshot ও service scope বসিয়ে live business চালাবে। এই update storefront ও rental management-এর; customer website-এর Laravel source code বানায় না।

## অন্য editing

Theme editor → Style থেকে menu/submenu-এর নাম, link, order ও footer links বদলাও। Hero ছবির তালিকা Store settings-এ। Content sections drag/touch/keyboard দিয়ে সাজাতে পারবে। Draft ও Publish আলাদা।

External website iframe block করলে তার server-এ embedding allow করতে হবে; Open live preview button দিয়ে তবু website খোলা যাবে। Hosting setup, recurring charge ও refunds নিজে manage করবে। Manual CSS/JS বদলালে `npm run build:assets` চালাবে।
