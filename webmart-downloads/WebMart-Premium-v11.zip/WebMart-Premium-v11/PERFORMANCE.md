# v11 interaction performance

Hero CTA overlays, SVG turbulence and per-pointer button work are removed. Button hover/press feedback is 80 ms; slide crossfade is 120 ms; pricing-card hover is 100 ms. These durations describe visual feedback, not network response time. Normal website navigation does not capture full-page View Transition snapshots.

The focused Chromium test measures the hero CTA's JavaScript dispatch until the website catalogue is in the DOM. Raw result is in INTERACTION-RESULTS.json. This is a local handler measurement, not end-to-end production latency or a Core Web Vitals certification. External demo speed depends on its host.

Brotli/gzip delivery, WOFF2 fonts, font preloads, lazy merchant-code loading, screenshot upload optimization and immediately visible text remain enabled. The carousel reuses existing DOM, loads its first image eagerly, lazy-loads the others and owns one cleanup-managed timer. It pauses in hidden tabs, during hover/focus, in editor previews and for reduced motion. No slider framework is loaded.

The earlier single-thumbnail layout was replaced by the requested website grid. More visible product images can increase page download size; v10's previous 71% resource reduction is not presented as a new v11 measurement. Uploaded images should remain compressed. Run npm run build:assets after manual source changes; integrity checks reject stale compressed bundles.
